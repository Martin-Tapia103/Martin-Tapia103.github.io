package clases;

public interface SalarioTotal {

	double calcularSalarioTotal();
	
}
