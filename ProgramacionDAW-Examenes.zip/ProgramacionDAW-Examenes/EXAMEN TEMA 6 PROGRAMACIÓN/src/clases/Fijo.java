package clases;

public class Fijo extends Empleados implements SalarioMensual {

	//ATRIBUTOS -------------------------------------
	
	private double complemento;
	
	
	
	//CONSTRUCTORES -----------------------------------

	public Fijo(String nombre, double salarioBase, double complemento) {
		super(nombre, salarioBase);
		this.complemento = complemento;
	}


	public Fijo() {
		super();
	}

	
	//GETTERS Y SETTERS -----------------------------------
	
	
	public double getComplemento() {
		return complemento;
	}


	public void setComplemento(double complemento) {
		this.complemento = complemento;
	}


	//ABSTRACTO
	
	@Override
	public void tipoEmpleado() {
		// TODO Auto-generated method stub
		System.out.println(" es un empleado fijo");
	}	
	
	
	//INTERFAZ

	@Override
	public double calcularSalarioMensual() {
		// TODO Auto-generated method stub
		double salarioMensual = this.SalarioBase + this.complemento;
		return salarioMensual;
	}
	
	
	
	
	
	
}
