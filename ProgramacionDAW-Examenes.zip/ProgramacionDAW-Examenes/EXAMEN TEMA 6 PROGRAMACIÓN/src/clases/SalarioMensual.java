package clases;

public interface SalarioMensual {

	double calcularSalarioMensual();
	
	
}
