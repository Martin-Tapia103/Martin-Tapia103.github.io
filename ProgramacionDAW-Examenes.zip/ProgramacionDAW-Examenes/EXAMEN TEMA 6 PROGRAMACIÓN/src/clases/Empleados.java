package clases;

public abstract class Empleados {

	
	//ATRIBUTOS -------------------------------------
	
	protected String nombre;
	protected double SalarioBase;
	
	
	
	//CONSTRUCTORES ----------------------------------
	
	public Empleados(String nombre, double salarioBase) {
		super();
		this.nombre = nombre;
		SalarioBase = salarioBase;
	}


	public Empleados() {
		super();
	}

	
	//GETTERS Y SETTERS --------------------------------

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public double getSalarioBase() {
		return SalarioBase;
	}


	public void setSalarioBase(double salarioBase) {
		SalarioBase = salarioBase;
	}
	
	
	//METODO ABSTRACTO
	
	public abstract void tipoEmpleado();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
