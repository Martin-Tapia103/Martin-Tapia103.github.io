package clases;

public class Temporal extends Empleados implements SalarioTotal {

	//ATRIBUTOS -------------------------------------
	
	private int mesesContrato;

	
	
	//CONSTRUCTORES -----------------------------------
	
	public Temporal(String nombre, double salarioBase, int mesesContrato) {
		super(nombre, salarioBase);
		this.mesesContrato = mesesContrato;
	}


	public Temporal() {
		super();
	}


	
	//GETTERS Y SETTERS ----------------------------------
	
	public int getMesesContrato() {
		return mesesContrato;
	}


	public void setMesesContrato(int mesesContrato) {
		this.mesesContrato = mesesContrato;
	}


	//ABSTRACTO
	
	@Override
	public void tipoEmpleado() {
		// TODO Auto-generated method stub
		System.out.println(" es un empleado temporal");
	}
	
	
	//INTERFAZ

	@Override
	public double calcularSalarioTotal() {
		// TODO Auto-generated method stub
		double salarioTotal = this.SalarioBase*this.mesesContrato;
		return salarioTotal;
	}
	
	
	
	
	
	
	
	
	
	
}
