package main;

import clases.Empleados;
import clases.Fijo;
import clases.Temporal;
import java.util.Scanner;


public class MainEmpleados {

	static boolean seguir = true;
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static Scanner scDouble = new Scanner(System.in);
	
	static Empleados e0;
	static Empleados e1;
	
	static String nombreEmpleadoFijo;
	static double salarioBase;
	static double complemento;
	
	static String nombreEmpleadoTemporal;
	static double salarioBase2;
	static int mesesContrato;
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		do {
			
		System.out.println("\n========== MENÚ ==========");
		System.out.println("1.- Introducir empleados");
		System.out.println("2.- Tipo empleados");	
		System.out.println("3.- Sueldo empleados");
		System.out.println("4.- Aumentar sueldo empleado fijo");
		System.out.println("5.- Comparar sueldos");
		System.out.println("6.- Salir");
		System.out.println("\n Elige una opción");
		
		int opcion = scInt.nextInt();
		switch (opcion) {
		case 1:
			introducirEmpleados();
			System.out.println("\nPulsa ENTER para volver al menu");
			scLine.nextLine();
			break;
			
		case 2:
			tipoDeEmpleados();
			System.out.println("\nPulsa ENTER para volver al menu");
			scLine.nextLine();
			break;
		
		case 3:
			sueldoEmpleados();
			System.out.println("\nPulsa ENTER para volver al menu");
			scLine.nextLine();
			break;
			
		case 4:
			aumentarElSueldoDelEmpleadoFijo();
			System.out.println("\nPulsa ENTER para volver al menu");
			scLine.nextLine();
			break;
			
		case 5:
			compararSueldos();
			System.out.println("\nPulsa ENTER para volver al menu");
			scLine.nextLine();
			break;
			
		case 6:
			salir();
			break;
		
		}
					
	} while(seguir);  
		System.out.println("PROGRAMA FINALIZADO");
}
	


	//CASOS ------------------------------------------------------------------
	
		
	private static void introducirEmpleados() {
		// TODO Auto-generated method stub

		// FIJO ------------------

		if (e0 == null && e1 == null) {

			System.out.println("Introducir empleado fijo");

			System.out.println("Nombre?");
			nombreEmpleadoFijo = scLine.nextLine();

			System.out.println("Sueldo base?");
			salarioBase = scDouble.nextInt();

			System.out.println("Complemento?");
			complemento = scLine.nextDouble();
			scLine.nextLine();

			e0 = new Fijo(nombreEmpleadoFijo, salarioBase, complemento);


		// TEMPORAL ------------------


			System.out.println("\nIntroducir empleado temporal");

			System.out.println("Nombre?");
			nombreEmpleadoTemporal = scLine.nextLine();

			System.out.println("Sueldo base?");
			salarioBase2 = scDouble.nextInt();

			System.out.println("Meses contrato?");
			mesesContrato = scLine.nextInt();

			e1 = new Temporal(nombreEmpleadoTemporal, salarioBase2, mesesContrato);

			System.out.println("\nEmpleados registrados\n");

		} else {
			
			System.out.println("\nYa tienes empleados creados");
			
		}
	}

	private static void tipoDeEmpleados() {
		// TODO Auto-generated method stub

		if (e0 != null && e1 != null) {

			System.out.print(e0.getNombre() + " ");  e0.tipoEmpleado();
			System.out.print(e1.getNombre() + " ");  e1.tipoEmpleado();

		} else {

			System.out.println("\nTodavía no hay empleados creados");
		}

	}
	
	private static void sueldoEmpleados() {
		// TODO Auto-generated method stub
		
		if (e0 != null && e1 != null) {

			Fijo fijo = (Fijo) e0;
			Temporal temporal = (Temporal) e1;

			System.out.println(e0.getNombre() + " tiene un salario mensual de " + fijo.calcularSalarioMensual());
			System.out.println(e1.getNombre() + " tiene un salario total de " + temporal.calcularSalarioTotal());

		} else {

			System.out.println("\nTodavía no hay empleados creados");
		}
	}
	
	
	private static void aumentarElSueldoDelEmpleadoFijo() {
		// TODO Auto-generated method stub
		
		if (e0 != null) {

			System.out.println("Aumento de sueldo base del empleado fijo?");
			double aumento = scDouble.nextDouble();
			e0.setSalarioBase(e0.getSalarioBase() + aumento);
			System.out.println("El salario base actual de " + e0.getNombre() + " es de " + e0.getSalarioBase());

		} else {

			System.out.println("\nTodavía no hay empleados creados");
		}

	}
		
	private static void compararSueldos() {
		// TODO Auto-generated method stub

		Fijo fijo = (Fijo) e0;
		Temporal temporal = (Temporal) e1;

		if (fijo == null && temporal == null) {
			System.out.println("\nAún no has creado empleados");

		} else if (fijo.calcularSalarioMensual() > temporal.calcularSalarioTotal()) {
			System.out.println("El salario mayor es el de " + fijo.getNombre());

		} else if (temporal.calcularSalarioTotal() > fijo.calcularSalarioMensual()) {
			System.out.println("El salario mayor es el de " + temporal.getNombre());
		}

	}	
		
	private static void salir() {
		seguir = false;
	}

}


