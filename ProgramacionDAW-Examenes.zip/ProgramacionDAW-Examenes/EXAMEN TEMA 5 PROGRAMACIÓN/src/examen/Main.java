package examen;
import java.util.*;


public class Main {

	static Scanner scInt = new Scanner(System.in);
	static Scanner scLine = new Scanner(System.in);
	
	static Movil m1 = new Movil("Oppo", 150, 678111222, true);
	static Movil m2 = new Movil("Xiaomi", 175, 678333444, false);
	
	
	public static void main(String[] args) { 
		// TODO Auto-generated method stub
		
		
do {
			
			System.out.println("--------------MENU--------------");
			System.out.println("\n1.- MOSTRAR DATOS");
			System.out.println("2.- CAMBIAR NUMERO");			
			System.out.println("3.- APAGAR/ENCENDER");
			System.out.println("4.- RECIBIR LLAMADA");
			
		
			int opcion = scInt.nextInt();
			switch (opcion) {
			case 1:
				mostrarDatos(m1, m2);
				break;
				
			case 2:
				cambiarNumero(m1);
				break;
			
			case 3:
				ApagarOEncender(m2);
				break;
				
			case 4:
				RecibirLlamada();
				break;
			
			}
						
    } while (true); 
    	
	}
	
	
	// METODOS ------------------------------------------------

		//CASO 1 ----------------------------------
	
			private static void mostrarDatos(Movil m1, Movil m2) {
				// TODO Auto-generated method stub
				
				System.out.println(m1);
				System.out.println(m2);		
				
				System.out.println("\nPulsa ENTER para continuar");
				scLine.nextLine();
			}
			
		
		//CASO 2 -----------------------------------	
			
			private static void cambiarNumero(Movil m1) {
		// TODO Auto-generated method stub
		
			System.out.println("Dime el nuevo número del móvil Oppo");			
			int numeroNuevo = scInt.nextInt();
			m1.setNumeroDeMovil(numeroNuevo);	
			
			System.out.println("El movil Oppo ha cambiado de numero");			
			
			System.out.println("\nPulsa ENTER para continuar");
			scLine.nextLine();
							
	}
			
		//CASO 3 --------------------------------------	
			
			private static void ApagarOEncender(Movil m2) {
		// TODO Auto-generated method stub
		
			m2.apagarEncender();
				
			System.out.println("\nPulsa ENTER para continuar");
			scLine.nextLine();					
	}

		
		//CASO 4 ---------------------------------------	
			
			private static void RecibirLlamada() {
		// TODO Auto-generated method stub
				
			m2.recibirLlamada();
				
			System.out.println("\nPulsa ENTER para continuar");
			scLine.nextLine();		
		
	}	
			
}		
	
 


