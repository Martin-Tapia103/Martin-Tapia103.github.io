package examen;

import java.util.Random;

public class Movil {

	
	//ATRIBUTOS --------------------------------------
	
	private String marca;
	private double peso;
	private int numeroDeMovil;
	private boolean encendido; //true = encendido | false = apagado
	
	
	//CONSTRUCTORES ----------------------------------
	
	public Movil() {
		super();
	}


	public Movil(String marca, double peso, int numeroDeMovil, boolean encendido) {
		super();
		this.marca = marca;
		this.peso = peso;
		this.numeroDeMovil = numeroDeMovil;
		this.encendido = encendido;
	}

	
	
	// GETTERS Y SETTERS -------------------------------
	
	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public int getNumeroDeMovil() {
		return numeroDeMovil;
	}


	public void setNumeroDeMovil(int numeroDeMovil) {
		this.numeroDeMovil = numeroDeMovil;
	}


	public boolean isEncendido() {
		return encendido;
	}


	public void setEncendido(boolean encendido) {
		this.encendido = encendido;
	}

	public void apagarEncender() {
		if (this.encendido == false) {
			this.encendido = true;
			System.out.println("El movil Xiaomi se ha encendido");
			
		} else if (this.encendido == true) {
			this.encendido = false;
			System.out.println("El movil Xiaomi se ha apagado");
		}
	}
	
	
	public int recibirLlamada() {
		Random random = new Random(); 
		int recibirLLamada = 0;
	    int r = random.nextInt(600111111,700000000);
		
		while (recibirLLamada == 0) {
			if (this.encendido == false) {
				System.out.println("El móvil no puede recibir llamadas porque está apagado");
				break;
			} else if (this.encendido == true) {
				System.out.println("Ha llamado el numero " + r);
				break;
			}
						
		}
			
		return recibirLLamada;
	}
	

	//TO STRING --------------------------------
	
	
	@Override
	public String toString() {
		return "Movil [marca=" + marca + ", peso=" + peso + ", numeroDeMovil=" + numeroDeMovil + ", encendido="
				+ encendido + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
