package programaExamen;
import java.util.*;

import programaExamen.Paciente;

public class Main {

	static Set<Paciente> pacientes = new HashSet();
	static List<Paciente> enCurso = new ArrayList();
	static List<Paciente> consultas = new ArrayList();
	
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Paciente p0 = new Paciente("1A", "Jose", 42);
		Paciente p1 = new Paciente("2A", "Eva", 39);
		Paciente p2 = new Paciente("3A", "Luis", 25);
		Paciente p3 = new Paciente("4A", "Elena", 38);
		
		
		//======= PACIENTES =========
		
		pacientes.add(p0);
		pacientes.add(p1);
		pacientes.add(p2);
		pacientes.add(p3);
		
		
		//======= EN CURSO =========
		
		enCurso.add(p0);
		enCurso.add(p1);
		enCurso.add(p2);
		
		
		do {
			
			System.out.println("\n=========== MENU ===========");
	        System.out.println("1.- Lista de pacientes identificados");
	        System.out.println("2.- Mostrar datos paciente");
	        System.out.println("3.- Introducir paciente");
	        System.out.println("4.- Pasar en curso a en consulta.");
	        System.out.println("5.- Eliminar paciente");


			
			int opcion = scInt.nextInt();
			switch (opcion) {
			case 1:
				listarPacientesIdentificados();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 2:
				mostrarDatosPacientes();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 3:
				introducirPaciente();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 4:
				pasarAConsulta();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 5:
				eliminarPaciente();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;			
			}
		
			} while (true);
			
		}

		
		//METODOS ===========================================
		
		
		


	private static void listarPacientesIdentificados() {
		// TODO Auto-generated method stub
		
		System.out.println("========= PACIENTES REGISTRADOS ==============");
		
		for(Paciente p: pacientes) {
			
			System.out.println(p);
			
		}
	}


	private static void mostrarDatosPacientes() {
		// TODO Auto-generated method stub
		
		System.out.print("Introduce la identificación del cliente: ");
		String busqueda = scLine.nextLine();
				
				for (Paciente p: pacientes) {
					if (p.getIdClinico().equalsIgnoreCase(busqueda)) {
						System.out.println("Datos del paciente");
						System.out.println(p);
					} else {
						System.out.println("Eso no es un paciente");
						break;
					}
				}
				
	    	}

	private static void introducirPaciente() {
		// TODO Auto-generated method stub
	
		System.out.print("\nIdentificador? ");
		String id = scLine.nextLine();
		
		System.out.print("Nombre? ");
		String nombre = scLine.nextLine();
		
		System.out.print("Edad? ");
		int curso = scInt.nextInt();
	
		Paciente Px = new Paciente(id, nombre, curso);
		
		if (pacientes.contains(Px)) {
			System.out.println("Ese identificador ya esta en uso");
			
		} else {
			
			pacientes.add(Px);			
			System.out.println("El paciente " + Px.getNombre() + " ha sido anyadido");
		}

	}
	
	private static void pasarAConsulta() {
		// TODO Auto-generated method stub
		
		for (int i=0; i<enCurso.size(); i++) {
			System.out.println(i + ".- " + enCurso.get(i));
			
		}
		
		System.out.println("\n");
		System.out.println("Que paciente pasamos de en curso a Consulta?");
		int opcion = scInt.nextInt();
		
		Paciente px = enCurso.get(opcion);
		
		consultas.add(px);
		enCurso.remove(opcion);
		
		
		System.out.println("Pacientes en curso");
		for (int i=0; i<enCurso.size(); i++) {
			System.out.println(i + ".- " + enCurso.get(i));
			
		}	
			
		System.out.println("\nPacientes en consulta");
		for (int i=0; i<consultas.size(); i++) {
				System.out.println(i + ".- " + consultas.get(i));
		
		}		
				
	}

	private static void eliminarPaciente() {
		// TODO Auto-generated method stub
		
		
		System.out.print("Introduce el ID del paciente a eliminar: ");
		String busqueda = scLine.nextLine();
				
		Paciente px = new Paciente(busqueda, "", 0);
		
		if (pacientes.contains(px)) {
		
				for (Paciente p: pacientes) {
					if (p.getIdClinico().equalsIgnoreCase(busqueda)) {	
						
						pacientes.remove(p);				
						System.out.println("Paciente borrado del registro general");
						break;								
					} 
				}
				
				for (Paciente p: enCurso) {
					if (p.getIdClinico().equalsIgnoreCase(busqueda)) {	
						
						enCurso.remove(p);				
						System.out.println("Paciente borrado de pacientes en curso");
						break;								
					} 
				}
				
				
				for (Paciente p: consultas) {
					if (p.getIdClinico().equalsIgnoreCase(busqueda)) {	
						
						consultas.remove(p);				
						System.out.println("Paciente borrado de pacientes en consulta");
						break;								
					} 
				}	
				
		}	else {
			System.out.println("Eso no es un paciente");
		}	
		
	}	
	
}
