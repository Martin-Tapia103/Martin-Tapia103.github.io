package arraysEjerciciosExamen;
import java.util.*;

public class EjerciciosArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//1.-
		
		int array1x[] = {1, 2, 3, 4, 5, 6};
		int array1y[] = {2, 2, 2, 3, 3, 3};
		
		int longitud = array1x.length;
		
		int array1z[] = new int [longitud];
		for (int i = 0; i<array1x.length; i++) {
			if (i % 2 == 0) {                            
			array1z[i] = (array1x[i] + array1y[i]);	
			}		
		}	
	
		System.out.println(Arrays.toString(array1z));
		
		
		
		
		//2.-
	
		
		
		
		//3.-
		
      int array3x[][] = {{1,1,1}, {2,2,2}, {3,3,3}, {4,4,4}};

      for(int i = 0; i < array3x.length; i++) {
    	  for(int j = 0; j < array3x[0].length; j++) {
         	
          	if (i%2 == 0 && j%2 !=0) {
          		
          	array3x[i][j] = array3x[i][j] * 4;

          	}     
      }
     }	
	System.out.println(Arrays.deepToString(array3x));
		
		
		
		
		
		
    int aa[][] = {{1,2,3}, {4,5,6}, {7,8,9}};
    int bb[][] = {{10,11,12,6}, {14,15,16,5}, {16,17,18,8}};


    int cc[][] = new int[aa.length][aa[0].length];

    for(int i = 0; i < aa.length; i++) {
        for(int j = 0; j < aa[0].length; j++) {
        	
        	if (i%2 ==0 && j%2==0) {
        		
        	cc[i][j] = aa[i][j] + bb[i][j];

        	}
        }
    }
	
	System.out.println(Arrays.deepToString(cc));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
