package tiendaVideojuegos;

import java.sql.*;
import java.util.*;

public class Main {

	private static final String URL = "jdbc:sqlite:bbdd_videojuegos.db";
	 
    public static void main(String[] args) {
        Scanner scLine = new Scanner(System.in);
        Scanner scInt = new Scanner(System.in);
        Scanner scDouble = new Scanner(System.in);
 
        try (Connection conn = DriverManager.getConnection(URL)) {
            System.out.println("Conexión establecida");
            String sql = """
                         CREATE TABLE IF NOT EXISTS videojuegos (
                             id INTEGER PRIMARY KEY AUTOINCREMENT,
                             codigo TEXT NOT NULL,
                             nombre TEXT NOT NULL,
                             precio REAL NOT NULL,
                             stock INTEGER NOT NULL
                         );
                         """;
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(sql);
            }
 
            int opcion;
            do {
                System.out.println("\nMENU");
                System.out.println("1. Añadir videojuego");
                System.out.println("2. Lista de videojuegos");
                System.out.println("3. Actualizar precio");
                System.out.println("4. Vender juego");
                System.out.println("Elige una opcion ( 1- 4 ) ");
                opcion = scInt.nextInt();
 
                switch (opcion) {
                    case 1:
                        System.out.println("Añadir videojuego");
                        System.out.println("Codigo");
                        String codigo = scLine.nextLine();
                        System.out.println("Nombre?");
                        String nombre = scLine.nextLine();
                        System.out.println("Precio?");
                        double precio = scDouble.nextDouble();
                        System.out.println("Stock?");
                        int stock = scInt.nextInt();
                        insertarVideojuego(conn, codigo, nombre, precio, stock);
                        System.out.println("\nPulsa ENTER para para volver al menu");
                        scLine.nextLine();
                        break;
                    case 2:
                        listarVideojuegos(conn);
                        System.out.println("\nPulsa ENTER para para volver al menu");
                        scLine.nextLine();
                        break;
                    case 3:
                        actualizarPrecios(conn, scLine, scInt, scDouble);
                        System.out.println("\nPulsa ENTER para para volver al menu");
                        scLine.nextLine();
                        break;
                    case 4:
                        eliminarVideojuego(conn, scLine, scInt, scDouble);
                        System.out.println("\nPulsa ENTER para para volver al menu");
                        scLine.nextLine();
                        break;
                }
            } while (true);
 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private static void insertarVideojuego(Connection conn, String codigo, String nombre, double precio, int stock) {
        String sql = "INSERT INTO videojuegos(codigo, nombre, precio, stock) VALUES(?,?,?,?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            pstmt.setString(2, nombre);
            pstmt.setDouble(3, precio);
            pstmt.setInt(4, stock);
            pstmt.executeUpdate();
            System.out.println("Videojuego " + nombre + " añadido");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private static void listarVideojuegos(Connection conn) {
        String sql = "SELECT * FROM videojuegos";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println(rs.getString("codigo") + " | " + rs.getString("nombre") + " | " + rs.getDouble("precio") + " | " + rs.getInt("Stock"));
            }
        } catch (SQLException e) {
            System.out.println("No hay ningun videojuego");
        }
    }
 
    private static void actualizarPrecios(Connection conn, Scanner scLine, Scanner scInt, Scanner scDouble) {
        System.out.println("¿Codigo del videojuego para actualizar?");
        String codigo = scLine.nextLine();
        String sqlBuscar = "SELECT * FROM videojuegos WHERE codigo = ?";
 
        try (PreparedStatement pstmtBuscar = conn.prepareStatement(sqlBuscar)) {
            pstmtBuscar.setString(1, codigo);
            ResultSet rs = pstmtBuscar.executeQuery();
 
            if (rs.next()) {
                double precioActual = rs.getDouble("precio");
                System.out.println("\nprecio actual: " + precioActual);
                System.out.println("Nuevo precio (ENTER para mantener)");
                String precioTexto = scLine.nextLine();
 
                if (precioTexto.equals("")) {
                    System.out.println("No se ha modificado nada");
                } else {
                    double precioNuevo = Double.parseDouble(precioTexto);
                    String sqlUpdate = "UPDATE videojuegos SET precio = ? WHERE codigo = ?";
                    try (PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
                        pstmtUpdate.setDouble(1, precioNuevo);
                        pstmtUpdate.setString(2, codigo);
                        pstmtUpdate.executeUpdate();
                        System.out.println("El nuevo precio ha sido puesto");
                    }
                }
            } else {
                System.out.println("No existe ese codigo");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private static void eliminarVideojuego(Connection conn, Scanner scLine, Scanner scInt, Scanner scDouble) {
        System.out.println("¿Codigo del juego para vender?");
        String codigo = scLine.nextLine();
        String sqlBuscar = "SELECT precio, stock FROM videojuegos WHERE codigo = ?";
 
        try (PreparedStatement pstmtBuscar = conn.prepareStatement(sqlBuscar)) {
            pstmtBuscar.setString(1, codigo);
            ResultSet rs = pstmtBuscar.executeQuery();
 
            if (rs.next()) {
                int stockActual = rs.getInt("stock");
                double precio = rs.getDouble("precio");
 
                if (stockActual > 0) {
                    String sqlUpdate = "UPDATE videojuegos SET stock = ? WHERE codigo = ?";
                    try (PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
                        pstmtUpdate.setInt(1, stockActual - 1);
                        pstmtUpdate.setString(2, codigo);
                        pstmtUpdate.executeUpdate();
                        System.out.println("El videojuego ha sido vendido y el stock ha sido actualizado");
                        System.out.println("Ganancias de la venta: " + precio + "€");
                    }
                } else {
                    System.out.println("No queda stock de este videojuego");
                }
            } else {
                System.out.println("No existe ese codigo");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



