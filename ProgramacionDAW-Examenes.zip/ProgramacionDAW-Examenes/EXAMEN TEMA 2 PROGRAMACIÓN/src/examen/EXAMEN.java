package examen;
import java.util.*;
public class EXAMEN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		//1.- Preguntar por el nombre, a continuación, preguntar por el primer apellido y por último preguntar por el segundo apellido. El programa ha de decir:
//		El nombre completo es [nombre] [apellido1] [apellido2]

		
//		Scanner scLine = new Scanner(System.in);
//		
//		System.out.println("Dime tu nombre");
//		String nombre = scLine.nextLine();
//		
//		System.out.println("Dime tu primer apellido");
//		String apellido1 = scLine.nextLine();
//		
//		System.out.println("Dime tu segundo apellido");
//		String apellido2 = scLine.nextLine();
//		
//		System.out.print("El nombre completo es " + nombre + " " + apellido1 + " " + apellido2);
//		
//		scLine.close();
		
		
		
		//2.- Hacer un programa que pida una frase. El programa dirá la longitud de la frase sin contar los espacios.
		
//		Scanner scLine = new Scanner(System.in);
//		
//		System.out.println("Dame una frase");
//		String frase = scLine.nextLine();
//		int longitudSinEspacios = frase.replace(" ", "").length();				
//		System.out.println("La frase sin espacios mide: " + longitudSinEspacios + " caracteres");
//		
//		scLine.close();
		
		
		//3.- Hacer un programa que pida dos números con decimales y obtenga la división del primero entre el segundo.
		//La solución se ha de mostrar redondeada a un decimal.
		
		
//		Scanner scDouble = new Scanner(System.in);
//		
//		System.out.println("Dame un nº decimal");		
//		double numero1 = scDouble.nextDouble();
//		
//		System.out.println("Dame otro nº decimal");		
//		double numero2 = scDouble.nextDouble();
//		
//		double division = numero1/numero2;
//		double resultado = Math.round(division * 10.0) / 10.0;
//		
//		System.out.println("Tu nº decimal redondeado es: " + resultado);
//		
//		scDouble.close();
		
		
		
		
		//Hacer un programa que pregunte por un número entero y a continuación escriba la frase:
		//“La raíz cuadra del número [número] es [resultado]”. El resultado con todos los decimales.
		
//		Scanner scDouble = new Scanner(System.in);
//		
//		System.out.println("Dame un nº entero");
//		int entero = scDouble.nextInt();
//		
//		double resultado = Math.sqrt(entero);
//		
//		System.out.println(resultado);
//		
//		scDouble.close();
		
		
		
		//5.- Hacer un programa que pida una palabra.
		//A continuación, el programa pedirá una posición de la palabra entre 0 y la posición del último carácter, que calculará él.
		//Al introducir la posición el programa devolverá el carácter en esa posición. Se asume que el usuario va a introducir una posición válida.
		
		
		
//		Scanner scLine = new Scanner(System.in);
//		
//		System.out.println("Introduce una palabra");
//		String palabra = scLine.nextLine();
//		
//		System.out.println("Introduce una posición (relativa a tu palabra introducida)");
//		int posicion = scLine.nextInt();
//		
//		char resultado = palabra.charAt(posicion);
//		
//		System.out.println(resultado);
//		
//		scLine.close();

		
		
		
		//6.- Un correo corporativo tiene el siguiente formato: nombre.apellido1.apellido2@dominio.subdominio.tld
		//Preguntar por el correo, por ejemplo: manuel.perez.lopez@microsoft.finanzas.com y obtener el subdominio, es decir ‘finanzas’.
		//Ha de funcionar con cualquier correo con ese formato.

		
		
		
//		Scanner scLine = new Scanner(System.in);
//
//        System.out.print("Email: ");
//        String email = scLine.nextLine();
//        email = email.trim();
//
//
//        String usuario = email.substring(0, email.indexOf('@'));
//
//
//        int posArroba = email.indexOf('@');
//        int posUltimoPunto = email.lastIndexOf('.');
//
//        int posPenultimoPunto = email.lastIndexOf('.', posUltimoPunto - 1);
//        String segundoNivel = email.substring(posPenultimoPunto + 1, posUltimoPunto);
//
//        System.out.println(segundoNivel);
//
//        scLine.close();
		
		
		
		
		//7. - Obtener dos números aleatorios entre 0 y 500 (ambos incluidos).
		//A continuación, obtener un numero aleatorio entre los dos números obtenidos. Se tiene que garantizar que el programa no puede fallar.
		

//      Random r = new Random();
//
//      int num1 = r.nextInt(500) + 0; 
//      System.out.println("Primer nº: " + num1);
//
//
//      int num2 = r.nextInt(500) + 0; 
//      System.out.println("\nSegundo nº: " + num2);
//
//      int min = Math.min(num1, num2);
//      int max = Math.max(num1, num2);
//      int num3 = r.nextInt(min, max + 1);  
//      System.out.println("\nTercer nº (Entre los dos primeros): " + num3);
      

		
		
		//8.- Hacer un programa que pida 3 números enteros.
		//El programa obtendrá un número aleatorio entre el menor de los tres números y el mayor de los tres números (ambos incluidos).
		
//		Scanner scInt = new Scanner(System.in);
//		Random r = new Random();
//		
//		System.out.println("Dame un nº");
//		int n1 = scInt.nextInt();
//		
//		System.out.println("Dame un nº");
//		int n2 = scInt.nextInt();
//		
//		System.out.println("Dame un nº");
//		int n3 = scInt.nextInt();
//		
//     	int n4 = Math.min(n1, n2);
//     	int n5 = Math.max(n4, n3);
//     	int resultado = r.nextInt(n4, n5 + 1);  
//		
//		System.out.println("El nª aleatorio sera:" + resultado);
//		
//		scInt.close();
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
