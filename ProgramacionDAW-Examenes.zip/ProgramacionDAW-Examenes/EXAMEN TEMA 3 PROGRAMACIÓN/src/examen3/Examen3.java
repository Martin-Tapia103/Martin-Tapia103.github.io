package examen3;
import java.util.*;

public class Examen3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//1.- Obtener un listado con todos los múltiplos de 7 entre 7 y 70 (ambos incluidos).

//		for (int i = 7; i <= 70; i += 7) {
//	    System.out.println(i);
//	}
		
		
		//2.- Hacer un programa que pregunte por un número entero. A continuación que pregunte por otro número entero.
		//El programa ha de decir si el primero es mayor, si el segundo es mayor o si los dos son iguales.
		
//		Scanner scInt = new Scanner(System.in);
//		
//		System.out.println("Dame un número entero");
//		int numero = scInt.nextInt();
//		
//		System.out.println("Dame un número entero");
//		int numero2 = scInt.nextInt();
//		
//		if (numero > numero2) {
//			System.out.println("El primer nº es mayor");
//			
//		} else if (numero2 > numero) {
//			System.out.println("El segundo nº es mayor");
//			
//		}else if (numero == numero2) {
//			System.out.println("Los dos son iguales");
//		}
//			
//		scInt.close();
		
		
		
		//3.- Obtener un listado con todos los múltiplos de 5 entre 5 y 200 (ambos incluidos).
		//Los que también sean múltiplos de 25 han de salir con un * al lado. 
		
		
//		for (int i = 5; i <= 200; i += 5) {
//	    if (i % 25 == 0)
//	        System.out.println(i + "*");
//	    else
//	        System.out.println(i);
//	}
		
		
		
		//4.- Obtener la suma de todos los múltiplos de 3 entre 1 y 400 exceptuando los múltiplos de 12.
		
//		int suma = 0;
//		for (int i = 1; i <= 400; i +=3) {
//		    if (i % 12 !=0) {
//		        suma += i;
//			System.out.println(i);
//		    }
//		}
//		System.out.println("Suma total: " + suma);
		
		
		//5.- Obtener un listado con todos los números pares entre -40 y -100 (ambos incluidos), empezando por el -40 y exceptuando los que están entre -59 y -79.
		//Hacerlo utilizando solo un bucle y condicionales.
		
		
		
		//6.- El programa pedirá introducir una frase.
		//Se mostrarán en vertical los caracteres de las posiciones pares de la frase (0,2,4…) excepto si en esa posición par hay un espacio, que no se mostrará.
		
		
		
		
		
		//7.- Hacer un programa que pida un número entero.
		//El programa mostrará el número introducido multiplicado por 2. Si no se introduce un número el programa indicará que el dato introducido no es válido.
		//Hacerlo con try-with-resources. No tiene que entrar en bucle.
		
		
//		try (Scanner scInt = new Scanner(System.in);) {
//	
//		System.out.println("Introduce un número entero");
//		int numero = scInt.nextInt();
//		System.out.println("Tu nº multiplicado x2 es: " + numero*2);
//
//		} catch (Exception e) {
//			
//			System.out.println("El dato introducido no es válido");
//		}
		
		
		//8.- Hacer sin utilizar try-with-resources un programa que pida una frase y dos números enteros.
		//El programa mostrará los dos caracteres que hay en la frase en las posiciones de los dos números introducidos.
		//También mostrará el resultado (como un entero) de la división de los dos números.
		//El programa ha de capturar las excepciones InputMismatchException, StringIndexOutOfBoundsException y ArithmeticException indicando
		//en cada una qué error se ha producido (en caso de producirse). No tiene que entrar en bucle.

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
