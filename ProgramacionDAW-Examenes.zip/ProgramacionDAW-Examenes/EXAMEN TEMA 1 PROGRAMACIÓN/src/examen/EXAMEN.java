package examen;

public class EXAMEN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
		// EJERCICIO 1 - 1.	Obtén el módulo 5 del número 103 y guárdalo en la variable ‘m’.
		//A continuación, obtén el módulo 3 del resultado anterior, es decir el módulo 3 de ‘m’. Muestra el resultado.
		
//		double m = 5 % 103;
//		
//		System.out.println("Modulo 'm': " + m);
//		
//		double a = 3 % m;
//		
//		System.out.println("Modulo '3' de 'm': " + a);
		
		
		
		
		
		// EJERCICIO 2 - 2.	Declara la variable int a=11. A continuación divide ‘a’ entre dos, de modo que el resultado sea exacto.
		
		
//		int a = 11;
//		
//		double b = a/2.0;
//		
//		System.out.println("Resultado: " + b);

		
		
		
		
		// EJERCICIO 3 - 3.	Crea una variable con valor igual a 200. A continuación, multiplica esa variable por 3. Luego súmale a esa misma variable 50.
		//A continuación, divide esa misma variable entre 3. Por último, muestra el valor de la variable. El resultado ha de ser exacto.
		
		
//		double a = 200.0;
//		double b = 200.0*3.0;
//		double c = b + 50.0;
//		double d = c/3.0;
//		
//		System.out.println("Total: " + d);
	
		
		
		//EJERCICIO 4 - 4.	Dadas las variables a=4 y b=10, implementa la siguiente formula y obtén el valor exacto de c.
		// c=(5/3)*100*a*b + 50

		
//		double a = 4.0;
//		double b = 10.0;
//		
//		double c = (5.0/3.0)*100.0*a*b + 50.0;
//		
//		System.out.println("El resultado de la formula es: " + c);
		
		
		//EJERCICIO 5 - 5.	Si un coche consume 7.5 litros de gasolina cada 100 km, calcula cuánto consumirá en un trayecto de 350 km.
		
//		double gasoil = 7.5;
//		double km = 100.0;
//		double km2 = 350.0;
//		
//		double consumo = (gasoil/km) * km2;
//		
//		System.out.println("El coche consumira " + consumo + "L en un trayecto de 350km");
		
		
		//EJERCICIO 6 - 6.	Declara una variable booleana SIN inicializarla. A continuación, en OTRA instrucción inicializa la variable a true.
		//A continuación, en otra instrucción declara otra variable booleana e inicialízala a que sea la negada de la primera.
		//Por último, muestra el resultado de la segunda variable booleana.
		
		
		
		
//		boolean a = true;
//		System.out.println("Variable original: " + a);
//		
//		boolean e = !a;
//		System.out.println("variable original negada: " + e);
		
		
	
		//EJERCICIO 7 - 7.	Si un tren viaja a una velocidad constante de 90 km/h, calcula cuántos kilómetros habrá recorrido en 2 horas y 30 minutos.
		
		
//        double velocidad = 90.0;
//        double tiempo = 2.5;
//        double distancia = velocidad * tiempo;
//        System.out.println("Distancia recorrida por el tren en 2h 30m: " + distancia + " km");

		
		
		
		
		//EJERCICIO 8 - 8.	Si para hacer 2 tazas de chocolate hacen falta 7 onzas de la tableta, calcula cuántas tazas de chocolate salen con 25 onzas.
		
//		double a = 2.0;
//		double b = 7.0;
//		double c = 25.0;
//		
//		double d = (a/7.0)*c;
//		
//		System.out.println("Con 25 onzas de chocolate saldran: " + d + " tazas");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
