package tarea1;
import java.util.*;

public class Tarea2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		//EJERCICIO 1 - Hacer un programa que pregunte por un número con decimales. Devolverá el número con la parte entera.
		//A continuación, pedirá dos palabras. Mostrará las dos palabras unidas por un ‘y’. A continuación, el programa volverá a empezar de nuevo.
		
		
		
//		Scanner scDouble = new Scanner(System.in);
//		Scanner scLine = new Scanner(System.in);
//
//		while (true) {
//			System.out.println("Dime un nº con decimales");
//			double decimal = scDouble.nextDouble();
//			System.out.println("Tu nº sin decimales es:" + Math.floor(decimal));
//
//			System.out.println("Introduce una palabra:");
//			String palabra = scLine.nextLine();
//
//			System.out.println("Introduce otra palabra");
//			String palabra2 = scLine.nextLine();
//
//			System.out.println("Tus palabras son: " + palabra + " y " + palabra2);
//
//		}

		
		
		//EJERCICIO 2 - Hacer un programa que pregunte por el radio de una esfera (con decimales).
		//A continuación, mostrará el volumen (V= 4/3*Pi*r3) . El programa continuará hasta que se introduzca -1.
		
		
//		Scanner scDouble = new Scanner(System.in);
//		
//		while(true) {
//			
//		System.out.println("Dime el radio de una esfera, si quieres acabar el bucle introduce -1:");
//		double radio = scDouble.nextDouble();
//		if (radio != -1) {
//		double volumen = (4.0*Math.PI*(Math.pow(radio, 3))/3.0);
//		System.out.println("Volumen de la esfera: " + volumen);
//								
//		} else {
//			System.out.println("Rompiste");
//			break;
//		}
//		}
//		
//		scDouble.close();
		
		
		
		//EJERCICIO 3 - Hacer un programa donde introduzcamos una palabra y nos muestre la suma de todos los valores ASCII de los caracteres que la componen.
		
		
//		Scanner scLine = new Scanner(System.in);
//		
//		System.out.println("Dame una palabra");
//		String palabra = scLine.nextLine();
//		
//		int suma = 0;
//		
//		for (int i=0; i<palabra.length(); i++) {
//			char caracter = palabra.charAt(i);
//			int ASCII = (int) caracter;
//			
//			suma = ASCII + suma;
//			
//			System.out.println(caracter + " " + ASCII);
//			
//		}
//		
//		System.out.println("Suma ASCII de todos los caracteres: " + (suma));
		
		
		
		
		//EJERCICIO 4 - Hacer un programa que pregunte por frases y a continuación nos muestre su longitud total de caracteres (incluyendo espacios).
		// Acabará cuando se introduzca la palabra “fin” en dos preguntas seguidas.
		
		
//		Scanner scLine = new Scanner(System.in);
//
//		while (true) {
//
//			System.out.println("Dame una frase");
//			String frase = scLine.nextLine();
//
//			if (frase.equals("fin")) {
//				int longitud = frase.length();
//				System.out.println("La longitud es: " + longitud);
//				System.out.println("Seguro que desea acabar? Introduzca 'fin' para confirmar");
//				
//				String fin = scLine.nextLine();
//			if (fin.equals("fin")) {
//					System.out.println("Vaya, paraste");
//					break;
//				} else {
//					int longitud2 = fin.length();
//					System.out.println("La longitud es: " + longitud2);					
//				}
//			
//			
//			} else {
//
//				int longitud3 = frase.length();
//				System.out.println("Longitud de la frase: " + longitud3);
//			}
//
//		}
//		scLine.close();
		
		
								
				
		
		//EJERCICIO 5 - Hacer un programa que pida un número y nos muestre su parte entera y su parte decimal por separado.
		//Cuando hayamos introducido 5 números el programa parará. 
		
		
//		Scanner scDouble = new Scanner(System.in);
//		int contador = 0;
//		while (contador <= 5) {
//		contador ++;
//		
//		System.out.println("Dime un numero decimal");
//		double numero = scDouble.nextDouble();
//		System.out.println("La parte entera del nº es: " + Math.floor(numero));
//		double numero2 = numero - (int)numero;
//		System.out.println("La parte decimal del nº es: " + numero2);		
//		}
//		scDouble.close();
		
		
		
		
		//EJERCICIO 6 - Hacer un programa que pregunte por dos números enteros. Se le podrá dar el primero más bajo que el segundo o al revés.
		//A continuación, se obtendrán en una misma línea 4 números aleatorios comprendidos entre los dos números introducidos (incluidos).
		//Repetir hasta que se ponga -1 en los dos números.
		
		
//		Scanner scInt = new Scanner(System.in);
//		Random r = new Random();
//
//        while (true) {
//            System.out.println("Dame un nº entero:");
//            int numero1 = scInt.nextInt();
//
//            System.out.println("Dame un 2º nº entero (diferente al anterior):");
//            int numero2 = scInt.nextInt();
//
//            if (numero1 == -1 && numero2 == -1) {
//                System.out.println("Aquí se acaba");
//                break;
//            } else {
//                int minimo = Math.min(numero1, numero2);
//                int maximo = Math.max(numero1, numero2);
//
//                int random1 = r.nextInt(maximo - minimo + 1) + minimo;
//                int random2 = r.nextInt(maximo - minimo + 1) + minimo;
//                int random3 = r.nextInt(maximo - minimo + 1) + minimo;
//                int random4 = r.nextInt(maximo - minimo + 1) + minimo;
//
//                System.out.println("Tus números son: " + random1 + " " + random2 + " " + random3 + " " + random4 + "\n");
//            }
//        }
//
//        scInt.close();
	
		
		
		
		//EJERCICIO 7 - Hacer un programa que pida dos cosas “Hasta que número?” y “Con múltiplos de que número?
        //A continuación, mostrará un listado de los múltiplos del número introducido en segundo lugar cómo máximo hasta el número introducido en primer lugar.
        //Una vez mostrado en listado volverá a introducir mostrar la pregunta.
		
		
//		Scanner scInt = new Scanner(System.in);
//
//        while (true) {
//            System.out.println("¿Hasta qué número?");
//            int numero = scInt.nextInt();
//
//            System.out.println("¿Con múltiplos de qué número?");
//            int multiplo = scInt.nextInt();
//
//            System.out.println("\nMultiplos de " + multiplo + " hasta " + numero + ":");
//
//            for (int i = multiplo; i <= numero; i += multiplo) {
//                System.out.println(i);
//            }           
//
//        }

     
		
		
        //EJERCICIO 8 - Hacer un programa donde la máquina después de mostrar “tirada de la máquina” obtiene el resultado de tirar dos dados,
        //es decir, mostrará dos números entre 1 y 6 (incluidos).
        //A continuación, pondrá “tirada del jugador” y cuando el usuario pulse enter se obtendrán los dos dados del usuario.
        //Cada tirada la ganará el que la suma de los dados sea mayor. Se tendrá que indicar con un mensaje.
        //Cuando uno de los dos gane dos tiradas seguidas ganará y se indicará con un mensaje de quien ha ganado la partida y se acabará el juego.
		
		
//		Scanner scInt = new Scanner(System.in);
//		Random r = new Random();
//
//		int GanasTu = 0;
//		int GanaElBot = 0;
//		boolean Juego = true;
//
//		while (Juego) {
//			System.out.println("\nTirada de el BOT:");
//			int dado1Bot = r.nextInt(6) + 1;
//			int dado2Bot = r.nextInt(6) + 1;
//			int sumaBot = dado1Bot + dado2Bot;
//			System.out.println("El BOT ha sacado: " + dado1Bot + " y " + dado2Bot + " (Total: " + sumaBot + ")");
//
//			System.out.println("\nTiras tu (Pulsa Enter):");
//			scInt.nextLine();
//			int dado1Tuyo = r.nextInt(6) + 1;
//			int dado2Tuyo = r.nextInt(6) + 1;
//			int sumaTuyo = dado1Tuyo + dado2Tuyo;
//			System.out.println("Has sacado: " + dado1Tuyo + " y " + dado2Tuyo + " (Total: " + sumaTuyo + ")");
//
//			if (sumaTuyo == sumaBot) {				
//				System.out.println("¿EMPATE? Tira otra vez");
//				GanasTu = 0;
//				GanaElBot = 0;
//				continue;
//
//			}
//
//			boolean GanaJugador = sumaTuyo > sumaBot;
//
//			if (GanaJugador) {
//				GanasTu++;
//				GanaElBot = 0;
//				System.out.println("HAS GANADO LA RONDA");
//			} else {
//				GanaElBot++;
//				GanasTu = 0;
//				System.out.println("EL BOT GANA LA RONDA");
//			}
//
//			if (GanasTu == 2) {
//				System.out.println("HAS GANADO LA PARTIDA (2 Rondas seguidas) - ACABASTE.");
//				Juego = false;
//			} else if (GanaElBot == 2) {
//				System.out.println("BOT GANA OTRA VEZ - PIERDES LA PARTIDA - ACABASTE");
//				Juego = false;
//			}
//		}
//
//		scInt.close();
            
            
            
            
            
  
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
            
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
