package tarea1;

public class Tarea4y5Opcional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//1.- Obtener un listado de todos los números pares del 2 al 20.
		//RESULTADO:

//      for (int i = 2; i <= 20; i++) { 
//      if (i % 2 == 0) { 
//          System.out.println(i + " es par"); 
//      }       
//	}
		

		//2.- Obtener un listado con los números del 1 al 10. En la posición del cinco en lugar de salir el número ha de salir la palabra ‘CINCO’.
		//RESULTADO:

//		int suma = 1;
//
//		while (suma <= 10) {
//		    if (suma == 5) {
//		        System.out.println("CINCO");
//		    } else {
//		        System.out.println(suma);
//		    }
//		    suma += 1;
//		}

		//3.- Obtener un listado de todos los números del -30 al 30. Los números que se encuentren entre 0 y 8 sólo aparecerán los pares.
		//RESULTADO:

//		for (int i = -30; i <= 30; i++) {
//		    if (i >= 0 && i <= 8 && i % 2 != 0) {
//		        continue; 
//		    }
//		    System.out.println(i + " ");
//		}

		//4.- Sin utilizar la sentencia FOR sacar un listado de todos los números impares del 7 al 21.
		//RESULTADO:

//		int i = 7;
//		while (i <= 21) {
//		    if (i % 2 != 0) {
//		        System.out.println(i + " ");
//		    }
//		    i++;
//		}

		//5.- Obtener un listado de todos los números del 1 al 100 que contengan un 8
		//RESULTADO:

//		for (int i = 1; i <= 100; i++) {
//		    int numero = i % 10;    
//		    int numero2 = i / 10;      
//
//		    if (numero == 8 || numero2 == 8) {
//		        System.out.println(i + " ");
//		    }
//		}
		
		
		//6.- Obtener un listado de todos los números múltiplos de 4 entre 4 y 40.
		//RESULTADO:

//		for (int i = 4; i <= 40; i += 4) {
//		    System.out.println(i + " ");
//		}
		

		//7.- Sin utilizar la sentencia FOR hacer un listado de 10 al -10 seguido a continuación de otro de -10 a 10.
		//RESULTADO:

//		int i = 10;
//		while (i >= -10) {
//		    System.out.println(i);
//		    i--;
//		}
//
//		i = -10;
//		while (i <= 10) {
//		    System.out.println(i);
//		    i++;
//		}
		
		//8.- Obtener un listado de los números pares entre -20 y 0 y a partir del 0 un listado de los números impares entre 1 y 21.
		//RESULTADO:

//		for (int i = -20; i <= 0; i++) {
//		    if (i % 2 == 0) {
//		        System.out.println(i);
//		    }
//		}
//		for (int i = 1; i <= 21; i++) {
//		    if (i % 2 != 0) {
//		        System.out.println(i);
//		    }
//		}

	
		//9.- Obtener la suma de todos los números entre 5 y 15.
		//RESULTADO:

//		int suma = 0;
//		for (int i = 5; i <= 15; i++) {
//		    suma += i;
//		}
//		System.out.println("Suma total: " + suma);
		
		
		//10.- Obtener la suma de todos los números impares entre 3 y 21 exceptuando el 13 y el 17.
		//RESULTADO:

//		int suma = 0;
//		for (int i = 3; i <= 21; i++) {
//		    if (i % 2 != 0 && i != 13 && i != 17) {
//		        suma += i;
//		    }
//		}
//		System.out.println("Suma total: " + suma);
		
		
//------------------------------------------------------------------------------------------------------------------------------------------------------
		
		//SEGUNDA PARTE
		
		
		//1.- Obtener un listado con todos los múltiplos de 5 entre 5 y 50.

//		for (int i = 5; i <= 50; i += 5) {
//		    System.out.println(i);
//		}
		
		//2.- Crear una lista con todos los números pares entre -20 y 0 seguida de todos los números impares entre 1 y 21.

//		for (int i = -20; i <= 0; i++) {
//		    if (i % 2 == 0) System.out.println(i);
//		}
//		for (int i = 1; i <= 21; i++) {
//		    if (i % 2 != 0) System.out.println(i);
//		}
		
		//3.- Obtener un listado de 1 a 20. En cada número múltiplo de 3 además del número pondrá el texto: ‘Múltiplo de tres’.

//		for (int i = 1; i <= 20; i++) {
//		    if (i % 3 == 0)
//		        System.out.println(i + " Es multiplo de 3");
//		    else
//		        System.out.println(i);
//		}
		
		//4.- Obtener la suma de todos los números múltiplos de 3 entre 3 y 99.

//		int suma = 0;
//		for (int i = 3; i <= 99; i += 3) {
//		    suma += i;
//		}
//		System.out.println("Suma total: " + suma);
		
		//5.- Sin utilizar FOR obtener un listado de todos los números entre 0 y 50 que acaben en el 2 o el 3.

//		int i = 0;
//		while (i <= 50) {
//		    int unidades = i % 10;
//		    if (unidades == 2 || unidades == 3) {
//		        System.out.println(i);
//		    }
//		    i++;
//		}
		
		//6.-  Mostrar la frase: “listado entre 1 y 10” y a continuación mostrar este listado.
		//A continuación mostrar la frase “listado entre 30 y 40 y a continuación mostrar ese listado.

//		System.out.println("Entre 1 y 10:");
//		for (int i = 1; i <= 10; i++) {
//		    System.out.println(i);
//		}
//
//		System.out.println("\n\nEntre 30 y 40:");
//		for (int i = 30; i <= 40; i++) {
//		    System.out.println(i);
//		}
		
		//7.- Obtener la suma de todos los números impares entre 0 y 100. Obtener la suma de todos los múltiplos de 4 entre 0 y 50.
		//Mostrar la resta de las dos cantidades anteriores.

//		int sumaImpares = 0, sumaMultiplos4 = 0;
//
//		for (int i = 0; i <= 100; i++) {
//		    if (i % 2 != 0) sumaImpares += i;
//		}
//		for (int i = 0; i <= 50; i++) {
//		    if (i % 4 == 0) sumaMultiplos4 += i;
//		}
//
//		int resta = sumaImpares - sumaMultiplos4;
//		System.out.println("Resta: " + resta);
		
		//8.- Mostrar la suma de todos los números impares entre -30 y 35.

//		int suma = 0;
//		for (int i = -30; i <= 35; i++) {
//		    if (i % 2 != 0) suma += i;
//		}
//		System.out.println("Suma total: " + suma);
		
		//9.- Una serie empieza por los números 0, 1, 3. El siguiente numero de la serie se calcula con la suma de los últimos tres últimos y así sucesivamente.
		//Calcular los 25 primeros números de la serie.

//		int a = 0, b = 1, c = 3;
//		 System.out.println(a);
//		 System.out.println(b);
//		 System.out.println(c);
//
//		for (int i = 4; i <= 25; i++) {
//		    int siguiente = a + b + c;
//		    System.out.println(siguiente);
//		    a = b;
//		    b = c;
//		    c = siguiente; 
//		}
		
		//10.- Obtener todos los números primos entre 1 y 400.

//		for (int i = 2; i <= 400; i++) {
//		    boolean primos = true;
//
//		    for (int j = 2; j <= Math.sqrt(i); j++) {
//		        if (i % j == 0) {
//		            primos = false;        
//		            break;
//		        }
//		    }
//
//		    if (primos) {
//		        System.out.println(i);
//		    }
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
