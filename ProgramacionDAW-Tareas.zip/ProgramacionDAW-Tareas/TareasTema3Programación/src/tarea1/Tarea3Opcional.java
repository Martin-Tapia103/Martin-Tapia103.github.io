package tarea1;
import java.util.*;

public class Tarea3Opcional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//EJERCICIO 1.- Generar en una línea horizontal un listado de 3 números aleatorios entre 0 y 30 todos diferentes. Repetir cada vez que se pulse enter.

//		Scanner scInt = new Scanner(System.in);
//		Random r = new Random();
//
//		while (true) {
//
//			int numero = r.nextInt(30) + 1;
//			int numero2 = r.nextInt(30) + 1;
//			int numero3 = r.nextInt(30) + 1;
//
//			while (numero2 == numero) {
//				numero2 = r.nextInt(30) + 1;
//			}
//			while (numero3 == numero || numero3 == numero2) {
//				numero3 = r.nextInt(30) + 1;
//			}
//
//			System.out.print(numero + " " + numero2 + " " + numero3);
//			System.out.println("\nPULSA ENTER PARA SEGUIR");
//
//			scInt.nextLine();
//		}


		//EJERCICIO 2.- Hacer un programa que pida dos números.
		//A continuación cada vez que pulsemos la tecla enter muestre el primero elevado al segundo hasta que el valor mayor de 1.000.000, momento en el que el programa acabará. 

//        Scanner scDouble = new Scanner(System.in);
//
//        System.out.println("Introduce un nº: ");
//        double numero = scDouble.nextDouble();
//
//        System.out.println("Introduce un segundo nº (Al que se elevara)");
//        int potencia = scDouble.nextInt();
//
//        scDouble.nextLine();
//        
//        for (double resultado = Math.pow(numero, potencia); resultado <= 1000000; potencia++, resultado = Math.pow(numero, potencia)) {
//            System.out.println(numero + " elevado a " + potencia + ": " + resultado);
//
//            System.out.println("ENTER para seguir");
//            scDouble.nextLine();
//        }
//
//        System.out.println("Esto ya pasa del millon");
//
//        scDouble.close();
		
		
		
		
		//EJERCICIO 3.- Hacer un programa que pregunte por una frase
		//A continuación mostrarla partida aleatoriamente por tres partes de igual o diferente longitud. Repetir indefinidamente hasta que se introduzca fin.

//		Scanner scLine = new Scanner(System.in);
//		Random r = new Random();
//
//		while (true) {
//			System.out.println("DAME LA FRASE");
//			String frase = scLine.nextLine();
//
//			if (frase.equalsIgnoreCase("fin")) {
//				System.out.println("SE ACABO");
//				break;
//			}
//
//			if (frase.length() < 3) {
//				System.out.println("UNA FRASE NO UNA PALABRA");
//				continue;
//			}
//
//			int r2 = r.nextInt(frase.length() - 1) + 1;
//			int r3 = r.nextInt(frase.length() - 1) + 1;
//
//			while (r3 == r2) {
//				r3 = r.nextInt(frase.length() - 1) + 1;
//			}
//
//			int TROZO1 = Math.min(r2, r3);
//			int TROZO2 = Math.max(r2, r3);
//
//			String TrozoAleatorio = frase.substring(0, TROZO1);
//			String TrozoAleatorio2 = frase.substring(TROZO1, TROZO2);
//			String TrozoAleatorio3 = frase.substring(TROZO2);
//
//			System.out.println("Trozos de frase: ");
//			System.out.println("1: " + TrozoAleatorio);
//			System.out.println("2: " + TrozoAleatorio2);
//			System.out.println("3: " + TrozoAleatorio3);
//		}
//
//		scLine.close();
		
		
		
		
		
		//EJERCICIO 4.- Hacer un programa que nos pregunte un número entero
		//A continuación nos muestre un String formado por una cantidad de letras minúsculas aleatorias similar de la misma longitud que el número inicial introducido. Repetir hasta que se introduzca -1.

		
//		Scanner scInt = new Scanner(System.in);
//        Scanner scLine = new Scanner(System.in);
//        Random r = new Random();
//
//        while (true) {
//            System.out.println("DAME UN Nº ENTERO:");
//            int numero = scInt.nextInt();
//
//            if (numero == -1) {
//                System.out.println("AQUI SE ACABA");
//                break;
//            }
//
//            if (numero == -1) {
//                System.out.println("-1 Pa salir");
//                continue;
//            }
//
//            String resultado = "";
//
//            for (int i = 0; i < numero; i++) {
//                char letra = (char) ('a' + r.nextInt(26));
//                resultado = resultado + letra;
//            }
//
//            System.out.println("Resultado: " + resultado);
//
//        }
//
//        scInt.close();
//        scLine.close();
		
		
		
		
		
		//EJERCICIO 5.- Hacer un programa que pregunte por un número inicial. A continuación, dirá: “multiplicar por?”.
		// Introduciremos un número y obtendrá la multiplicación del número inicial por ese número. A continuación, dirá: “dividir por?”. 
		// Introduciremos otro número y obtendrá la división del número anterior por ese número. 
		//Y de ese modo seguirá alternando entre multiplicar y dividir hasta que introduzcamos un 0 en cualquier momento, que será cuando el programa acabe.
		
		
//		Scanner scDouble = new Scanner(System.in);
//
//        System.out.println("Introduce un nº: ");
//        double resultado = scDouble.nextDouble();
//
//        while (true) {
//            System.out.println("Multiplicar por?: ");
//            double multiplicacion = scDouble.nextDouble();
//
//            if (multiplicacion == 0) {
//                System.out.println("Se acabo");
//                break;
//            }
//
//            resultado = resultado * multiplicacion;
//            System.out.println("Resultado actual: " + resultado);
//
//            System.out.println("Dividir por?: ");
//            double division = scDouble.nextDouble();
//
//            if (division == 0) {
//                System.out.println("Programa terminado.");
//                break;
//            }
//
//            resultado = resultado / division;
//            System.out.println("Resultado: " + resultado);
//        }
//
//        scDouble.close();

		
	
		
		//EJERCICIO 6.- Preguntar por un número que tenga muchos decimales. A continuación, preguntar si se redondea con 1, 2 o 3 decimales.
		// Se devolverá el número redondeado con estos decimales. 
		//Si a la pregunta de cuantos decimales de introduce algo diferente de 1, 2 o 3 
		//dirá que el número introducido no es válido y volverá a hacer esta segunda pregunta.

//		 Scanner scDouble = new Scanner(System.in);
//
//	        System.out.println("Introduce un nº: ");
//	        double numero = scDouble.nextDouble();
//
//	        int decimales;
//
//	        while (true) {
//	            System.out.println("Nº de decimales?: ");
//	            decimales = scDouble.nextInt();
//
//	            if (decimales == 1 || decimales == 2 || decimales == 3) {
//	                break; 
//	            } else {
//	                System.out.println("No es 1 2 o 3");
//	            }
//	        }
//
//	        double factor = Math.pow(10, decimales);
//	        double redondeado = Math.round(numero * factor) / factor;
//
//	        System.out.println("Nª redondeado a " + decimales + " decimales: " + redondeado);
//
//	        scDouble.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
