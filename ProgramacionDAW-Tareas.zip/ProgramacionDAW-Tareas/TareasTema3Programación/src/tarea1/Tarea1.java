package tarea1;

public class Tarea1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	//EJERCICIO 1 - Obtener una lista de números entre el 0 y el 100. En cada cambio de decena se ha de imprimir el mensaje:
	//‘Cambio de decena’. Es decir, ha de aparecer el mensaje en lugar del 10, del 20, del 30…etc.	
		

//	int listado = 0;
//	
//	while(listado<=100) {
//		if (listado % 10 == 0 & listado !=0) {
//			System.out.println("Cambio de decena");
//		}else {
//			System.out.println(listado);
//		}
//		listado+=1;
//	}
		    
	
		
		
		//EJERCICIO 2 - Sumar todos los números consecutivamente 1 + 2 + 3 + 4... etc.
		//Cuando la suma anterior sea mayor de 40 obtener cual ha sido el último número sumado.
			
//		int suma = 0;
//		int contador = 0;
//		
//		while(suma < 40) {
//		contador++;
//		suma = suma + contador;
//		System.out.println("[while] suma " + suma + " sumo: " + contador);
//		
//		}
//		System.out.println("Suma: " + suma);
//		System.out.println("Contador: " + contador); 
		
		
		
		//EJERCICIO 3 - Hacer el siguiente listado: en primer lugar 2. En segundo lugar el resultado de 2*2. 
		//En tercer lugar el resultado de 2*2*2 y así consecutivamente hasta que multipliquemos 2 por si mismo 10 veces.
		
		
//		int numero = 2;
//		for (int i = 1; i <= 10; i++) {
//			System.out.println(numero);
//			numero*=2;
//		}
		
		
		
		//EJERCICIO 4 - Utilizando la estructura DO-WHILE obtener un listado de los números pares del 22 al 48.
		
//		int pares = 22;
//		
//		do {
//			System.out.println("Es par " + pares);
//			pares += 2;
//					
//		}while (pares <=48);
		
		
		
		
		//EJERCICIO 5 - Obtener cuantas veces hay que sumar 0,48 (0,48 + 0,48 + 0,48…etc) para sobrepasar el valor de 23,4.
		
//		double suma = 0;
//		int contador = 0;
//
//		while (suma <= 23.4) {
//		    suma += 0.48; 
//		    contador++;  
//		    System.out.println("Hay que sumar 0.48 " + contador + " veces");
//		}
//
//		System.out.println("Suma final: " + suma);
		
		
		
		
		//EJERCICIO 6 - Obtener la suma de todos los números impares desde -21 a -9 más la suma de todos los elementos pares de 14 a 64.
		
//		int pares = 14;
//		int impares = -21;
//		int sumaPares = 0;
//		int sumaImpares = 0;
//
//	
//		do {
//		    sumaPares += pares;
//		    System.out.println("Par: " + pares);
//		    pares += 2;
//		} while (pares <= 64);
//
//		System.out.println("Suma de pares = " + sumaPares);
//		System.out.println("\n");
//
//
//		do {
//		    sumaImpares += impares;
//		    System.out.println("Impar: " + impares);
//		    impares += 2;
//		} while (impares <= -9);
//
//		System.out.println("Suma de impares = " + sumaImpares);
//		System.out.println("\n");
//		
//		int SumaTotal = sumaPares + sumaImpares;
//		System.out.println("Suma total: " + SumaTotal);
		
		
		
		//EJERCICIO 7 - Obtener el resultado de dividir 4096 entre 2, a continuación entre 3, a continuación entre 4 y así consecutivamente hasta 8. 
		//Hacerlo empleando la sentencia WHILE.
	
		
//		double division = 4096;
//		double contador = 1;
//		
//		while (contador <=8) {
//			contador +=1;
//			division = division / contador;
//			System.out.println("[While] numero: " + division + " dividido entre " + contador);
//		}
		
		
		
		
		//EJERCICIO 8 - Crear una lista de números múltiplos de 6 entre 6 y 60.
		//De modo que cada número esté al lado del siguiente y separado por un espacio (no en una fila de arriba hacia abajo).
		
		
//		for (int i = 6; i <= 60; i+=6) {
//			System.out.print(i + " ");
//		}
//	
		
		
		// EJERCICIO CLASE - Programa que calcula la sequencia Fibonacci hasta el 100
		
//		int numero1 = 0;   
//		int numero2= 1;   
//		int suma;
//
//		System.out.println("Finbonacci hasta el 100");
//		System.out.println(numero1);
//
//		while (true) {
//		    suma = numero1 + numero2;
//		    if (suma > 100) {
//		        break;
//		    }
//		    System.out.println(suma);
//		    numero1 = numero2;
//		    numero2 = suma;
//		}
		
		
		// EJERCICIO CLASE - Programa que calcule los nº primos hasta 200
		
//        for (int numero = 2; numero <= 200; numero++) {
//            boolean EsPrimo = true;
//
//            
//            for (int divisor = 2; divisor <= Math.sqrt(numero); divisor++) {
//                if (numero % divisor == 0) {
//                    EsPrimo = false;
//                    break;
//                }
//            }
//
//            if (EsPrimo) {
//                System.out.println(numero);
//            }
//        }
		
		
        
		//EJERCICIO CLASE - finacci que empieze con 0 1 1 y el nuevo sea la suma de los 3 ultimos hasta el 100
		
//		int numero1 = 0;   
//		int numero2= 1;
//		int numero3 = 1;
//		int suma;
//
//		System.out.println("Finbonacci hasta el 100 sumando los tres anteriores");
//		System.out.println(numero1);
//
//		while (true) {
//		    suma = numero1 + numero2 + numero3;
//		    if (suma > 100) {
//		        break;
//		    }
//		    System.out.println(suma);
//		    numero1 = numero2;
//		    numero2 = numero3;
//		    numero3 = suma;
//		    
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
