package tarea1;
import java.util.*;

public class Tarea1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//EJERCICIO 1 - Escribe un programa en Java que pida al usuario dos números enteros y muestre su suma.
		//El programa debe usar un bloque try-with-resources con Scanner para gestionar la entrada de datos.
		//Si el usuario introduce un valor no válido (por ejemplo, texto en lugar de número), el programa debe mostrar un mensaje de error.

					
//		try (Scanner scInt = new Scanner(System.in)) {
//			
//				System.out.println("Introduce el primer nº entero");
//				int numero = scInt.nextInt();
//				
//				System.out.println("Introduce otro número");				
//				int numero2 = scInt.nextInt();
//				
//				int suma = numero + numero2;
//				System.out.println("La suma es: " + suma);
//		
//		} catch (Exception e) {
//			
//			System.out.println("No has introducido un número entero, vuelve a intentar");
//		}
		
	
		
		//EJERCICIO 2 - 2. Crea un programa en Java que pida al usuario que introduzca un número en forma de texto 
		//(por ejemplo: "123" o "3.14") y lo convierta a número para mostrarlo en pantalla.
		//El programa debe usar un bloque try-with-resources con Scanner para gestionar la entrada de datos.
		//•  Usa Scanner para leer el texto con nextLine().
		//•  Convierte el texto a número con Double.parseDouble().


//        try (Scanner scLine = new Scanner(System.in)) {
//
//            System.out.println("Introduce un número en forma de texto: ");
//            String NumeroTexto = scLine.nextLine();
//
//            double numero = Double.parseDouble(NumeroTexto);
//
//            System.out.println("Número convertido: " + numero);
//
//        } catch (Exception e) {
//            System.out.println("Eso no es un número");
//        }
		
		
		
		//3.- Escribe un programa en Java que pida al usuario una palabra y un número N,
		//y muestre una abreviatura formada por los N primeros caracteres de la palabra.
		//El programa debe controlar los siguientes errores:
		//•	Si el usuario introduce un número mayor que la longitud de la palabra o menor que 1 → captura StringIndexOutOfBoundsException.
		//•	Si introduce algo que no sea un número entero → captura InputMismatchException.

		
//		 try (Scanner scInt = new Scanner(System.in);
//					Scanner scLine = new Scanner(System.in);) { 
//
//	            System.out.println("Introduce una palabra: ");
//	            String palabra = scLine.nextLine();
//
//	            System.out.println("Introduce un número: ");
//	            int numero = scInt.nextInt();
//
//	            String abreviatura = palabra.substring(0, numero);
//	            System.out.println("Abreviatura: " + abreviatura);
//
//	        } catch (StringIndexOutOfBoundsException e) {
//	            System.out.println("Eso es inferior o supera las letras de la palabra");
//	        } catch (InputMismatchException e) {
//	            System.out.println("Eso no es un nº entero");
//	        }

		
		
		//4.- Escribe un programa en Java que solicite al usuario que introduzca dos números enteros por teclado
		//y muestre por pantalla el resultado de su división.
//		El programa debe cumplir las siguientes condiciones:
//			1.	Utiliza la clase Scanner para leer los valores introducidos por el usuario.
//			2.	Usa un bloque try-catch para capturar posibles excepciones:
//			o	InputMismatchException si el usuario introduce un valor que no sea un número entero.
//			o	ArithmeticException si intenta dividir entre cero.
//			3.	En caso de que ocurra una excepción, el programa debe mostrar un mensaje de error apropiado y permitir al usuario volver a intentarlo.
//			4.	El programa debe finalizar correctamente mostrando el resultado de la división cuando la operación se haya realizado sin errores.

		
//		try (Scanner scInt = new Scanner(System.in)) {
//
//            System.out.println("Introduce el primer nº: ");
//            int numero = scInt.nextInt();
//
//            System.out.println("Introduce el segundo nº: ");
//            int numero2 = scInt.nextInt();
//
//            int resultado = numero / numero2;
//
//            System.out.println("Resultado: " + resultado);
//
//        } catch (InputMismatchException e) {
//            System.out.println("Introduce un nº entero");
//        } catch (ArithmeticException e) {
//            System.out.println("No dividas entre 0");
//        }
		
		
		
		//5.- Desarrolla un programa en Java que funcione como una calculadora simple.
		//El programa debe:
			//1.	Pedir al usuario dos números decimales.
			//2.	Pedirle que introduzca una operación: suma (+), resta (-), multiplicación (*) o división (/). Implementar switch para hacer esto.
			//3.	Mostrar el resultado de la operación.
			//4.	Controlar los siguientes errores mediante try-catch:
			//o	InputMismatchException si el usuario introduce algo que no sea un número.
			//o	ArithmeticException si intenta dividir entre cero.
			//o	Cualquier otro error (por ejemplo, símbolo de operación incorrecto) debe mostrar un mensaje genérico.

		
//        try (Scanner scInt = new Scanner(System.in);
//        		Scanner scLine = new Scanner(System.in);) {
//
//            System.out.println("Introduce un nº: ");
//            int numero = scInt.nextInt();
//
//            System.out.println("Introduce un segundo nº: ");
//            int numero2 = scInt.nextInt();
//
//            System.out.println("Introduce + - * /: ");
//            String operacion = scLine.nextLine();
//
//            double resultado;
//
//            switch (operacion) {
//                case "+":
//                    resultado = numero + numero2;
//                    System.out.println("Resultado: " + resultado);
//                    break;
//
//                case "-":
//                	resultado = numero - numero2;
//                    System.out.println("Resultado: " + resultado);
//                    break;
//
//                case "*":
//                	resultado = numero * numero2;
//                    System.out.println("Resultado: " + resultado);
//                    break;
//
//                case "/":
//                	resultado = numero / numero2; 
//                    System.out.println("Resultado: " + resultado);
//                    break;
//                    
//                default:
//                    System.out.println("ESO NO ES UNA OPERACIÓN");
//            }
//
//        } catch (InputMismatchException e) {
//            System.out.println("SOLO NUMEROS ENTEROS");
//        } catch (ArithmeticException e) {
//            System.out.println("NO DIVIDAS ENTRE 0");
//		
//        }
		
		
		
		//6.- Crea un programa en Java que pida al usuario introducir números enteros uno a uno.
				//El programa debe seguir pidiendo números hasta que el usuario escriba “fin”.
				//Al terminar, mostrará:
				//•	La cantidad de números válidos introducidos.
				//•	La suma total de esos números.
				//•	El promedio (media) de los números introducidos.
				//Si el usuario escribe algo que no sea un número ni “fin”, el programa mostrará un mensaje de error, pero continuará pidiendo más valores.
				//Ejemplo: 
				//Introduce números enteros (escribe 'fin' para terminar):
				//10
				//5
				//hola
				//Error: 'hola' no es un número válido.
				//3
				//fin

				//Has introducido 3 números válidos.
				//Suma total: 18
				//Promedio: 6.0

//				try (Scanner scLine = new Scanner(System.in)) {
		//
//					while (true) {
//						int contador = 0;
//						int suma = 0;
		//
//						while (contador < 1) {
//							System.out.println("Introduce el primer nª: ");
//							String siguiente = scLine.nextLine().trim();
		//
//							if (siguiente.equalsIgnoreCase("fin")) {
//								System.out.println("Se acabo");
//								return;
//							}
		//
//							try {
//								int numero = Integer.parseInt(siguiente);
//								suma += numero;
//								contador++;
//							} catch (NumberFormatException e) {
//								System.out.println("Error: '" + siguiente + "' no es un número válido.");
//							}
//						}
		//
//						while (contador < 2) {
//							System.out.println("Introduce el segundo nº: ");
//							String siguiente2 = scLine.nextLine().trim();
		//
//							if (siguiente2.equalsIgnoreCase("fin")) {
//								System.out.println("Programa terminado.");
//								return;
//							}
		//
//							try {
//								int numero2 = Integer.parseInt(siguiente2);
//								suma += numero2;
//								contador++;
//							} catch (NumberFormatException e) {
//								System.out.println("Error: '" + siguiente2 + "' no es un número válido.");
//							}
//						}
		//
//						while (contador < 3) {
//							System.out.println("Introduce el tercer nº: ");
//							String siguiente3 = scLine.nextLine().trim();
		//
//							if (siguiente3.equalsIgnoreCase("fin")) {
//								System.out.println("Programa terminado.");
//								return;
//							}
		//
//							try {
//								int numero3 = Integer.parseInt(siguiente3);
//								suma += numero3;
//								contador++;
//							} catch (NumberFormatException e) {
//								System.out.println("Error: '" + siguiente3 + "' no es un número válido.");
//							}
//						}
		//
//						double promedio = (double) suma / contador;
//						System.out.println("\nHas introducido " + contador + " números válidos.");
//						System.out.println("Suma total: " + suma);
//						System.out.println("Promedio: " + promedio);
//					}
//				}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
