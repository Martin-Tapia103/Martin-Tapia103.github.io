package ejercicios2Multi;

import java.util.Arrays;

public class EjerciciosArraysMultis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1.- Multiplicar todas las posiciones del siguiente array por 5 y obtener el array solución:
		//{{1, 2, 3}, {4, 5}, {3, 2, 1, 0}}
		
		int a[][] = {{1, 2, 3}, {4, 5}, {3, 2, 1, 0}};
		int resultado[][] = new int[a.length][];

		for (int i = 0; i < a.length; i++) {
		    resultado[i] = new int[a[i].length];
		    for (int j = 0; j < a[i].length; j++) {
		        resultado[i][j] = a[i][j] * 5;
		    }
		}
		
		System.out.println(Arrays.deepToString(resultado));
		
		
		
		//2.- Obtener la cifra del resultado de sumar todos los valores del siguiente array:
		//{{1, 1, 1, 1,}, {2, 2, 2, 2}, {3, 4, 5, 6}}
		
		
		int b[][] = {{1, 1, 1, 1}, {2, 2, 2, 2}, {3, 4, 5, 6}};
		int suma = 0;

		for (int i = 0; i < b.length; i++) {
		    for (int j = 0; j < b[i].length; j++) {
		        suma += b[i][j];
		    }
		}

		System.out.println(suma);

		
		
		//3.- Sumar todas las posiciones de los tres arrays siguientes y obtener el array resultado:
		//{{1, 2, 3, 2, 1}, {1, 1}}
		//{{3, 2, 1, 2, 3}, {2, 2}}
		//{{2, 2, 2, 2, 2}, {0, 0}}
		
		int a1[][] = {{1, 2, 3, 2, 1}, {1, 1}};
		int a2[][] = {{3, 2, 1, 2, 3}, {2, 2}};
		int a3[][] = {{2, 2, 2, 2, 2}, {0, 0}};

		int resultado1[][] = new int[a1.length][];

		for (int i = 0; i < a1.length; i++) {
		    resultado1[i] = new int[a1[i].length];
		    for (int j = 0; j < a1[i].length; j++) {
		        resultado1[i][j] = a1[i][j] + a2[i][j] + a3[i][j];
		    }
		}

		System.out.println(Arrays.deepToString(resultado1));

		
		//4.- En un array bidimensional donde se asegura que solo hay un cero, averiguar en que posiciones i, j está el cero. Hacerlo con el siguiente array:
		//{{3, 5, 8, 9}, {4, 12, 14, 10}, {0, 2, 20, 5}};
		
		int c[][] = {{3, 5, 8, 9}, {4, 12, 14, 10}, {0, 2, 20, 5}};

		int posI = 0;
		int posJ = 0;

		for (int i = 0; i < c.length; i++) {
		    for (int j = 0; j < c[i].length; j++) {
		        if (c[i][j] == 0) {
		            posI = i;
		            posJ = j;
		        }
		    }
		}

		System.out.println("i=" + posI + ", j=" + posJ);

		
		
		
		//5.- Obtener cual es el valor más alto de un array bidimensional donde nunca va a haber valores negativos. Hacerlo con el siguiente array
		//{{3, 5, 8, 9}, {4, 12, 14, 10}, {0, 2, 20, 5}};
		
		int d[][] = {{3, 5, 8, 9}, {4, 12, 14, 10}, {0, 2, 20, 5}};
		int mayor = d[0][0];

		for (int i = 0; i < d.length; i++) {
		    for (int j = 0; j < d[i].length; j++) {
		        if (d[i][j] > mayor) {
		            mayor = d[i][j];
		        }
		    }
		}

		System.out.println(mayor);

		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
