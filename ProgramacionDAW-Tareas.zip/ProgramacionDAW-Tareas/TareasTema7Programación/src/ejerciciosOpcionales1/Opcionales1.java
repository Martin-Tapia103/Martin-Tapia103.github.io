package ejerciciosOpcionales1;

import java.util.Arrays;

public class Opcionales1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//1-1.- Partiendo de dos arrays de cualquier longitud y que pueden ser de longitud diferente crear un tercer array con las posiciones intercaladas
		//de los dos primeros, cuando se hayan acabado las posiciones de un array se pondrán a continuación las posiciones del otro. 
		//Por ejemplo {1, 2, 3} y {4, 5, 6, 7, 8} daría como resultado {1, 4, 2 , 5, 3, 6, 7, 8}.
		//Probarlo con {4, 7, 4, 7, 3, 23, -4, 12, 6} y {5, 7, 8, 9, 10}

		
//		 	int arrayA[] = {4, 7, 4, 7, 3, 23, -4, 12, 6};
//	        int arrayB[] = {5, 7, 8, 9, 10};
//
//	        int resultado[] = new int[arrayA.length + arrayB.length];
//
//	        int i = 0, x = 0, z = 0;
//
//	        while (x < arrayA.length || z < arrayB.length) {
//	            if (x < arrayA.length) {
//	                resultado[i++] = arrayA[x++];
//	            }
//	            if (z < arrayB.length) {
//	                resultado[i++] = arrayB[z++];
//	            }
//	        }
//
//	        System.out.println(Arrays.toString(resultado));
		
		
		
		//2.- Sumar 3 arrays de longitud diferentes. El array solución será del tamaño del array más grande, 
	        //y en las posiciones que no existan de los arrays más cortos se considererá que hay un 0.
	        //Probarlo con {4, 7, 9, -6, 5}, {5, 7, 1, 7, 2, 7, 23}, {5, 6, 10}

		
//	        int a[] = {4, 7, 9, -6, 5};
//	        int b[] = {5, 7, 1, 7, 2, 7, 23};
//	        int c[] = {5, 6, 10};
//
//	        int maximo = Math.max(a.length, Math.max(b.length, c.length));
//	        int resultado[] = new int[maximo];
//
//	        for (int i = 0; i < maximo; i++) {
//	            if (i < a.length) resultado[i] += a[i];
//	            if (i < b.length) resultado[i] += b[i];
//	            if (i < c.length) resultado[i] += c[i];
//	        }
//
//	        System.out.println(Arrays.toString(resultado));
		
		
		
		//3.- Dado un array con elementos entre -3 y 3 (cero incluido) obtener un array solución de la siguiente manera.
		//- Un -3 se transforma en tres -3
		//- Un -2 se transforma en dos -2
		//- Un -1 se transforma en un -1
		//- Un 1 se transforma en un 1
		//- Un 2 se transforma en dos 2
		//- Un 3 se transforma en tres 3
		//Cualquier valor diferente de los anteriores desaparece.

		//Ejemplo, el array {-2,0, 3, 5, 2} daría : {-2,-2, 3, 3, 3, 2, 2}.

		//Probarlo con {2, -3, 0, 1, 2, -2} 

		
//        int array[] = {2, -3, 0, 1, 2, -2};
//
//        int tamaño = 0;
//        for (int n : array) {
//            if (n >= -3 && n <= 3 && n != 0) {
//                tamaño += Math.abs(n);
//            }
//        }
//
//        int resultado[] = new int[tamaño];
//        int x = 0;
//
//        for (int n : array) {
//            if (n >= -3 && n <= 3 && n != 0) {
//                for (int i = 0; i < Math.abs(n); i++) {
//                    resultado[x++] = n;
//                }
//            }
//        }
//
//        System.out.println(Arrays.toString(resultado));
		
		
		
		
		// 4.- declarar un int a= valor inicial, int b=valor final;
		//Para cualquier array obtener el subarray que se encuentra entre la posición del valor a más a la izquierda y el valor de la posición b más a la derecha.

		//Ejemplo, con a= 4, y b = 1 y el array { 3, 6, 4, 6, 8, 1, 6, 9, 10} la solución será {4, 6, 8,1}

		//Si no se da la condiciones de que haya a o b en el array, 
		//o b está más a la izquierda que a deberá de indicarlo mediante un mensaje y no resolver el array solución.

//        int array[] = {3, 6, 4, 6, 8, 1, 6, 9, 10};
//        int a = 4;
//        int b = 1;
//
//        int posA = -1;
//        int posB = -1;
//    
//        for (int i = 0; i < array.length; i++) {
//            if (array[i] == a && posA == -1) {
//                posA = i;
//            }
//            if (array[i] == b) {
//                posB = i;
//            }
//        }
//
// 
//        if (posA == -1 || posB == -1 || posB < posA) {
//            System.out.println("No hay a ni b");
//        } else {
//
//            int tamaño = posB - posA + 1;
//            int[] resultado = new int[tamaño];
//
//            int x = 0;
//            for (int i = posA; i <= posB; i++) {
//                resultado[x++] = array[i];
//            }
//
//            System.out.println(Arrays.toString(resultado));
//        }

        	
		
	}

}
