package tareaGranjaClases;

public class Cerdos extends Animales {

	
	//ATRIBUTOS -------------------------------------
	
	private String colorDePiel;
	
	
	
	//CONSTRUCTORES ---------------------------------
	
	public Cerdos() {
		super();
	}
	

	public Cerdos(String nombre, double peso, int edad, String colorDePiel) {
		super(nombre, peso, edad);
		this.colorDePiel = colorDePiel;
	}



	//GETTERS Y SETTERS ------------------------------

	public String getColorDePiel() {
		return colorDePiel;
	}

	public void setColorDePiel(String colorDePiel) {
		this.colorDePiel = colorDePiel;
	}

	@Override
	public void tipoAnimal() {
		// TODO Auto-generated method stub
		System.out.println(" es cerdo");
	}
	
	//TO STRING--------------------------------------
	
	@Override
	public String toString() {
		return nombre + ": Peso" + peso + "kg, edad: " + edad + " anyos" + " color piel: " + colorDePiel;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
