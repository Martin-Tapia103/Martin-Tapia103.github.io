package tareaGranjaClases;

public class Ovejas extends Animales {

	
	
	//ATRIBUTOS -----------------------------------
	
	private String tipoDePelo;

	
	
	//CONSTRUCTORES -------------------------------
		
	public Ovejas() {
		super();
	}
	
	public Ovejas(String nombre, double peso, int edad, String tipoDePelo) {
		super(nombre, peso, edad);
		this.tipoDePelo = tipoDePelo;
	}



	//GETTERS Y SETTERS ---------------------------
	
	public String getTipoDePelo() {
		return tipoDePelo;
	}

	public void setTipoDePelo(String tipoDePelo) {
		this.tipoDePelo = tipoDePelo;
	}

	@Override
	public void tipoAnimal() {
		// TODO Auto-generated method stub
		System.out.println(" es oveja");
	}
	
	
	//TO STRING--------------------------------------
	
	@Override
	public String toString() {
		return nombre + ": Peso" + peso + "kg, edad: " + edad + " anyos" + " tipo de pelo: " + tipoDePelo;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
