package tareaGranjaClases;
import java.util.*;

public class Vacas extends Animales implements LecheProducida {
	
	
	//ATRIBUTOS --------------------------------------
	
	private String uso;
	
	
	//CONSTRUCTORES -------------------------------------------

	public Vacas() {
		super();
	}
	
	
	public Vacas(String nombre, double peso, int edad, String uso) {
		super(nombre, peso, edad);
		this.uso = uso;
	}


	//SETTERS Y GETTERS


	public String getUso() {
		return uso;
	}


	public void setUso(String uso) {
		this.uso = uso;
	}


	@Override
	public double ordenyar() {
		// TODO Auto-generated method stub
		
		Random r = new Random();
		double lechita = r.nextDouble(3.0, 8.0);
		return Math.min(lechita, 8.0);
	}


	@Override
	public void tipoAnimal() {
		// TODO Auto-generated method stub
		 System.out.println(" es vaca");
	}
	

	//TO STRING ------------------------------
	
	@Override
	public String toString() {
		return nombre + ": Peso" + peso + "kg, edad: " + edad + " anyos" + " use: " + uso;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
