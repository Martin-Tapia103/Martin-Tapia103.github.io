package tareaGranjaClases;

public abstract class Animales {

	//ATRIBUTOS -----------------------------------------------
	
	protected String nombre;
	protected double peso;
	protected int edad;
	protected boolean vivo = true; //vivo = true, muerto = false.
	
	
	//CONSTRUCTORES -------------------------------------------
	

	public Animales() {
		super();
	}

	public Animales(String nombre, double peso, int edad) {
		super();
		this.nombre = nombre;
		this.peso = peso;
		this.edad = edad;
	}



	//GETTERS Y SETTERS ----------------------------------------
	

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	public boolean isVivo() {
		return vivo;
	}

	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}

	public abstract void tipoAnimal();

	
	//TO STRING ----------------------------------------------------
	
	@Override
	public String toString() {
		return nombre + ": Peso" + peso + "kg, edad: " + edad + " anyos";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
