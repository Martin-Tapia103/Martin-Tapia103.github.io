package tareaGranjaClases;

public interface LecheProducida {

	
	public double ordenyar(); 
		
	
}
