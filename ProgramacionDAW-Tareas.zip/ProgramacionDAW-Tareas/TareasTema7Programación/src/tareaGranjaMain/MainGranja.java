package tareaGranjaMain;
import java.lang.reflect.Array;
import java.util.*;

import tareaGranjaClases.Animales;
import tareaGranjaClases.Cerdos;
import tareaGranjaClases.Ovejas;
import tareaGranjaClases.Vacas;



public class MainGranja {
	
	static Animales array[]= new Animales[7];
	static boolean hayVivos = false;
	
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static Scanner scDouble = new Scanner(System.in);
	
	static double lecheTotal = 0.0;
	static double gananciasTotales = 0.0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
		array[0]= new Vacas("Romera", 230.5, 3, "Leche");
		array[1]= new Vacas("Facunda", 205.2, 3, "Carne");
		array[2]= new Vacas("Fina", 245.4, 3, "Leche");
		
		array[3]= new Cerdos("Petro", 90.2, 2, "Rosado");

		array[4]= new Ovejas("Mota", 40, 3, "Rizado");
		array[5]= new Ovejas("Coral", 50, 4, "Liso");
		array[6]= new Ovejas("Cebra", 37.6, 1, "Rizado");
		
			
		do {
			
			System.out.println("\n=========== MENU PRINCIPAL ===========");
			System.out.println("\n1.- Marcar animal como muerto");
			System.out.println("2.- Listado de animales");
			System.out.println("3.- Listado de animales completo");
			System.out.println("4.- Mostrar tipo de animal");
			System.out.println("5.- Sumar anyo a un animal");
			System.out.println("6.- Cambiar peso animal");
			System.out.println("7.- Adquirir nuevo cerdo");
			System.out.println("8.- Obtencion de leche");
			System.out.println("9.- Venta de leche");
			
		
			int opcion = scInt.nextInt();

			switch (opcion) {
			
			case 1: 
				MarcarComoMuerto();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 2: 
				ListarAnimales(); 
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 3: 
				ListadoAnimalesCompleto();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 4: 
				MostrarTipoDeAnimal();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 5: 
				SumarAnyoAAnimal();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 6: 
				CambiarPesoAAnimal(); 
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 7: 
				AdquirirUnCerdoNuevo();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 8: 
				ObtenerLeche(); 
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 9:
				VenderLeche();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
			}
			
			
		} while (true);

	}
	
		
	
	//METODOS ===================================================================
	
	private static void MarcarComoMuerto() {
		// TODO Auto-generated method stub
		
		System.out.println("\nMARCAR ANIMAL COMO MUERTO");
	    
	    for (int i = 0; i < array.length; i++) {
	        if (array[i] != null && array[i].isVivo()) {
	            hayVivos = true;
	            System.out.println((i + 1) + ".- " + array[i].getNombre());
	        }
	    }

	    if (!hayVivos) {
	        System.out.println("\nHAS MATADO A TODOS");
	        return;
	    }

	    System.out.println("\nElija el animal");
	    int opcion = scInt.nextInt();

	    if (opcion < 1 || opcion > array.length || array[opcion - 1] == null || !array[opcion - 1].isVivo()) {
	        System.out.println("Ya mataste a ese...");
	        return;
	    }

	    System.out.println("\nEl animal " + array[opcion - 1].getNombre() + " ha muerto");
	    array[opcion - 1] = null; 
		
	}


	private static void ListarAnimales() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		System.out.println("LISTADO DE ANIMALES");
		for (int i = 0; i<array.length; i++) {
			if (array[i] != null && array[i].isVivo()) {
				System.out.println(array[i].getNombre() + ": peso: " + array[i].getPeso() + " Kg, edad: " + array[i].getEdad() + " anyos");
			}
		}	
	}


	private static void ListadoAnimalesCompleto() {
		// TODO Auto-generated method stub
		System.out.println("\n");
	    System.out.println("LISTADO DE ANIMALES COMPLETO");

	    for (int i = 0; i < array.length; i++) {
	        if (array[i] != null && array[i].isVivo()) {

	            System.out.println(array[i].toString());

	        }
	    }	
	}


	private static void MostrarTipoDeAnimal() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		System.out.println("MOSTRAR TIPO DE ANIMAL");
	    
	    for (int i = 0; i < array.length; i++) {
	        if (array[i] != null && array[i].isVivo()) {
	            System.out.println((i + 1) + ".- " + array[i].getNombre());
	        }
	    }
	    
	    System.out.println("\nElija el animal");
	    int opcion = scInt.nextInt();
	    
	    System.out.print("\n" + array[opcion - 1].getNombre());
	    array[opcion -1].tipoAnimal();
	}
		

	private static void SumarAnyoAAnimal() {
		// TODO Auto-generated method stub		
		System.out.println("\n");
		System.out.println("SUMAR ANYO A ANIMAL");
	    
	    for (int i = 0; i < array.length; i++) {
	        if (array[i] != null && array[i].isVivo()) {
	            System.out.println((i + 1) + ".- " + array[i].getNombre());
	        }
	        
            int edadNueva = array[i].getEdad() + 1;
            array[i].setEdad(edadNueva);
	    }
	    
	    
	    System.out.println("\nElija el animal");
	    int opcion = scInt.nextInt();
		
		System.out.println("\n" + array[opcion - 1].getNombre() + " ahora tiene " + array[opcion - 1].getEdad() + " anyos");
	    
	    
	}

	private static void CambiarPesoAAnimal() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		System.out.println("CAMBIAR PESO A ANIMAL");
	    
	    for (int i = 0; i < array.length; i++) {
	        if (array[i] != null && array[i].isVivo()) {
	            System.out.println((i + 1) + ".- " + array[i].getNombre());
	        }
	    }
		
	    System.out.println("\nElija el animal");
	    int opcion = scInt.nextInt();
	    
	    double pesoViejo = array[opcion - 1].getPeso();
	    
	    System.out.println("¿Nuevo Peso?");
	    
	    double pesoNuevo = scDouble.nextDouble();    
        array[opcion - 1].setPeso(pesoNuevo);
        
        double resto = pesoNuevo - pesoViejo;
        
        System.out.println(array[opcion -1].getNombre() + " ha ganado" + " " + Math.round(resto*10.0)/10.0 + "Kg");
		
	}

	private static void AdquirirUnCerdoNuevo() {
		// TODO Auto-generated method stub		
		
    	Cerdos cerdo = (Cerdos) array[3];
		
		System.out.println("\n");
		System.out.println("ADQUIRIR UN NUEVO CERDO");
	    if (array[3] != null) {
	        System.out.println("El cerdo aun no es chorizo, no puedes crear otro.");
	        return;
	    }

	    System.out.println("Dime el nombre del cerdo nuevo");
	    String nombre = scLine.nextLine();

	    System.out.println("Su peso");
	    double peso = scDouble.nextDouble();

	    System.out.println("Su edad");
	    int edad = scInt.nextInt();

	    System.out.println("Y su color de piel");
	    String colorPiel = scLine.nextLine();

	    array[3] = new Cerdos(nombre, peso, edad, colorPiel);

	    System.out.println("Has obtenido un nuevo cerdo: " + array[3].toString());          			
	}

	private static void ObtenerLeche() {
		// TODO Auto-generated method stub
		System.out.println("\n");
	    System.out.println("OBTENER LECHE");

	    for (int i = 0; i < 3; i++) { 
	        if (array[i] == null) {
	            System.out.println("Vaca muerta");
	        } else {
	            Vacas vaca = (Vacas) array[i];

	            if (vaca.getUso().equalsIgnoreCase("Leche")) {
	                double leche = Math.round(vaca.ordenyar() * 10.0) / 10.0;
	                lecheTotal += leche;
	                System.out.println("Leche obtenida por " + vaca.getNombre() + ": " + leche + "l");
	            }
	        }
	    }

	}

	private static void VenderLeche() {
		// TODO Auto-generated method stub
		System.out.println("\n");
	    System.out.println("VENDER LECHE");

	    System.out.println("Leche en stock: " + Math.round(lecheTotal * 10.0) / 10.0 + "l");
	    System.out.println("Cuanta se quiere vender?");
	    double cantidadVenta = scDouble.nextDouble();

	    if (cantidadVenta > lecheTotal) {
	        System.out.println("No tienes tanta leche");
	        return;
	    }
	    
	    if (cantidadVenta < 0) {
	        System.out.println("¿?");
	        return;
	    }

	    double gananciasVenta = cantidadVenta * 0.5;
	    lecheTotal -= cantidadVenta;
	    gananciasTotales += gananciasVenta;

	    System.out.println("Ganancias por esta venta: " + Math.round(gananciasVenta * 100.0) / 100.0 + " euros");
	    System.out.println("Ganancias acumuladas: " + Math.round(gananciasTotales * 100.0) / 100.0 + " euros");
	    
	}	
}
