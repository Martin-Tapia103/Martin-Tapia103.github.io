package ejercicios1;

import java.util.Arrays;

public class EjerciciosArray1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//1.- A partir del siguiente array {2, 3, 4, 7, 8} obtener otro donde la primera posición se multiplique por 10, la segunda por 100,
		//la tercera por 1000 etc…
		
//		int array[] = {2, 3, 4, 7, 8};
//		int multiplicacion = 1;
//		
//		for (int i = 0; i<array.length; i++) {	
//			multiplicacion = multiplicacion * 10;
//			array[i] = (array[i] * multiplicacion);
//			System.out.println(array[i]);
//		}
		
		
		
		//2.-Dados estos dos arrays: {1, 3, 5, 7, 9} y {6, 4, 2, 1, 3} multiplicar un array por otro (posición a posición)
		//y dividir el resultado entre 10 (todas las posiciones).
		
//        double[] arrayX = {1, 3, 5, 7, 9};
//        double[] arrayY = {6, 4, 2, 1, 3};
//
//        int longitud = arrayX.length;
//
//        double[] arrayZ = new double[longitud];
//
//        for (int i = 0; i < arrayX.length; i++) {
//            arrayZ[i] = (arrayX[i] * arrayY[i]) / 10;
//        }
//
//        System.out.println(Arrays.toString(arrayZ));
		
		
		
		//3.- Coger el siguiente array [6, 9, 8, 10, 11] y dividirlo por este otro posición a posición [2, 3, 4, 2, 3]
		//y en el resultado sumarle 10 a todos los valores menores de 4.
		
		
//		double arrayX[] = {6, 9, 8, 10, 11};
//		double arrayY[] = {2, 3, 4, 2, 3};
//		
//		
//		double arrayZ[] = new double [arrayX.length];
//		for (int i = 0; i<arrayX.length; i++) {
//			arrayZ[i] = (arrayX[i] / arrayY[i]);
//		}
//		System.out.println(Arrays.toString(arrayZ));
//		
//		
//		for (int i = 0; i<arrayZ.length; i++) {
//			if (arrayZ[i] < 4) {
//				arrayZ[i] = arrayZ[i] +10;
//			}
//			
//		}
//		System.out.println(Arrays.toString(arrayZ));
		
		
		
		//4.- Dado el siguiente array de Strings [“Coche”, “Tren”, “Avión”, “Furgoneta”, “Moto”, “Barco”, “Autobus”]
		//y este otro array de booleanos [false, true, true, false, true, true, false]. 
		//El segundo array indica que elementos del primero han de ser pasados a mayúsculas (true) y cuales a minúsculas (false). 
		//Obtener entonces un tercer array similar al primero pero con los cambios a mayúsculas o minúsculas indicados por el segundo array.
		
//		String arrayX[] = {"Coche", "Tren", "Avión", "Furgoneta", "Moto", "Barco", "Autobus"};
//		boolean arrayY[] = {false, true, true, false, true, true, false};
//		
//        String arrayZ[] = new String[arrayX.length];
//
//        for (int i = 0; i < arrayX.length; i++) {
//            if (arrayY[i]) {
//                arrayZ[i] = arrayX[i].toUpperCase();
//            } else {
//                arrayZ[i] = arrayX[i].toLowerCase();
//            }
//        }
//
//        System.out.println(Arrays.toString(arrayZ));
		
		
		
		//5.- A partir del siguiente array {2, 3, 4, 7, 8, 10, 11} obtener otro con ceros intercalados entre sus posiciones {2, 0, 3, 0, 4, 0, …}
		
		
//        int arrayX[] = {2, 3, 4, 7, 8, 10, 11};
//
//        int arrayY[] = new int[arrayX.length * 2];
//
//        for (int i = 0; i<arrayX.length; i++) {
//            arrayY[i * 2] = arrayX[i];  
//            arrayY[i * 2 + 1] = 0;       
//        }
//
//        System.out.println(Arrays.toString(arrayY));
		
		
		
		
		//6.- Dado el siguiente array de caracteres { ´P’, ‘a’, ‘l’, ‘a’, ‘b’, ‘r’, ‘a’} convertirlo en un String.
		
		
//		char array[] = {'P', 'a', 'l', 'a', 'b', 'r', 'a'};
//			
//        String palabra = new String(array);
//
//        System.out.println(palabra);
		
		
		
		
		//7.- Obtener otro array como el siguiente pero reordenado DE MAYOR A MENOR [4, 6, 1, 5, 6, 15, 12, 7].
		
		
//        int[] array = {4, 6, 1, 5, 6, 15, 12, 7};
// 
//        Arrays.sort(array);
//
//        int array2[] = new int [array.length]; 
//        
//        for (int i = 0; i<array.length; i++) {
//        	array2[i] = array[(array.length -1) -i];
//        	
//        }
//        
//        System.out.println(Arrays.toString(array2));
		
		
		
		//8.- A partir del siguiente array {2, 8, 4, 7, 3, 10, 11} obtener dos más, uno que contenga solo los elementos menores de 6 y otro los mayores de 6. 
		//Los arrays resultado NO tienen que tener ceros (es decir, que midan solo las posiciones que necesitan) 
		
		
        int arrayX[] = {2, 8, 4, 7, 3, 10, 11};

        int contador = 0;
        int contador1 = 0;

        for (int i = 0; i < arrayX.length; i++) {
            if (arrayX[i] < 6) {
                contador++;
            } else if (arrayX[i] > 6) {
                contador1++;
            }
        }

        int arrayZ[] = new int[contador];
        int arrayY[] = new int[contador1];
  
        int Menores = 0;
        int Mayores = 0;

        for (int i = 0; i < arrayX.length; i++) {
            if (arrayX[i] < 6) {
                arrayZ[Menores++] = arrayX[i];
            } else if (arrayX[i] > 6) {
                arrayY[Mayores++] = arrayX[i];
            }
        }

        System.out.println(Arrays.toString(arrayZ));
        System.out.println(Arrays.toString(arrayY));
		
		
		
		
		
		
		
		
		
		
	}

}
