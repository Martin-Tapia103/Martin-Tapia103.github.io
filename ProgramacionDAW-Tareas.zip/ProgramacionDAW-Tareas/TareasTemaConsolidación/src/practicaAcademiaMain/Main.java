package practicaAcademiaMain;

import practicaAcademiaClases.*;

import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

public class Main {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static Scanner scDouble = new Scanner(System.in);

	static Set<Persona> personas = new HashSet();
	private static final String archivo = "personal.txt";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		cargarPersonas();
			
		//========================= INTERFAZ GRAFICA =============================
		
		// ---------------- VENTANA PROFESOR ----------------

				JFrame frame = new JFrame("BASE DE DATOS PROFESORES");

				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(500, 290);
				frame.setLocation(300, 250);
								
				JPanel panel = new JPanel(new FlowLayout());
	
				
				// ---------------- LABELS ------------------
				
				JLabel lblDni = new JLabel("DNI: ");
				JTextField txtDni = new JTextField(45);
				
				JLabel lblNombre = new JLabel("Nombre: ");
				JTextField txtNombre = new JTextField(45);
				
				JLabel lblApellido = new JLabel("Apellidos: ");
				JTextField txtApellido = new JTextField(45);
				
				JLabel lblEdad = new JLabel("Edad: ");
				JTextField txtEdad = new JTextField(45);
				
				JLabel lblSalario = new JLabel("Salario: ");
				JTextField txtSalario = new JTextField(45);
				
				JLabel lblAsignatura = new JLabel("Asginatura: ");
				JTextField txtAsignatura = new JTextField(42);
				
				JLabel lblHorasLectivas = new JLabel("Horas Lectivas: ");
				JTextField txtHorasLectivas = new JTextField(38);
			
				JRadioButton rbHombre = new JRadioButton("Hombre");
				JRadioButton rbMujer = new JRadioButton("Mujer");
				
				//---------------- RADIOS ------------------------
				
				ButtonGroup grupoSexo = new ButtonGroup();
				grupoSexo.add(rbHombre);
				grupoSexo.add(rbMujer);
				
				// --------------- BOTONES ------------------------
				
				JButton btnAnyadir = new JButton("Añadir");
				JButton btnEliminar = new JButton("Eliminar");
						
					
				// ----------------- AGRUPAR LABELS, BOTONES E INTERFAZ ------------------
				
				panel.add(lblDni);
				panel.add(txtDni);
				panel.add(lblNombre);
				panel.add(txtNombre);
				panel.add(lblApellido);
				panel.add(txtApellido);
				panel.add(lblEdad);
				panel.add(txtEdad);
				panel.add(lblSalario);
				panel.add(txtSalario);
				panel.add(lblAsignatura);
				panel.add(txtAsignatura);
				panel.add(lblHorasLectivas);
				panel.add(txtHorasLectivas);
				
				panel.add(rbHombre);
				panel.add(rbMujer);
				
				panel.add(btnAnyadir);
				panel.add(btnEliminar);
				
				frame.setContentPane(panel);
				frame.setVisible(true);
				
				// ---------------- BOTON AÑADIR PROFESOR ------------------
				
				btnAnyadir.addActionListener(e -> {
					if (txtDni.getText().trim().isEmpty() || txtNombre.getText().trim().isEmpty()
							|| txtApellido.getText().trim().isEmpty() || txtEdad.getText().trim().isEmpty()
							|| txtSalario.getText().trim().isEmpty() || txtAsignatura.getText().trim().isEmpty()
							|| txtHorasLectivas.getText().trim().isEmpty()
							|| (!rbHombre.isSelected() && !rbMujer.isSelected())) {

						JOptionPane.showMessageDialog(frame, "Mete todos los datos");

					} else {
						String dni = txtDni.getText().trim();
						String nombre = txtNombre.getText().trim();
						String apellidos = txtApellido.getText().trim();
						int edad = Integer.parseInt(txtEdad.getText().trim());
						double salario = Double.parseDouble(txtSalario.getText().trim());
						String asignatura = txtAsignatura.getText().trim();
						int horasLectivas = Integer.parseInt(txtHorasLectivas.getText().trim());
						boolean esHombre = rbHombre.isSelected();

						Profesor p = new Profesor(dni, nombre, apellidos, edad, salario, esHombre, asignatura, horasLectivas);

						if (personas.add(p)) {
							JOptionPane.showMessageDialog(frame, "Persona metida");
						} else {
							JOptionPane.showMessageDialog(frame, "Ya hay alguien con ese DNI");
						}
					}
				});
				
				// ---------------- BOTON ELIMINAR PROFESOR ------------------

				btnEliminar.addActionListener(e -> {
					if (txtDni.getText().trim().isEmpty()) {
						JOptionPane.showMessageDialog(frame, "Introduce el DNI");
					} else {
						String dni = txtDni.getText().trim();
						Persona personaAEliminar = null;

						for (Persona p : personas) {
							if (p.getDni().equalsIgnoreCase(dni)) {
								personaAEliminar = p;
								break;
							}
						}

						if (personaAEliminar != null) {
							personas.remove(personaAEliminar);
							JOptionPane.showMessageDialog(frame, "Persona eliminada");
						} else {
							JOptionPane.showMessageDialog(frame, "No existe ese DNI");
						}
					}
				});
				
		// ---------------- VENTANA ADMINISTRATIVO ----------------

				JFrame frame2 = new JFrame("BASE DE DATOS ADMINISTRATIVOS");

				frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame2.setSize(500, 290);
				frame2.setLocation(1000, 250);
								
				JPanel panel2 = new JPanel(new FlowLayout());
	
				
				// ---------------- LABELS ------------------
				
				JLabel lblDni2 = new JLabel("DNI: ");
				JTextField txtDni2 = new JTextField(45);
				
				JLabel lblNombre2 = new JLabel("Nombre: ");
				JTextField txtNombre2 = new JTextField(45);
				
				JLabel lblApellido2 = new JLabel("Apellidos: ");
				JTextField txtApellido2 = new JTextField(45);
				
				JLabel lblEdad2 = new JLabel("Edad: ");
				JTextField txtEdad2 = new JTextField(45);
				
				JLabel lblSalario2 = new JLabel("Salario: ");
				JTextField txtSalario2 = new JTextField(45);
			
				JRadioButton rbHombre2 = new JRadioButton("Hombre");
				JRadioButton rbMujer2 = new JRadioButton("Mujer");
				
				JLabel lblDepartamento = new JLabel("Departamento: ");
				JTextField txtDepartamento = new JTextField(42);
				
				JLabel lblAntiguedad = new JLabel("Antiguedad: ");
				JTextField txtAntiguedad = new JTextField(38);
			
				
				//---------------- RADIOS ------------------------
				
				ButtonGroup grupoSexo2 = new ButtonGroup();
				grupoSexo2.add(rbHombre2);
				grupoSexo2.add(rbMujer2);
				
				// --------------- BOTONES ------------------------
				
				JButton btnAnyadir2 = new JButton("Añadir");
				JButton btnEliminar2 = new JButton("Eliminar");
									
					
				// ----------------- AGRUPAR LABELS, BOTONES E INTERFAZ ------------------
				
				panel2.add(lblDni2);
				panel2.add(txtDni2);
				panel2.add(lblNombre2);
				panel2.add(txtNombre2);
				panel2.add(lblApellido2);
				panel2.add(txtApellido2);
				panel2.add(lblEdad2);
				panel2.add(txtEdad2);
				panel2.add(lblSalario2);
				panel2.add(txtSalario2);
				panel2.add(lblDepartamento);
				panel2.add(txtDepartamento);
				panel2.add(lblAntiguedad);
				panel2.add(txtAntiguedad);
				
				panel2.add(rbHombre2);
				panel2.add(rbMujer2);
				
				panel2.add(btnAnyadir2);
				panel2.add(btnEliminar2);
				
				frame2.setContentPane(panel2);
				frame2.setVisible(true);		
				
				
		// ---------------- BOTON AÑADIR ADMINISTRATIVO ------------------
				
		btnAnyadir2.addActionListener(e -> {
			if (txtDni2.getText().trim().isEmpty() || txtNombre2.getText().trim().isEmpty()
					|| txtApellido2.getText().trim().isEmpty() || txtEdad2.getText().trim().isEmpty()
					|| txtSalario2.getText().trim().isEmpty() || txtDepartamento.getText().trim().isEmpty()
					|| txtAntiguedad.getText().trim().isEmpty()
					|| (!rbHombre2.isSelected() && !rbMujer2.isSelected())) {

				JOptionPane.showMessageDialog(frame2, "Falta algún dato");

			} else {
				String dni = txtDni2.getText().trim();
				String nombre = txtNombre2.getText().trim();
				String apellidos = txtApellido2.getText().trim();
				int edad = Integer.parseInt(txtEdad2.getText().trim());
				double salario = Double.parseDouble(txtSalario2.getText().trim());
				String departamento = txtDepartamento.getText().trim();
				int antiguedad = Integer.parseInt(txtAntiguedad.getText().trim());
				boolean esHombre = rbHombre2.isSelected();

				Administrativo a = new Administrativo(dni, nombre, apellidos, edad, salario, esHombre, departamento,
						antiguedad);

				if (personas.add(a)) {
					JOptionPane.showMessageDialog(frame2, "Persona introducida");
				} else {
					JOptionPane.showMessageDialog(frame2, "Ese DNI ya existe");
				}
			}
		});
				
		// ---------------- BOTON ELIMINAR ADMINISTRATIVO ------------------
				
		btnEliminar2.addActionListener(e -> {
			if (txtDni2.getText().trim().isEmpty()) {
				JOptionPane.showMessageDialog(frame2, "Introduce el DNI");
			} else {
				String dni = txtDni2.getText().trim();
				Persona personaAEliminar = null;

				for (Persona p : personas) {
					if (p.getDni().equalsIgnoreCase(dni)) {
						personaAEliminar = p;
						break;
					}
				}

				if (personaAEliminar != null) {
					personas.remove(personaAEliminar);
					JOptionPane.showMessageDialog(frame2, "Persona eliminada");
				} else {
					JOptionPane.showMessageDialog(frame2, "No existe ese DNI");
				}
			}
		});
				
		//========================= MENU ===============================
		
		int opcion;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Mostrar todo el personal");
            System.out.println("2. Mostrar solo profesores");
            System.out.println("3. Mostrar solo administrativos");
            System.out.println("4. Buscar por dni");
            System.out.println("5. Guardar datos en archivo");
            System.out.println("6. Salir");
            
            opcion = scInt.nextInt();
            switch (opcion) {
                case 1:
                    mostrarTodoElPersonal();
        	        System.out.println("\nPulsa ENTER para volver al menu");
        	        scLine.nextLine();
                    break;
                case 2:
                    mostrarSoloLosProfesores();
        	        System.out.println("\nPulsa ENTER para volver al menu");
        	        scLine.nextLine();
                    break;
                case 3:
                    mostrarSoloLosAdministrativos();
        	        System.out.println("\nPulsa ENTER para volver al menu");
        	        scLine.nextLine();
                    break;
                case 4:
                    buscarPorDni();
        	        System.out.println("\nPulsa ENTER para volver al menu");
        	        scLine.nextLine();
                    break;
                case 5:
                    guardarDatosEnArchivo(); 
        	        System.out.println("\nPulsa ENTER para volver al menu");
        	        scLine.nextLine();
                    break;
                case 6:
                    Salir(); 
                    System.out.println("Adeu");
                    break;
                default:
                    System.out.println("Eso no es uan opción valida");
            }

        } while (opcion != 6);
    }
	
	
	//========================= METODOS ============================
	
	private static void mostrarTodoElPersonal() {
		// TODO Auto-generated method stub
		
        for (Persona p : personas) {
            System.out.println(p);
        }
		
	}
	private static void mostrarSoloLosProfesores() {
		// TODO Auto-generated method stub
		
	    for (Persona p : personas) {
	        p.mostrarSiEsProfe();
	    }
		
	}
	
	private static void mostrarSoloLosAdministrativos() {
		// TODO Auto-generated method stub
		
	    for (Persona p : personas) {
	        p.mostrarSiEsAdmin();
	    }
				
	}
	
	private static void buscarPorDni() {
		// TODO Auto-generated method stub
		
		System.out.println("Introduce el dni");
		String busqueda = scLine.nextLine();
		
		for (Persona p : personas) {
		    if (p.getDni().equalsIgnoreCase(busqueda)) {
		        System.out.println(p);
		    }
		}
		
	}

	private static void guardarDatosEnArchivo() {
		// TODO Auto-generated method stub
		guardarPersonas();
		System.out.println("Datos guardados");
	}

	private static void Salir() {
		guardarPersonas();
		// TODO Auto-generated method stub	
	}

	// ============================ GESTOR =============================
	
	private static void cargarPersonas() {
	    
	    File fichero = new File(archivo);

	    if (!fichero.exists()) {
	        return;
	    }	
	    
	    try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
	        String linea;

	        while ((linea = br.readLine()) != null) {
	            String[] partes = linea.split(";");
	            
	            String tipo = partes[0];
	            String dni = partes[1];
	            String nombre = partes[2];
	            String apellido = partes[3];
	            int edad = Integer.parseInt(partes[4]);
	            boolean sexo = Boolean.parseBoolean(partes[5]);
	            double salario = Double.parseDouble(partes[6]);

	            switch (tipo.toUpperCase()) {
	                case "PROFESOR":
	                	String asignatura = partes[7];
	                	int horasLectivas = Integer.parseInt(partes[4]);
	                	Persona profesor = new Profesor(dni, nombre, apellido, edad, salario, sexo, asignatura, horasLectivas);
	                    personas.add(profesor);
	                    break;

	                case "ADMINISTRATIVO":
	                    String departamento = partes[7];
	                    int antiguedad = Integer.parseInt(partes[8]);
	                    Persona administrativo = new Administrativo(dni, nombre, apellido, edad, salario, sexo, departamento, antiguedad);
	                    personas.add(administrativo);
	                    break;

	                default:
	                    System.out.println("Escribe algo que sea valido: " + tipo);
	                    break;
	            }
	        }

	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}

    private static void guardarPersonas() {
	    
	    File fichero = new File(archivo);

	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichero))) {
	        
	        for (Persona p : personas) {
	            bw.write(p.toString());
	            bw.newLine();
	        }

	    } catch (IOException e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}
}