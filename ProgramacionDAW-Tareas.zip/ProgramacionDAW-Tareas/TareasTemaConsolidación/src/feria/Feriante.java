package feria;

public class Feriante {

	private String nombreYApellido;
	private int edad;
	
	
	public Feriante(String nombreYApellido, int edad) {
		super();
		this.nombreYApellido = nombreYApellido;
		this.edad = edad;
	}


	public Feriante() {
		super();
	}


	public String getNombreYApellido() {
		return nombreYApellido;
	}


	public void setNombreYApellido(String nombreYApellido) {
		this.nombreYApellido = nombreYApellido;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}


	@Override
	public String toString() {
		return nombreYApellido;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
