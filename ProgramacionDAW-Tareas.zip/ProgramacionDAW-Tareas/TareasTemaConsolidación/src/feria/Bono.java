package feria;

public interface Bono {
	
	public double precioBono(); 	
	
}
