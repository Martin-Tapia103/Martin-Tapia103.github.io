package feria;

import java.util.*;
import feria.Feriante;
import feria.Attraccion;

public class Main {
	
	
	//STATICS ============================================
	
	static List<Feriante> feriantes = new ArrayList();
	static List<Attraccion> atracciones = new ArrayList();
	static List<Cuadrante> cuadrantes = new ArrayList();
	
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	
	static Attraccion a0 = new Attraccion("Tiovivo", 2.5);
	static Attraccion a1 = new Attraccion("Noria", 4);
	static Attraccion a2 = new Attraccion("Coches de choque", 2.5);
	
	 static double precioBonoTioVivo = 6 * a0.precioBono() * a1.getTicket() * 0.8;
	 static double precioBonoNoria = 5 * a1.precioBono() * a1.getTicket() * 0.90;
	 static double precioBonoCochesChoque = 10 * a2.precioBono() * a2.getTicket() * 0.60;
	 
	 static Feriante f0 = new Feriante("Chiquichonqui", 70);
	 static Feriante f1 = new Feriante("Godofredo", 30);
	 static Feriante f2 = new Feriante("Guliguli", 100);
	 
	 static int[][] ganancias = new int[7][3];

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		atracciones.add(a0);
		atracciones.add(a1);
		atracciones.add(a2);
		
		feriantes.add(f0);
		feriantes.add(f1);
		feriantes.add(f2);
		
		
	//MENU ===============================================
		
		do {
			
			System.out.println("\n=========== MENU ===========");
	        System.out.println("1.- Muestra de precios");
	        System.out.println("2.- Introducción de feriante");
	        System.out.println("3.- Eliminar feriante");
	        System.out.println("4.- Asociar día con atracción y feriante (cuadrante)");
	        System.out.println("5.- Muestra del cuadrante anterior");
	        System.out.println("6.- Muestra de ganancias de la semana");
	        System.out.println("7.- Mustra ganancias max por día");
	        System.out.println("8.- Generación automática del cuadrante");
	        System.out.println("9.- Obtención ganancias feriantes");


			
			int opcion = scInt.nextInt();
			switch (opcion) {
			case 1:
				mostrarPrecios();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 2:
				introducirFeriante();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 3:
				eliminarFeriante();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 4:
				asociarDiaConAtraccionYFeriante();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;
				
			case 5:
				mostrarCuadranteAnterior();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;	
				
			case 6:
				mostrarGananciasSemana();
		        System.out.println("\nPulsa ENTER para volver al menu");
		        scLine.nextLine();
				break;	
				
			case 7:
				mostrarMAximosPorDia();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
			
			case 8:
				generacionAutomaticaDeCuadrante();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
			
		
			case 9:
				obtencionGananciasFeriantes();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
		
			}
				
			} while (true);
			
		}


	//METODOS ======================================================
	
	private static void mostrarPrecios() {
		// TODO Auto-generated method stub
		
		System.out.println("=============== PRECIOS ===================");
		System.out.println("\nTicket tio vivo: " + a0.getTicket() + " euros");
		System.out.println("Abono tio vivo " + precioBonoTioVivo + " eutos");
		
		System.out.println("\nTicket noria: " + a1.getTicket() + " euros");
		System.out.println("Abono noria: " + precioBonoNoria + " eutos");
		
		System.out.println("\nTicket coches de choque : " + a2.getTicket() + " euros");
		System.out.println("Abono coches de choque: " + precioBonoCochesChoque + " eutos");
		
	}

	private static void introducirFeriante() {
		// TODO Auto-generated method stub
		
		System.out.println("=============== INTRODUCIR FERIANTE ===================");
		
		System.out.print("\nNombre y apellido? ");
		String nombreYApellido = scLine.nextLine();
		
		System.out.print("Edad? ");
		int edad = scInt.nextInt();
		
		Feriante Fx = new Feriante(nombreYApellido, edad);
		
		System.out.println("\nEl feriante " + Fx.getNombreYApellido() + " ha sido añadido");
		feriantes.add(Fx);
		
	}

	private static void eliminarFeriante() {
		// TODO Auto-generated method stub
		
	    for (int i = 0; i < feriantes.size(); i++) {
	        System.out.println(i + ".- " + feriantes.get(i));
	    }

	    System.out.println("\nQue feriante quitamos? ");
	    int opcion = scInt.nextInt();

	    feriantes.remove(opcion);
		
	}

	private static void asociarDiaConAtraccionYFeriante() {
		// TODO Auto-generated method stub
		
		 boolean salir = false;

		    do {

		        if (feriantes.isEmpty()) {
		            System.out.println("Como que falta personal por aca");
		            break;
		        }

		        System.out.println("Introduzca datos de quien lleva cada dia cada atraccion");
		        
		        //DIA
		        System.out.print("\nIntroduzca el dia: ");
		        int dia = scInt.nextInt();

		        if (dia == -1) {
		            salir = true;
		            break;
		        }

		        
		        // FERIANTES
		        for (int i = 0; i < feriantes.size(); i++) {
		            System.out.println(i + ".- " + feriantes.get(i).getNombreYApellido());
		        }

		        System.out.print("\nIntroduzca el feriante (1-3): ");
		        int feriante = scInt.nextInt();
		        String nombreFeriante = feriantes.get(feriante).getNombreYApellido();
		        System.out.println("Ha seleccionado " + feriantes.get(feriante).getNombreYApellido());
		        System.out.println("\n");

		        
		        // ATRACCIONES
		        for (int i = 0; i < atracciones.size(); i++) {
		            System.out.println(i + ".- " + atracciones.get(i).getNombre());
		        }

		        System.out.print("\nIntroduzca la atraccion (1-3): ");
		        int atraccion = scInt.nextInt();
		        String nombreAtraccion = atracciones.get(atraccion).getNombre();
		        System.out.println("Ha seleccionado " + atracciones.get(atraccion).getNombre());
		        System.out.println("\n");
		        
		        
		        Cuadrante Cx = new Cuadrante(dia, nombreFeriante, nombreAtraccion);
		        cuadrantes.add(Cx);
		        System.out.println(Cx.toString());
		        System.out.println("\n");

		    } while (!salir);
		
	}

	private static void mostrarCuadranteAnterior() {
		// TODO Auto-generated method stub
		
		    if (cuadrantes.isEmpty()) {
		        System.out.println("NADIE TRABAJO");
		    }

		    for (Cuadrante c : cuadrantes) {
		    	System.out.println("\n");
		        System.out.println(c.toString());
		    }		
	}

	private static void mostrarGananciasSemana() {
		// TODO Auto-generated method stub
		
	    Random r = new Random();

	    for (int i = 0; i < 7; i++) {
	        for (int j = 0; j < 3; j++) {
	            ganancias[i][j] = r.nextInt(400) + 100;
	        }
	    }

	    for (int j = 0; j < 3; j++) {
	        for (int i = 0; i < 7; i++) {
	            System.out.println("Dia " + (i + 1) + ", atraccion " + (j + 1) + " (" +atracciones.get(j).getNombre() + 
	            "); ganancias = " + ganancias[i][j] + " euros");
	        }
	        System.out.println();
	    }
		
	}
		
	private static void mostrarMAximosPorDia() {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < 7; i++) {

	        int max = ganancias[i][0];
	        int x = 0;

	        for (int j = 1; j < 3; j++) {
	            if (ganancias[i][j] > max) {
	                max = ganancias[i][j];
	                x = j;
	            }
	        }

	        System.out.println("Dia " + (i + 1) + ": maximo del dia: " + atracciones.get(x).getNombre() + " = " + max + " euros");
	    }		
	}	
	
	
	private static void generacionAutomaticaDeCuadrante() {
		// TODO Auto-generated method stub
		
		if (feriantes.size() < 3) {
	        System.out.println("No hay 3 feriantes");
	        return;
	    }

	    Random r = new Random();

	    for (int dia = 0; dia < 7; dia++) {

	        boolean[] usado = new boolean[3]; 

	        for (int atraccion = 0; atraccion < atracciones.size(); atraccion++) {

	            int indiceFeriante;

	            do {
	                indiceFeriante = r.nextInt(3); 
	            } while (usado[indiceFeriante]);

	            usado[indiceFeriante] = true; 

	            String nombreFeriante = feriantes.get(indiceFeriante).getNombreYApellido();
	            String nombreAtraccion = atracciones.get(atraccion).getNombre();

	            Cuadrante c = new Cuadrante(dia + 1, nombreFeriante, nombreAtraccion);
	            cuadrantes.add(c);
	        }
	    }

	    mostrarCuadranteAnterior();
		 
	}

	private static void obtencionGananciasFeriantes() {
		// TODO Auto-generated method stub
		
	}

}


