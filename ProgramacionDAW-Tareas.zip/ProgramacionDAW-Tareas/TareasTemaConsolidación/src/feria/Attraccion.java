package feria;

public class Attraccion implements Bono {

	
	//ATRIBUTOS ===========================================
	
	private String nombre;
	private double ticket;
	
	
	//CONSTRUCTORES =======================================
	
	public Attraccion() {
		super();
	}


	public Attraccion(String nombre, double ticket) {
		super();
		this.nombre = nombre;
		this.ticket = ticket;
	}

	
	//GETTERS Y SETTERS ===================================

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public double getTicket() {
		return ticket;
	}


	public void setTicket(double ticket) {
		this.ticket = ticket;
	}


	@Override
	public double precioBono() {
		// TODO Auto-generated method stub
		return this.ticket;
	}


	@Override
	public String toString() {
		return nombre;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
