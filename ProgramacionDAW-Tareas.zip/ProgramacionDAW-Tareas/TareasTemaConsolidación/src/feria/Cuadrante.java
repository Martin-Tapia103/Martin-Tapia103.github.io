package feria;

public class Cuadrante {

	private int dia;
	private String feriante;
	private String atraccion;
	
	
	public Cuadrante(int dia, String feriante, String atraccion) {
		super();
		this.dia = dia;
		this.feriante = feriante;
		this.atraccion = atraccion;
		
	}
	public Cuadrante() {
		super();
	}
	
	
	
	public int getDia() {
		return dia;
	}
	public void setDia(int dia) {
		this.dia = dia;
	}
	public String getFeriante() {
		return feriante;
	}
	public void setFeriante(String feriante) {
		this.feriante = feriante;
	}
	public String getAtraccion() {
		return atraccion;
	}
	public void setAtraccion(String atraccion) {
		this.atraccion = atraccion;
	}
	
	
	@Override
	public String toString() {
		return "El dia " + dia + " de feria " + feriante + " se encargo de " + atraccion;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
