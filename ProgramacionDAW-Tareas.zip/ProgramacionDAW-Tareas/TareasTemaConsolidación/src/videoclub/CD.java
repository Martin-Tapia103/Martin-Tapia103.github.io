package videoclub;

public class CD extends Producto {

    private String autor;
    private String titulo;
    private double precio;

    public CD(int codigo, String autor, String titulo, double precio) {
        super(codigo);
        this.autor = autor;
        this.titulo = titulo;
        this.precio = precio;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "CD [codigo=" + codigo + ", autor=" + autor + ", titulo=" + titulo + ", precio=" + precio + "]";
    }
}
