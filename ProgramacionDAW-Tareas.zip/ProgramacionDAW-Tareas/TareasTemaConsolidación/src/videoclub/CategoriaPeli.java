package videoclub;

public enum CategoriaPeli {

    NOVEDAD("Novedad", 3.0, 1),
    SEMINOVEDAD("Semi-novedad", 2.0, 2),
    ANTIGUA("Antigua", 1.0, 4);

    private String categoria;
    private double precio;
    private int diasAlquiler;

    CategoriaPeli(String categoria, double precio, int diasAlquiler) {
        this.categoria = categoria;
        this.precio = precio;
        this.diasAlquiler = diasAlquiler;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public int getDiasAlquiler() {
        return diasAlquiler;
    }

    @Override
    public String toString() {
        return categoria + " - " + precio + " euros - " + diasAlquiler + " dias";
    }
}
