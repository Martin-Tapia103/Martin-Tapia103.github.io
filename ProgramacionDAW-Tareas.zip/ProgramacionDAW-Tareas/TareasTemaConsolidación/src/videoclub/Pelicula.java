package videoclub;

public class Pelicula extends Producto {

    private String titulo;
    private CategoriaPeli categoria;
    private boolean alquilada;
    private int diaAlquiler;

    public Pelicula(int codigo, String titulo, CategoriaPeli categoria) {
        super(codigo);
        this.titulo = titulo;
        this.categoria = categoria;
        this.alquilada = false;
        this.diaAlquiler = 0;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public CategoriaPeli getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaPeli categoria) {
        this.categoria = categoria;
    }

    public boolean isAlquilada() {
        return alquilada;
    }

    public void setAlquilada(boolean alquilada) {
        this.alquilada = alquilada;
    }

    public int getDiaAlquiler() {
        return diaAlquiler;
    }

    public void setDiaAlquiler(int diaAlquiler) {
        this.diaAlquiler = diaAlquiler;
    }

    @Override
    public String toString() {

        String estado = "No";

        if (alquilada) {
            estado = "Si";
        }

        return "Pelicula [codigo=" + codigo + ", titulo=" + titulo + ", categoria=" + categoria.getCategoria() + ", precio alquiler=" + categoria.getPrecio() +
        		", dias alquiler=" + categoria.getDiasAlquiler() + ", alquilada=" + estado + "]";
    }
}