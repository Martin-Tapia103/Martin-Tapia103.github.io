package videoclub;

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class MainVideoclub {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);

	static ArrayList<Pelicula> peliculas = new ArrayList<>();
	static ArrayList<CD> cds = new ArrayList<>();

	static int codigoPelicula = 10000;
	static int codigoCD = 20000;

	static int diaActual = 1;

	static double gananciasPeliculas = 0;
	static double gananciasCD = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// ============= VENTANA PELICULA =============

		JFrame framePeli = new JFrame("Introducir pelicula");
		framePeli.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framePeli.setSize(700, 180);
		framePeli.setLocation(120, 100);

		JPanel panelPeli = new JPanel(new FlowLayout());

		JLabel tituloPeli = new JLabel("Titulo");
		JTextField txtTituloPeli = new JTextField(35);

		JRadioButton novedad = new JRadioButton("Novedad");
		JRadioButton seminovedad = new JRadioButton("Seminovedad");
		JRadioButton antigua = new JRadioButton("Antigua");

		ButtonGroup grupo = new ButtonGroup();
		grupo.add(novedad);
		grupo.add(seminovedad);
		grupo.add(antigua);

		seminovedad.setSelected(true);

		JLabel unidadesPeli = new JLabel("Unidades");
		JTextField txtUnidadesPeli = new JTextField(8);

		JButton introducirPeli = new JButton("Introducir");

		panelPeli.add(tituloPeli);
		panelPeli.add(txtTituloPeli);
		panelPeli.add(novedad);
		panelPeli.add(seminovedad);
		panelPeli.add(antigua);
		panelPeli.add(unidadesPeli);
		panelPeli.add(txtUnidadesPeli);
		panelPeli.add(introducirPeli);

		framePeli.setContentPane(panelPeli);
		framePeli.setVisible(true);

		// ============= VENTANA CD ===================

		JFrame frameCD = new JFrame("Introducir CD");
		frameCD.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameCD.setSize(700, 220);
		frameCD.setLocation(120, 320);

		JPanel panelCD = new JPanel(new FlowLayout());

		JLabel tituloCD = new JLabel("Titulo");
		JTextField txtTituloCD = new JTextField(40);

		JLabel lblCantante = new JLabel("Cantante");
		JTextField txtCantante = new JTextField(35);

		JLabel lblPrecio = new JLabel("Precio");
		JTextField txtPrecio = new JTextField(8);

		JLabel lblUnidadesCD = new JLabel("Unidades");
		JTextField txtUnidadesCD = new JTextField(8);

		JButton btnIntroducirCD = new JButton("Introducir");

		panelCD.add(tituloCD);
		panelCD.add(txtTituloCD);
		panelCD.add(lblCantante);
		panelCD.add(txtCantante);
		panelCD.add(lblPrecio);
		panelCD.add(txtPrecio);
		panelCD.add(lblUnidadesCD);
		panelCD.add(txtUnidadesCD);
		panelCD.add(btnIntroducirCD);

		frameCD.setContentPane(panelCD);
		frameCD.setVisible(true);

		// =================== BOTON METER PELICULA =================

		introducirPeli.addActionListener(e -> {

			String titulo = txtTituloPeli.getText();
			int unidades = Integer.parseInt(txtUnidadesPeli.getText());

			CategoriaPeli categoria = CategoriaPeli.SEMINOVEDAD;

			if (novedad.isSelected()) {
				categoria = CategoriaPeli.NOVEDAD;
			}

			if (seminovedad.isSelected()) {
				categoria = CategoriaPeli.SEMINOVEDAD;
			}

			if (antigua.isSelected()) {
				categoria = CategoriaPeli.ANTIGUA;
			}

			for (int i = 0; i < unidades; i++) {
				peliculas.add(new Pelicula(codigoPelicula, titulo, categoria));
				codigoPelicula++;
			}

			txtTituloPeli.setText("");
			txtUnidadesPeli.setText("");
			seminovedad.setSelected(true);

			System.out.println("Pelicula/s metidas");
		});

		// ========================= BOTON METER CD ==================================

		btnIntroducirCD.addActionListener(e -> {

			String titulo = txtTituloCD.getText();
			String cantante = txtCantante.getText();
			double precio = Double.parseDouble(txtPrecio.getText());
			int unidades = Integer.parseInt(txtUnidadesCD.getText());

			for (int i = 0; i < unidades; i++) {
				cds.add(new CD(codigoCD, cantante, titulo, precio));
				codigoCD++;
			}

			txtTituloCD.setText("");
			txtCantante.setText("");
			txtPrecio.setText("");
			txtUnidadesCD.setText("");

			System.out.println("CD/s metidos");
		});

		// ============================== MENU ==============================

		do {

			System.out.println("\n=========== MENU DIA " + diaActual + " ===========");
			System.out.println("1.- Eliminar producto");
			System.out.println("2.- Ver listado de películas");
			System.out.println("3.- Ver listado de CDs");
			System.out.println("4.- Alquilar película");
			System.out.println("5.- Vender disco");
			System.out.println("6.- Ver películas en alquiler");
			System.out.println("7.- Ver ganancias");
			System.out.println("8.- Pasar al día siguiente");

			int opcion = scInt.nextInt();
			switch (opcion) {
			case 1:
				eliminarProducto();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 2:
				verListadoPeliculas();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 3:
				verListadoCDs();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 4:
				alquilarPelicula();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 5:
				venderDisco();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 6:
				verPeliculasEnAlquiler();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 7:
				verGanancias();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			case 8:
				pasarAlDiaSiguiente();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;

			default:
				System.out.println("Opcion no valida");
				break;
			}

		} while (true);

	}

	// ====================== METODOS ===========================

	private static void eliminarProducto() {
		int contador = 0;
		System.out.println("========= PRODUCTOS =========");

		for (int i = 0; i < peliculas.size(); i++) {
			System.out.println(contador++ + ".- PELICULA - " + peliculas.get(i));
		}
		for (int i = 0; i < cds.size(); i++) {
			System.out.println(contador++ + ".- CD - " + cds.get(i));
		}

		System.out.println("\n¿Qué producto quieres eliminar?");
		int opcion = scInt.nextInt();

		if (opcion >= 0 && opcion < peliculas.size()) {
			
			peliculas.remove(opcion);	
			System.out.println("Peli fuera.");
			
		} else if (opcion >= peliculas.size() && opcion < (peliculas.size() + cds.size())) {
			
			cds.remove(opcion - peliculas.size());
			System.out.println("CD fuera.");
			
		} else {
			System.out.println("Eso no es ni una peli ni un cd");
		}
	}

	private static void verListadoPeliculas() {

		System.out.println("========= LISTADO DE PELICULAS =========");

		for (int i = 0; i < peliculas.size(); i++) {
			System.out.println(i + ".- " + peliculas.get(i));

		}
	}

	private static void verListadoCDs() {

		System.out.println("========= LISTADO DE CDs =========");

		for (int i = 0; i < cds.size(); i++) {
			System.out.println(i + ".- " + cds.get(i));

		}
	}

	private static void alquilarPelicula() {

		System.out.println("========= PELICULAS DISPONIBLES =========");
		int contador = 0;

		for (int i = 0; i < peliculas.size(); i++) {
			if (!peliculas.get(i).isAlquilada()) {

				System.out.println(contador + ".- " + peliculas.get(i));
				contador++;
			}
		}

		System.out.println("\nQue pelicula quieres alquilar?");
		int opcion = scInt.nextInt();
		int num = 0;

		for (int i = 0; i < peliculas.size(); i++) {
			Pelicula p = peliculas.get(i);

			if (!p.isAlquilada()) {
				if (num == opcion) {

					p.setAlquilada(true);
					p.setDiaAlquiler(diaActual);
					gananciasPeliculas += p.getCategoria().getPrecio();

					System.out.println("La pelicula " + p.getTitulo() + " ha sido alquilada por " + p.getCategoria().getDiasAlquiler() + " dias");
					break;
				} 			
				num++;
			} 
		}
	}

	private static void venderDisco() {

		System.out.println("========= LISTADO DE CDs =========");

		for (int i = 0; i < cds.size(); i++) {
			System.out.println(i + ".- " + cds.get(i));
		}

		System.out.println("\nQue disco quieres vender?");
		int opcion = scInt.nextInt();

		CD vendido = cds.get(opcion);
		cds.remove(opcion);
		gananciasCD += vendido.getPrecio();

		System.out.println("El disco " + vendido.getTitulo() + " de " + vendido.getAutor() + " ha sido vendido por " + vendido.getPrecio() + " euros");
	}

	private static void verPeliculasEnAlquiler() {

		System.out.println("========= PELICULAS EN ALQUILER =========");

		for (int i = 0; i < peliculas.size(); i++) {
			if (peliculas.get(i).isAlquilada()) {

				System.out.println(peliculas.get(i));
			}
		}
	}

	private static void verGanancias() {

		System.out.println("Ganancias por alquiler de peliculas: " + gananciasPeliculas + " euros");
		System.out.println("Ganancias por venta de CDs: " + gananciasCD + " euros");
		System.out.println("Ganancias totales: " + (gananciasPeliculas + gananciasCD) + " euros");

	}

	private static void pasarAlDiaSiguiente() {

		System.out.println("Desea pasar al dia siguiente (s/n)?");
		String siNo = scLine.nextLine();

		if (siNo.equalsIgnoreCase("s")) {
			diaActual++;
			System.out.println("Avanzamos día");

			for (int i = 0; i < peliculas.size(); i++) {
				Pelicula p = peliculas.get(i);

				if (p.isAlquilada()) {

					int dias = p.getCategoria().getDiasAlquiler();
					if (diaActual >= p.getDiaAlquiler() + dias) {
						p.setAlquilada(false);
					}
				}
			}

		} else if (siNo.equalsIgnoreCase("n")) {
			System.out.println("Pues no se avanza día");
		} else {
			System.out.println("Te dije 's' o 'n', no otra cosa");
		}
	}
}
