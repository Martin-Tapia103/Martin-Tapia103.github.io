package practicaAcademiaClases;

public class Administrativo extends Persona {

	
	private String departamento;
	private int antiguedad;
	
	
	public Administrativo(String dni, String nombre, String apellidos, int edad, double salario, boolean esHombre,
			String departamento, int antiguedad) {
		super(dni, nombre, apellidos, edad, salario, esHombre);
		this.departamento = departamento;
		this.antiguedad = antiguedad;
	}
	public Administrativo() {
		super();
	}
	
	
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public int getAntiguedad() {
		return antiguedad;
	}
	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}
	
	@Override
	public void mostrarSiEsAdmin() {
	    System.out.println(this.toString());
	}
	
	@Override
	public String toString() {
		return "ADMINISTRATIVO;" + dni + ";" + nombre + ";" + apellidos + ";" + edad + ";" + esHombre + ";" + departamento + ";" + salario + "€;" + antiguedad;
	}
}
