package practicaAcademiaClases;

public class Profesor extends Persona {

	
	private String asignatura;
	private int horasLectivas;
	
	
	public Profesor(String dni, String nombre, String apellidos, int edad, double salario, boolean esHombre,
			String asignatura, int horasLectivas) {
		super(dni, nombre, apellidos, edad, salario, esHombre);
		this.asignatura = asignatura;
		this.horasLectivas = horasLectivas;
	}


	public Profesor() {
		super();
	}


	public String getAsignatura() {
		return asignatura;
	}


	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}


	public int getHorasLectivas() {
		return horasLectivas;
	}


	public void setHorasLectivas(int horasLectivas) {
		this.horasLectivas = horasLectivas;
	}

	@Override
	public void mostrarSiEsProfe() {
	    System.out.println(this.toString());
	}

	@Override
	public String toString() {
		return "PROFESOR;" + dni + ";" + nombre + ";" + apellidos + ";" + edad + ";" + esHombre + ";" + asignatura + ";" + salario + "€;" + horasLectivas;
	}	
}
