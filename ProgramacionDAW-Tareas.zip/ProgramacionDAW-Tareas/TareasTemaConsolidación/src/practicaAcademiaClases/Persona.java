package practicaAcademiaClases;

import java.util.Objects;

public abstract class Persona {

	// ========================= ATRIBUTOS =============================
	
	protected String dni;
	protected String nombre;
	protected String apellidos;
	protected int edad;
	protected double salario;
	protected boolean esHombre; //TRUE == SI, FALSE == NO
	
	
	// ======================== CONSTRUCTORES ============================
	
	public Persona(String dni, String nombre, String apellidos, int edad, double salario, boolean esHombre) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
		this.salario = salario;
		this.esHombre = esHombre;
	}


	public Persona() {
		super();
	}


	// =========================== GETTERS Y SETTERS ============================
	
	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellidos() {
		return apellidos;
	}


	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public boolean isEsHombre() {
		return esHombre;
	}


	public void setEsHombre(boolean esHombre) {
		this.esHombre = esHombre;
	}

	
	public void mostrarSiEsProfe() {
		
	}
	
	public void mostrarSiEsAdmin() {
		
	}
	
	
	// =============== TO STRING ================
	
	@Override
	public String toString() {
		return "Persona [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", edad=" + edad
				+ ", salario=" + salario + ", esHombre=" + esHombre + "]";
	}

	
	
	//===================================== HASH CODE Y EQUALS ==============================

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return Objects.equals(dni, other.dni);
	}
	
}
