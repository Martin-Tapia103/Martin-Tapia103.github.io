package tareaCensoAlumnos;

import java.util.*;
import tareaCensoAlumnos.Alumno;

public class Main {
	
	static Set<Alumno> censo = new HashSet();
	static List<Alumno> partes = new ArrayList();
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static boolean salir = true; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//====================== CENSO POR DEFECTO ======================================
		
		Alumno a1 = new Alumno(1, "Ana Pérez", "1º DAM");
		Alumno a2 = new Alumno(2, "Luis Solís", "1º DAM");
		Alumno a3 = new Alumno(3, "Marta Ruiz", "1º DAM");
		Alumno a4 = new Alumno(4, "Javier Ortega", "1º DAW");
		Alumno a5 = new Alumno(5, "Lucía Sánchez", "1º DAW");
		Alumno a6 = new Alumno(6, "Carlos Martín", "1º DAW");
			
		censo.add(a1);
		censo.add(a2);
		censo.add(a3);
		censo.add(a4);
		censo.add(a5);
		censo.add(a6);
		
		
		//====================== PARTES POR DEFECTO ======================================
		
		partes.add(a1);
		partes.add(a2);
		partes.add(a3);
		partes.add(a4);
		partes.add(a1);
		partes.add(a5);
		partes.add(a2);
		partes.add(a4);
		
		
		//====================== MENU ======================================
		
		do {
		
		System.out.println("\n=========== MENU ===========");
        System.out.println("1.- Mostrar censo de alumnos");
        System.out.println("2.- Mostrar registro de partes");
        System.out.println("3.- Añadir alumno al censo");
        System.out.println("4.- Eliminar alumno del censo por ID.");
        System.out.println("5.- Poner parte a un alumno buscándolo por ID");
        System.out.println("6.- Mostrar número de alumnos en el censo");
        System.out.println("7.- Mostrar número total de partes registrados");
        System.out.println("8.- Buscar datos alumno por ID y mostrar cuántos partes tiene");
        
        System.out.println("\n======OPCIONAL======\n");
        
        System.out.println("9.- Eliminar un parte del registro");
        System.out.println("10.- Mostrar alumnos del censo sin partes registrados ");
        System.out.println("11.- Mostrar alumnos con al menos un parte");
        System.out.println("12.- Mostrar alumnos con al menos N partes (preguntar por N)");
        System.out.println("13.- Buscar alumnos por nombre (coincidencia parcial)");
        System.out.println("14.- Salir");

		
		int opcion = scInt.nextInt();
		switch (opcion) {
		case 1:
			mostrarCenso();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 2:
			mostrarRegistroDePartes();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 3:
			anyadirAlumno();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 4:
			eliminarAlumnoPorId();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 5:
			ponerPartePorId();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 6:
			mostrarNumeroAlumnosEnElCenso();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 7:
			mostrarTotalDePartesRegistrados();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 8:
			buscarDatosAlumnoYPartesPorId();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 9:
			eliminarUnParteDelRegistro();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 10:
			mostrarAlumnosSinPartes();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 11:
			mostrarAlumnosConUnoOMasPartes();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 12:
			mostrarAlumnosConPartesAPArtirDeN();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 13:
			buscarAlumnosPorNombre();
	        System.out.println("\nPulsa ENTER para volver al menu");
	        scLine.nextLine();
			break;
			
		case 14:
			salir();
			break;
		
		}
					
	} while(salir);  
	
	System.out.println("\nAdeu...");
}
	

	//============================== METODOS ====================================
	
	private static void mostrarCenso() {
		// TODO Auto-generated method stub
		
		System.out.println("---- CENSO DE ALUMNOS ----");
		
		for(Alumno a: censo) {
			
			System.out.println(a.toString());
			
		}
		
	}
	private static void mostrarRegistroDePartes() {
		// TODO Auto-generated method stub
		
		System.out.println("---- REGISTRO DE PARTES (histórico) ----");
		
		for (int i = 0; i < partes.size(); i++) {
            System.out.println((i + 1) + ".- " + partes.get(i));
        }
		
	}
	
	private static void anyadirAlumno() {
		// TODO Auto-generated method stub
		
			System.out.println("\nIntroduce el id del alumno ");
			int id = scLine.nextInt();
			scLine.nextLine();
			
			System.out.println("Introduce el nombre del alumno ");
			String nombre = scLine.nextLine();
			
			System.out.println("Introduce el curso del alumno ");
			String curso = scLine.nextLine();
			
			Alumno Ax = new Alumno(id, nombre, curso);
			
			censo.add(Ax);
			
		}

		
	private static void eliminarAlumnoPorId() {
		// TODO Auto-generated method stub
		
		System.out.println("Dime el ID del alumno que quieres quitar");
		int busqueda = scInt.nextInt();
		
		Alumno ax = new Alumno(busqueda, "", "");
		
		if (censo.contains(ax)) {
			
			for (Alumno a: censo) {
			    if (a.getId() == busqueda) {
			        censo.remove(ax);
			        System.out.println("El alumno con id " + a.getId() + " (" + a.getNombre() + ") ha sido quitado del censo");
			        break;
			    }
			}
	    }	else {
	    	
	    	System.out.println("Eso no es un alumno");
	    	
	    }
	}
	
	
	private static void ponerPartePorId() {
		// TODO Auto-generated method stub
		
		System.out.println("Dime el ID del alumno quien le quieres poner el parte");
		int busqueda = scInt.nextInt();
		
		Alumno ax = new Alumno(busqueda, "", "");
		
		if (censo.contains(ax)) {
			
			for (Alumno a: censo) {
			    if (a.getId() == busqueda) {
			        partes.add(a);
			        System.out.println("El alumno con id " + a.getId() + " (" + a.getNombre() + ") se ha llevado un buen partecito");
			        break;
			    }
			}
	    } else {
	    	
	    	System.out.println("Eso no es un alumno");  	
	    }
	}
		

	private static void mostrarNumeroAlumnosEnElCenso() {
		// TODO Auto-generated method stub
			
		System.out.println("En el censo hay " + censo.size() + " alumnos");
		
	}
	
	
	private static void mostrarTotalDePartesRegistrados() {
		// TODO Auto-generated method stub
		
		System.out.println("Actualmente hay " + partes.size() + " papeles indeseados rulando");
	}
	
	
	private static void buscarDatosAlumnoYPartesPorId() {
		// TODO Auto-generated method stub
		
		System.out.println("Dime el ID del alumno que quieres buscar");
		int busqueda = scInt.nextInt();
		
		Alumno ax = new Alumno(busqueda, "", "");
		
		if (censo.contains(ax)) {
			
			for (Alumno a: censo) {
			    if (a.getId() == busqueda) {
			    	System.out.println(a);
			    }		
			}
			
			int contador = 0;
			for (Alumno a: partes) {
				if (a.getId() == busqueda) {
					contador ++;
				}			
			}
			
			System.out.println("- Tiene " + contador + " partecito/s");
	    } else {
	    	
	    	System.out.println("Eso no es un alumno");
	    }
		
	}

	
	private static void eliminarUnParteDelRegistro() {
		// TODO Auto-generated method stub
		
		System.out.println("A quien le quitamos un papel indeseado?");
		int largoParte = scInt.nextInt();
		
		Alumno Ax = new Alumno(largoParte, "", "");
		
		if (partes.contains(Ax)) {
			for (Alumno a: censo) {
				if (a.getId() == largoParte) {
					partes.remove(a);
					
					System.out.println("Parte fuera, " + a.getNombre() + " es tu día de suerte");
				}
			}
			
		} else {
			
		System.out.println("Ese alumno no tiene partes/No es un alumno");
			
		}
		
	}


	private static void mostrarAlumnosSinPartes() {
		// TODO Auto-generated method stub
			
	    for (Alumno a : censo) {
	        boolean tieneParte = false;

	        for (Alumno b : partes) {
	            if (a.getId() == b.getId()) {
	                tieneParte = true;
	                break;
	            }
	        }

	        if (!tieneParte) {
	            System.out.println(a);
	        }
	    }
	
	}


	private static void mostrarAlumnosConUnoOMasPartes() {
		// TODO Auto-generated method stub
		
	    for (Alumno a : censo) {
	        boolean tieneParte = false;

	        for (Alumno b : partes) {
	            if (a.getId() == b.getId()) {
	                tieneParte = true;
	                break;
	            }
	        }

	        if (tieneParte) {
	            System.out.println(a + " tiene parte/s");
	        } 
	    }
	
	}


	private static void mostrarAlumnosConPartesAPArtirDeN() {
		// TODO Auto-generated method stub
		
		System.out.println("Dime el nº de partes");
		int numPartes = scInt.nextInt();
		
		for (Alumno a : censo) {
		    int contador = 0;

		    for (Alumno b : partes) {
		        if (a.getId() == b.getId()) {
		            contador++;
		        }
		    }

		    if (contador == numPartes) {
		        System.out.println(a + " tiene " + contador + " parte/s");
		    }
		}	
		
	}



	private static void buscarAlumnosPorNombre() {
		// TODO Auto-generated method stub
		
		System.out.println("Dime el nombre del alumno");
		String busqueda = scLine.nextLine();
		
		for (Alumno a : censo) {
		    if (a.getNombre().equalsIgnoreCase(busqueda)) {
		        System.out.println(a);
		    }
		}
	}
	
	private static void salir() {
		// TODO Auto-generated method stub
		salir = false;
	}
	
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}


