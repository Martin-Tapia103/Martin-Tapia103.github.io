package tareaCensoAlumnos;

import java.util.Objects;

public class Alumno {

	
	//================================ ATRIBUTOS =========================================
	
	private int id;
	private String nombre;
	private String curso;
	
	
	//=============================== CONSTRUCTORES =======================================
	
	public Alumno(int id, String nombre, String curso) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.curso = curso;
	}


	public Alumno() {
		super();
	}

	
	// ============================== GETTERS Y SETTERS ====================================

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCurso() {
		return curso;
	}


	public void setCurso(String curso) {
		this.curso = curso;
	}


	
	//===================================== HASH CODE Y EQUALS ==============================
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumno other = (Alumno) obj;
		return id == other.id;
	}


	//====================================== TO STRING ======================================

	
	@Override
	public String toString() {
		return "Alumno [id=" + id + ", nombre=" + nombre + ", curso=" + curso + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
