package tarea2;

public class Tarea2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	//EJERCICIO 1	- .- Para un círculo con un radio de 5 metros, calcula su área y perímetro.
		
//		//Área = πr²
//		
//		double r=5;
//		double area= 3.14*(r*r);
//		
//		//Perímetro = 2πr
//		
//		double perimetro= 2 * 3.14 * r;
//		System.out.println("El área del círculo es " + area + "m², y su perímetro es " + perimetro + "m");


		
		
	//EJERCICIO 2 - Si una persona tiene un peso de 70 kg y una altura de 1.75 metros, calcula su Índice de Masa Corporal (IMC).
		
//		//Masa corporal = Peso (kg) / Estatura (m)²
//		
//		double peso = 70;
//		double estatura = 1.75*1.75;
//		System.out.println("La masa corporal de dicha persona equivale a " + peso  / estatura);
//	
		
		
	//EJERCICIO 3 - Convierte una semana (7 días) en minutos.
		
		//1 día = 24h 1h = 60 segundos
//		int dias = 7;
//		int horas = dias*24;
//		int minutos = horas*60;
//		System.out.println("Una semana en minutos equivale a " + minutos) ;
		
	//EJERCICIO 4 - Calcula el volumen de un cilindro que tiene un radio de 3 metros y una altura de 5 metros.
		
		// V = πr²h (r= radio h= altura)
//		int radio=3;
//		int altura=5;
//		double volumen= 3.14*(radio*radio)*altura;
//		System.out.println("El volumen del cilindro es de "+ volumen + "m³");
		
		
	//EJERCICIO 5 - Si tienes un rectángulo con una longitud de 6 metros y una anchura de 4 metros, calcula su perímetro.
		
		// Perimetro rectángulo = 2 * (base + altura)
//		double largo = 6;
//        double ancho = 4;
//        double perimetroRectangulo = 2 * (largo + ancho);
//        System.out.println("Perímetro del rectángulo: " + perimetroRectangulo + " m");
		
	// EJERCICIO 6 - Si se ha recorrido una distancia de 150 km en un tiempo de 2 horas, calcula la velocidad media.
		
//		// Vel media = Distancia total entre tiempo total
//        double distancia = 150;
//        double tiempo = 2;
//        double velocidadMedia = distancia / tiempo;
//        System.out.println("Velocidad media: " + velocidadMedia + " km/h");
//	
	// EJERCICIO 7 - Si un producto tiene un precio inicial de 102,4 euros y la tasa de IVA es del 21%, calcula su precio final.
		
		//IVA = multiplicar el precio sin IVA por 1,21
//        double precioInicial = 102.4;
//        double iva = 0.21;
//        double precioFinal = precioInicial * (1 + iva);
//        System.out.println("Precio final con IVA: " + precioFinal + " €");
		
		
	//EJERCICIO 8 - Para una temperatura de 30 grados Celsius calcula los grados Fahrenheit equivalentes.
		
		//(0 °C × 9 / 5) + 32 = 32 °F
//		double celsius = 30;
//		double fahrenheit = (celsius * 9/5) + 32;
//        System.out.println("30 grados celsius equivalen a: " + fahrenheit + " grados fahrenheit");
		
		
		// EJERCICIOS OPCIONALES
		
        // Se utiliza una regla de tres "7,5/100*350"
//        double Cada100km = 7.5; 
//        double distancia = 350;    
//        double consumoTotal = (Cada100km / 100) * distancia;
//        System.out.println("Consume: " + consumoTotal + "L en 350km");
        
        // Otra regla de tres 400/4*7
//        double harinaPara4 = 400; // gramos
//        int personas4 = 4;
//        int personas7 = 7;
//        double harinaPara7 = (harinaPara4 / personas4) * personas7;
//        System.out.println("Seran necesarias: " + harinaPara7 + "g de harina para 7 personas");
        
//        // Regla de tres
//        double azucarPara8 = 250;
//        int porciones8 = 8;
//        int porciones15 = 15;
//        double azucarPara15 = (azucarPara8 / porciones8) * porciones15;
//        System.out.println("Se necesitan " + azucarPara15 + "g para 15 porciones");
        
        
//        // Formula volumen prisma rectangular =  largo × ancho × altura (V = l × a × h)
//        double largo = 5;
//        double ancho = 3;
//        double alto = 4;
//        double volumen = largo * ancho * alto;
//        System.out.println("Volumen del prisma: " + volumen + " m³");
        
//        // 90*2,5
//        double velocidad = 90;
//        double tiempo = 2.5;
//        double distancia = velocidad * tiempo;
//        System.out.println("Distancia recorrida por el tren: " + distancia + " km");
        
        // 15*40 💔
//        double Hora = 15;
//        double Semanal = 40;
//        double salarioSemanal = Hora * Semanal;
//        System.out.println("Su salario semanal equivale a " + salarioSemanal + " €");
        
		
		
		

		
	}

}
