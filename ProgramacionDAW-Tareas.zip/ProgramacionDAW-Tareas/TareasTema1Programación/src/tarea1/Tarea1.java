package tarea1;

public class Tarea1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//EJERCICIO 1 - Crear tres variables con los valores 10, 20 y 30. Crear una cuarta variable con la suma de las anteriores.

//		int a = 10;
//		int b = 20;
//		int c = 30;
//
//		int d = a + b + c;
//		System.out.println(d);
		
		
// EJERCICIO 2 - Crear tres variables con los valores 10, 19,5 y 30,5. Crear una cuarta variable con la suma de las anteriores.
		
//int a = 10;
//double b = 19.5;
//double c = 30.5;
//
//double d=a+b+c;
//System.out.println(d);
		
		
// EJERCICIO 3 - Crear dos variables con los valores 4 y 9. 
//Crear una nueva variable con la multiplicación de ambas. Restar después a esta última variable las dos primeras.
//int a = 4;
//int b = 9;
//int c = a*b;
//int d = c-(a+b);
//System.out.println(d);
//		
		
		
// EJERCICIO 4 - Crear dos variables, una con el valor 15 y otra con el valor 5,5.
// Obtener una tercera variable con el resultado de la división de las dos variables anteriores.
//int a = 15;
//double b = 5.5;
//double c = a/b;
//System.out.println(c);
		
//EJERCICIO 5 - Crear una variable con el valor 4. 
//Obtener el módulo 2, luego en otra instrucción el módulo 3 y luego el módulo 4 de esta variable. (La operación módulo es %).
//int a = 4;
//int b = a%2;
//System.out.println(b);
//int c = a%3;
//System.out.println(c);
//int d = a%4;
//System.out.println(d);

		
		
//EJERCICIO 6 - Crear una variable que guarde el carácter ‘v’, otra el carácter ‘V’ y otra que contenga un espacio. 
//char a='v';
//char b='V';
//char c=' ';
//System.out.println(a);
//System.out.println(b);
//System.out.println(c);
		
		
//EJERCICIO 7 - Crear una variable booleana y darle el valor true. 
//Crear otra con el valor false. Imprimir el valor de la primera y el valor de la segunda negada (!).
//boolean a=true;
//boolean b=false;
//System.out.println(a);
//System.out.println(!b);

		
//EJERCICIO 8 - Partiendo del número 1000 dividirlo entre 3, luego dividirlo por 8, a continuación dividirlo entre 5.7.
//Finalmente obtener el cuadrado de este número final.
//double a = 1000;
//double b = a/3.0;
//double c = b/8.0;
//double d = c/5.7;
//double e = d*d;
//System.out.println(e);


	}

}
