package tarea1RefugioA;

public class Canario extends Animal {

	
	//ATRIBUTOS ---------------------------
	
	private String colorPluma;

	
	//CONSTRUCTORES -------------------------
	
	public Canario(String nombre, int edad, String colorPluma) {
		super(nombre, edad);
		this.colorPluma = colorPluma;
	}

	
	//GETTERS Y SETTERS ---------------------------------

	public String getColorPluma() {
		return colorPluma;
	}


	public void setColorPluma(String colorPluma) {
		this.colorPluma = colorPluma;
	}
	
	
	public void emitirSonido() {
		System.out.println("Pío pío soy un canario llamado " + this.nombre);
	}
	
	public String getTipo() {		
		return "Canario";
				
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
