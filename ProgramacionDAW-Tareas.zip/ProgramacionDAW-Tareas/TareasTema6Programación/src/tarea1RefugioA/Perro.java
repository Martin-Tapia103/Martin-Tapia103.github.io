package tarea1RefugioA;

public class Perro extends Animal {

	
	//ATRIBUTOS ------------------------------------
	
	private String raza;

	
	//CONSTRUCTORES ----------------------------------
	
	public Perro(String nombre, int edad, String raza) {
		super(nombre, edad);
		this.raza = raza;
	}


	//GETTERS Y SETTERS ----------------------------
	
	public String getRaza() {
		return raza;
	}


	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	
	public void emitirSonido() {
		System.out.println("Guau guau, soy un perro llamado " + this.nombre);
	}
	
	public String getTipo() {
		return "Perro";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
