package tarea1RefugioA;

public class Gato extends Animal {

	//ATRIBUTOS ----------------------------------------------
	
	private boolean esCazador;

	
	//CONTRUCTORES -------------------------------------------
	
	public Gato(String nombre, int edad, boolean esCazador) {
		super(nombre, edad);
		this.esCazador = esCazador;
	}


	//GETTERS Y SETTERS --------------------------------------
	
	
	public boolean isEsCazador() {	
		return esCazador;
	}


	public void setEsCazador(boolean esCazador) {
		this.esCazador = esCazador;
	}
	
	
	public void emitirSonido() {
		System.out.println("Miau soy un perro gato llamado " + this.nombre);
	}
	
	public String getTipo() {		
		return "Gato";
				
	}
	
	public String convertirCazador() {
		
		if (this.esCazador == true) {
			return "si";
		} else {
			return "no";			
		}	 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
