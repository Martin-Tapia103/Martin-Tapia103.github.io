package tarea1RefugioA;

public class Animal {

	
	//ATRIBUTOS ------------------------------------------------------
	
	protected String nombre;
	protected int edad;	
	
	
	//CONSTRUCTORES --------------------------------------------------
	
	public Animal(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}
	
	
	//GETTERS Y SETTERS -----------------------------------------------
	
	
	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	public void emitirSonido() {
		System.out.println("El animal emite ruido");
	}
	
	public String getTipo() {
		return "No se sabe el tipo de animal";
	}


	//TO STRING ---------------------------------------------------------------
	
	@Override
	public String toString() {
		return "nombre: " + nombre + ", edad: " + edad;
	}
	
	
	
	
	
	
	
}
