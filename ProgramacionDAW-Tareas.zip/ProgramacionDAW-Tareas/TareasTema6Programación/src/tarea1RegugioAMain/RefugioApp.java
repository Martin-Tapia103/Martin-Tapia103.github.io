package tarea1RegugioAMain;

import tarea1RefugioA.Animal;
import tarea1RefugioA.Canario;
import tarea1RefugioA.Gato;
import tarea1RefugioA.Perro;

import java.util.*;

public class RefugioApp {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static Scanner scBoolean = new Scanner(System.in);
	static boolean seguir = true; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		 System.out.println("Dime el nombre de tu perro");
		 
		 String nombrePerro = scLine.nextLine();

		 System.out.println("Dime la edad de " + nombrePerro);

		 int edadPerro = scInt.nextInt();

		 System.out.println("Dime la raza de " + nombrePerro);

		 String razaDePerro = scLine.nextLine();


		// ----------------------------------------------------------------------------------------


		 System.out.println("Dime el nombre de tu gato");

		 String nombreGato = scLine.nextLine();

		 System.out.println("Dime la edad de " + nombreGato);

		 int edadGato = scInt.nextInt();

		 System.out.println("¿Es cazador? (true/false)");

		 boolean esCazador = scBoolean.nextBoolean();


		//-------------------------------------------------------------------------------------------	 


		 System.out.println("Dime el nombre de tu canario");

		 String nombreCanario = scLine.nextLine();

		 System.out.println("Dime la edad de " + nombreCanario);


		 int edadCanario = scInt.nextInt();

		 System.out.println("Dime el color de las plumas de " + nombreCanario);

		 String plumas = scLine.nextLine();
		 

		//---------------------------------------------------------------------------------------------	
		
		System.out.println("=== ALTA INICIAL DE ANIMALES EN EL REFUGIO ===\n");
		
		// ----------------------------
		
		System.out.println("=== Alta de PERRO ===");

		Animal a0 = new Perro(nombrePerro, edadPerro, razaDePerro);
		
		System.out.println("Nombre del perro: " + a0.getNombre());
		System.out.println("Edad del perro: " + a0.getEdad());
		
		Perro p0 = (Perro) a0;			
		System.out.println("Raza del perro: " + p0.getRaza() + "\n");
		
		// ----------------------------
		
		System.out.println("=== Alta de GATO ===");
		
		Animal a1 = new Gato(nombreGato, edadGato, esCazador);
		
		System.out.println("Nombre del gato: " + a1.getNombre());
		System.out.println("Edad del gato: " + a1.getEdad());
		
		Gato g0 = (Gato) a1;
		System.out.println("¿Es cazador? (sí/no): " + g0.convertirCazador() + "\n");
		
		// ----------------------------
		
		System.out.println("=== Alta de CANARIO ===");
		
		Animal a2 = new Canario(nombreCanario, edadCanario, plumas);
		
		System.out.println("Nombre del canario: " + a2.getNombre());
		System.out.println("Edad del canario: " + a2.getEdad());
		
		Canario c0 = (Canario) a2;
		System.out.println("Color de la pluma: " + c0.getColorPluma() + "\n");
		
		// -------------------------------------------------------------------------------------------------------
		
	
		do {
		
		System.out.println("\n========== MENÚ REFUGIO ==========");
		System.out.println("1. Escuchar a todos los animales");
		System.out.println("2. Ver fichas de los animales");			
		System.out.println("3. Mostrar animal más viejo");
		System.out.println("4. Elegir un animal y mostrar su ficha");
		System.out.println("0. Salir");
		
		int opcion = scInt.nextInt();
		switch (opcion) {
		case 1:
			sonidosDeLosAnimales(a0,a1,a2);
			break;
			
		case 2:
			fichasDeLosAnimales(a0,p0,a1,g0,a2,c0);
			break;
			
		case 3:
			masViejo(a0,p0,a1,g0,a2,c0);
			break;
			
		case 4:
			animalConcreto(a0,p0,a1,g0,a2,c0);
			break;
			
		case 0:
			salirDelMenu();
			break;
		
		}
					
	} while(seguir);  
	
	System.out.println("Saliendo del refugio...");
}




	//CASOS ----------------------------------------------------------
	
		
	private static void salirDelMenu() {
		seguir = false;
	}

	
	private static void sonidosDeLosAnimales(Animal a0, Animal a1, Animal a2) {
		System.out.println("--- Sonido de todos los animales ---");
		a0.emitirSonido();
		a1.emitirSonido();
		a2.emitirSonido();		
	}

	private static void fichasDeLosAnimales(Animal a0, Perro p0, Animal a1, Gato g0, Animal a2, Canario c0) {
		System.out.println("--- Fichas de los animales ---");
		System.out.println("Tipo:" + a0.getTipo() + ", " + a0.toString() + " raza: " + p0.getRaza());
		a0.emitirSonido();
		System.out.println("Tipo:" + a1.getTipo() + ", " + a1.toString() + " es cazador: " + g0.convertirCazador());
		a1.emitirSonido();
		System.out.println("Tipo:" + a2.getTipo() + ", " + a2.toString() + " color de pluma: " + c0.getColorPluma());
		a2.emitirSonido();
	}
	
	
	private static void masViejo(Animal a0, Perro p0, Animal a1, Gato g0, Animal a2, Canario c0) {
	System.out.println("--- Animal más viejo ---");
	System.out.println("El animal mas viejo es: ");

	 if ( a0.getEdad() >= a1.getEdad() && a0.getEdad() >= a2.getEdad() ) {
	 System.out.println("Tipo:" + a0.getTipo() + "," + a0.toString() + ", raza: " + p0.getRaza());
	 a0.emitirSonido();

	 } else if ( a1.getEdad() > a0.getEdad() && a1.getEdad() > a2.getEdad() ) {
	 System.out.println("Tipo:" + a1.getTipo() + "," + a1.toString() + ", es cazador: " + g0.convertirCazador());
	 a1.emitirSonido();

	 } else if ( a2.getEdad() > a0.getEdad() && a2.getEdad() > a1.getEdad()) {
	 System.out.println("Tipo:" + a2.getTipo() + "," + a2.toString() + ", color de las plumas: " + c0.getColorPluma());
	 a2.emitirSonido(); 
	 }
	
}

	private static void animalConcreto(Animal a0, Perro p0, Animal a1, Gato g0, Animal a2, Canario c0) {
		System.out.println("--- Probar un animal concreto ---");
		System.out.println("¿Que animal quieres probar?");
		 System.out.println("1. Primero");
		 System.out.println("2. Segundo");
		 System.out.println("3. Tercero");
		 System.out.println("Elige una opcion");

		 int opcion2 = scInt.nextInt();

		 switch ( opcion2 ) {
		 
		 case 1:
		 System.out.println("Has elegido a: ");
		 System.out.println("Tipo:" + a0.getTipo() + "," + a0.toString() + ", raza: " + p0.getRaza());
		 a0.emitirSonido();
		 break;

		 case 2:
		 System.out.println("Has elegido a: ");
		 System.out.println("Tipo:" + a1.getTipo() + "," + a1.toString() + ", es cazador: " + g0.convertirCazador());
		 a1.emitirSonido();
		 break;

		 case 3:
		 System.out.println("Has elegido a: ");
		 System.out.println("Tipo:" + a2.getTipo() + "," + a2.toString() + ", color de las plumas: " + c0.getColorPluma());
		 a2.emitirSonido();
		 break;

		 }		
	}	
	
	
}		
		
		
		
		
		
		
		
		
		
		
		
		
	


