package tarea2GestorContenidoMultimediaMain;

import java.util.Scanner;
import tarea2GestorContenidoMultimedia.*;

public class Menu {

	static Scanner scInt = new Scanner(System.in);
	static Scanner scLine = new Scanner(System.in);
	static boolean seguir = true;

	static Contenido contenido1 = null;
	static Contenido contenido2 = null;
	static Contenido contenido3 = null;

	public static void main(String[] args) {

		do {
			System.out.println("=========== GESTOR MULTIMEDIA ===========");
			System.out.println("\n1.- Crear/registrar contenido");
			System.out.println("2.- Mostrar ficha");
			System.out.println("3.- Mostrar detalle");
			System.out.println("4.- Reproducir");
			System.out.println("5.- Descargar");
			System.out.println("6.- Calcular coste mensual");
			System.out.println("7.- Vaciar hueco");
			System.out.println("0.- SALIR");
			System.out.print("\nOpción: ");

			int opcion = scInt.nextInt();

			switch (opcion) {
			
			case 1: 
				CrearORegistrarContenido();
				break;
				
			case 2: 
				MostrarFicha(); 
				break;
				
			case 3: 
				MostrarDetalle();
				break;
				
			case 4: 
				Reproducir(); 
				break;
				
			case 5: 
				Descargar(); 
				break;
				
			case 6: 
				CalcularCosteMensual(); 
				break;
				
			case 7: 
				VaciarHueco(); 
				break;
				
			case 0: 
				salirDelMenu(); 
				break;
			}
			
			
		} while (seguir);

		System.out.println("Adeu");
	}

	
	
	//METODOS -------------------------------------------------------------
	
	
	private static Contenido obtenerHueco(int hueco) {
		if (hueco == 1) return contenido1;
		if (hueco == 2) return contenido2;
		if (hueco == 3) return contenido3;
		return null;
	}

	private static void asignarHueco(int hueco, Contenido contenido) {
		if (hueco == 1) contenido1 = contenido;
		if (hueco == 2) contenido2 = contenido;
		if (hueco == 3) contenido3 = contenido;
	}

	private static void CrearORegistrarContenido() {
		System.out.print("Hueco (1-3): ");
		int huecoX = scInt.nextInt();

		System.out.println("Tipo (1=Pelicula, 2=Podcast, 3=Curso): ");
		int tipo = scInt.nextInt();

		System.out.println("ID: ");
		String id = scLine.nextLine();
		System.out.println("Título: ");
		String titulo = scLine.nextLine();
		System.out.println("Año: ");
		String anyo = scLine.nextLine();
		System.out.println("Premium (s/n): ");
		boolean premium = scLine.nextLine().equalsIgnoreCase("s");

		Contenido contenidoX = null;

		if (tipo == 1) {
			System.out.println("Director: ");
			String director = scLine.nextLine();
			System.out.println("Duración (min): ");
			int duracionZ = scInt.nextInt();
			System.out.println("Calidad (GB): ");
			double calidadZ = scInt.nextDouble();
			contenidoX = new Pelicula(id, titulo, anyo, premium, director, duracionZ, calidadZ);
		} else if (tipo == 2) {
			System.out.println("Anfitrión: ");
			String anfitrionZ = scLine.nextLine();
			System.out.println("Episodios: ");
			int episodiosZ = scInt.nextInt();
			System.out.println("Duración por episodio (min): ");
			int duracionZ = scInt.nextInt();
			contenidoX = new Podcast(id, titulo, anyo, premium, anfitrionZ, episodiosZ, duracionZ);
		} else if (tipo == 3) {
			System.out.println("Plataforma: ");
			String plataformaZ = scLine.nextLine();
			System.out.println("Horas: ");
			int horasZ = scInt.nextInt();
			System.out.println("Materiales (MB): ");
			double materialesZ = scInt.nextDouble();
			contenidoX = new CursoOnline(id, titulo, anyo, premium, plataformaZ, horasZ, materialesZ);
		}

		asignarHueco(huecoX, contenidoX);
		System.out.println("Contenido guardado en hueco " + huecoX);
	}

	private static void MostrarFicha() {
		System.out.println("Hueco (1-3): ");
		Contenido contenidoZ = obtenerHueco(scInt.nextInt());
		if (contenidoZ != null) System.out.println(contenidoZ.ficha());
	}

	private static void MostrarDetalle() {
		System.out.println("Hueco (1-3): ");
		Contenido contenidoC = obtenerHueco(scInt.nextInt());
		if (contenidoC != null) contenidoC.mostrarDetalle();
	}

	private static void Reproducir() {
		System.out.print("Hueco (1-3): ");
		Contenido contenidoV = obtenerHueco(scInt.nextInt());
		if (contenidoV instanceof Reproducible reproducibleZ) {
			reproducibleZ.reproducir();
			System.out.println("Duración (segundos): " + reproducibleZ.duracionSegundos());
		} else {
			System.out.println("Este contenido no se puede reproducir.");
		}
	}

	private static void Descargar() {
		System.out.print("Hueco (1-3): ");
		Contenido contenidoB = obtenerHueco(scInt.nextInt());

		if (contenidoB instanceof Descargable) {
			Descargable descargableZ = (Descargable) contenidoB;
			descargableZ.descargar();
			System.out.println("Tamaño (MB): " + descargableZ.tamanyoMB());
		} else {
			System.out.println("Este contenido no se puede descargar.");
		}
	}

	private static void CalcularCosteMensual() {
		System.out.print("Hueco (1-3): ");
		Contenido contenidoN = obtenerHueco(scInt.nextInt());
		if (contenidoN != null) {
			System.out.println("Coste mensual: " + contenidoN.costeMensual() + " €");
		}
	}

	private static void VaciarHueco() {
		System.out.print("Hueco (1-3): ");
		asignarHueco(scInt.nextInt(), null);
		System.out.println("Hueco vaciado.");
	}

	private static void salirDelMenu() {
		System.out.println("¿SEGURO? S/N: ");
		if (scLine.nextLine().equalsIgnoreCase("S")) seguir = false;
	}
}
	