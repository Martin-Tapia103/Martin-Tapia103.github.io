package tarea2GestorContenidoMultimedia;

public interface Reproducible {

	public void reproducir();
	
	public int duracionSegundos();	
	
}
