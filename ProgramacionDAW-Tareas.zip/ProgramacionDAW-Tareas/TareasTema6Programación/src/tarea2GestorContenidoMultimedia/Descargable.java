package tarea2GestorContenidoMultimedia;

public interface Descargable {

	public double tamanyoMB();
	
	public void descargar();
	
}
