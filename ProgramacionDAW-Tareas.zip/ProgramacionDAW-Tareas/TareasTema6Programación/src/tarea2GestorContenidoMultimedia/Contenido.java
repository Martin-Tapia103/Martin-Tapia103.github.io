package tarea2GestorContenidoMultimedia;

public abstract class Contenido {

	
	//ATRIBUTOS ----------------------------------------------------
	
	protected String id;
	protected String titulo;
	protected String anyo;
	protected boolean premium; //true = si | false = no	
	
	
	
	//CONSTRUCTORES -------------------------------------------------
	
	public Contenido(String id, String titulo, String anyo, boolean premium) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.anyo = anyo;
		this.premium = premium;
	}

	public Contenido() {
		super();
	}
	
	
	
	//GETTERS Y SETTERS -----------------------------------------------

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAnyo() {
		return anyo;
	}

	public void setAnyo(String anyo) {
		this.anyo = anyo;
	}

	public boolean isPremium() {
		return premium;
	}

	public void setPremium(boolean premium) {
		this.premium = premium;
	}
	
	
	public String ficha() {
		
		return this.id + " - " + this.titulo + " (" + this.anyo + ") Premium=" + this.premium;
	}
	
	
	public abstract double costeMensual();
	
	public abstract void mostrarDetalle();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
