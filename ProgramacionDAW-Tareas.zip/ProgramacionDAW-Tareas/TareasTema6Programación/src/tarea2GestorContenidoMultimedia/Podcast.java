package tarea2GestorContenidoMultimedia;

public class Podcast extends Contenido implements Reproducible {
	
	
	//ATRIBUTOS -----------------------------------------------

	private String anfitrion;
	private int episodios;
	private int duracionMinPorEpisodio;
	
	
	//CONSTRUCTORES --------------------------------------------
	
	public Podcast(String id, String titulo, String anyo, boolean premium, String anfitrion, int episodios,
			int duracionMinPorEpisodio) {
		super(id, titulo, anyo, premium);
		this.anfitrion = anfitrion;
		this.episodios = episodios;
		this.duracionMinPorEpisodio = duracionMinPorEpisodio;
	}


	public Podcast() {
		super();
	}


	//GETTERS Y SETTERS --------------------------------------------------
	
	public String getAnfitrion() {
		return anfitrion;
	}


	public void setAnfitrion(String anfitrion) {
		this.anfitrion = anfitrion;
	}


	public int getEpisodios() {
		return episodios;
	}


	public void setEpisodios(int episodios) {
		this.episodios = episodios;
	}


	public int getDuracionMinPorEpisodio() {
		return duracionMinPorEpisodio;
	}


	public void setDuracionMinPorEpisodio(int duracionMinPorEpisodio) {
		this.duracionMinPorEpisodio = duracionMinPorEpisodio;
	}


	@Override
	public void reproducir() {
		System.out.println("Reproduciendo podcast: " + this.titulo + "...");
	}

	@Override
	public int duracionSegundos() {
		return this.episodios * this.duracionMinPorEpisodio * 60;
	}

	@Override
	public double costeMensual() {
		double base;

		if (this.premium) {
			base = 4.99;
		} else {
			base = 0.0;
		}

		return base + (this.episodios * 0.05);
	}

	@Override
	public void mostrarDetalle() {
		System.out.println("[PODCAST] " + this.ficha());
		System.out.println("Anfitrión: " + this.anfitrion);
		System.out.println("Episodios: " + this.episodios);
		System.out.println("Duración por episodio: " + this.duracionMinPorEpisodio + " min");
	}	
	
}
