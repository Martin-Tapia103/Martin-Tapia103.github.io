package tarea2GestorContenidoMultimedia;

public class Pelicula extends Contenido implements Reproducible, Descargable {

	
	//ATRIBUTOS -----------------------------------------
	
	private String director;
	private int duracionMin;
	private double calidadGB;
	
	
	//CONSTRUCTORES -------------------------------------
	
	public Pelicula(String id, String titulo, String anyo, boolean premium, String director, int duracionMin,
			double calidadGB) {
		super(id, titulo, anyo, premium);
		this.director = director;
		this.duracionMin = duracionMin;
		this.calidadGB = calidadGB;
	}


	public Pelicula() {
		super();
	}

	
	
	//GETTERS Y SETTERS ----------------------------------

	public String getDirector() {
		return director;
	}


	public void setDirector(String director) {
		this.director = director;
	}


	public int getDuracionMin() {
		return duracionMin;
	}


	public void setDuracionMin(int duracionMin) {
		this.duracionMin = duracionMin;
	}


	public double getCalidadGB() {
		return calidadGB;
	}


	public void setCalidadGB(double calidadGB) {
		this.calidadGB = calidadGB;
	}


	@Override
	public double tamanyoMB() {
		return calidadGB * 1024;
	}

	@Override
	public void descargar() {
		System.out.println("Descargando película '" + this.titulo + "' (" + this.tamanyoMB() + " MB)...");
	}

	@Override
	public void reproducir() {
		System.out.println("Reproduciendo película: " + this.titulo + "...");
	}

	@Override
	public int duracionSegundos() {
		return this.duracionMin * 60;
	}

	@Override
	public double costeMensual() {
		double base;

		if (this.premium) {
			base = 6.99;
		} else {
			base = 3.99;
		}

		return base + (this.calidadGB * 0.25);
	}
	
	@Override
	public void mostrarDetalle() {
		System.out.println("[PELÍCULA] " + this.ficha());
		System.out.println("Director: " + this.director);
		System.out.println("Duración: " + this.duracionMin + " min");
		System.out.println("Tamaño aprox.: " + this.calidadGB + " GB");
	}
	
	
} 
