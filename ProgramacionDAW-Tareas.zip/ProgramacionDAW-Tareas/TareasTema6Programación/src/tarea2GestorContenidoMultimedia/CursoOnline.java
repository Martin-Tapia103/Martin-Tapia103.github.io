package tarea2GestorContenidoMultimedia;

public class CursoOnline extends Contenido implements Descargable {

	
	//ATRIBUTOS --------------------------------------------------
	
	private String plataforma;
	private int horas;
	private double materialesMB;
	
	
	//CONSTRUCTORES ----------------------------------------------
	
	public CursoOnline(String id, String titulo, String anyo, boolean premium, String plataforma, int horas,
			double materialesMB) {
		super(id, titulo, anyo, premium);
		this.plataforma = plataforma;
		this.horas = horas;
		this.materialesMB = materialesMB;
	}


	public CursoOnline() {
		super();
	}

	
	
	//GETTERS Y SETTERS ---------------------------------------------

	public String getPlataforma() {
		return plataforma;
	}


	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}


	public int getHoras() {
		return horas;
	}


	public void setHoras(int horas) {
		this.horas = horas;
	}


	public double getMaterialesMB() {
		return materialesMB;
	}


	public void setMaterialesMB(double materialesMB) {
		this.materialesMB = materialesMB;
	}


	@Override
	public double tamanyoMB() {
		return materialesMB;
	}

	@Override
	public void descargar() {
		System.out.println("Descargando curso '" + titulo + "' (" + materialesMB + " MB)...");
	}

	@Override
	public double costeMensual() {
		double base;

		if (this.premium) {
			base = 9.99;
		} else {
			base = 5.99;
		}

		return base + (materialesMB / 1024.0) * 0.20;
	}

	@Override
	public void mostrarDetalle() {
		System.out.println("[CURSO ONLINE] " + this.ficha());
		System.out.println("Plataforma: " + this.plataforma);
		System.out.println("Horas: " + this.horas);
		System.out.println("Materiales: " + this.materialesMB + " MB");
	}
	
}
