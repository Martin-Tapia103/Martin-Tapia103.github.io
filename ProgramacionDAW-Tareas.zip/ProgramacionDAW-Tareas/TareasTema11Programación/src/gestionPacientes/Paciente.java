package gestionPacientes;

public class Paciente {

	private int id;
	private String dni;
	private String nombre;
	private int edad;
	private String numMovil;
	private double peso;
	private int asegurado;

	public Paciente(int id, String dni, String nombre, int edad, String numMovil, double peso, int asegurado) {
		this.id = id;
		this.dni = dni;
		this.nombre = nombre;
		this.edad = edad;
		this.numMovil = numMovil;
		this.peso = peso;
		this.asegurado = asegurado;
	}

	public Paciente(String dni, String nombre, int edad, String numMovil, double peso, int asegurado) {
		this.dni = dni;
		this.nombre = nombre;
		this.edad = edad;
		this.numMovil = numMovil;
		this.peso = peso;
		this.asegurado = asegurado;
	}

	public int getId() {
		return id;
	}

	public String getDni() {
		return dni;
	}

	public String getNombre() {
		return nombre;
	}

	public int getEdad() {
		return edad;
	}

	public String getNumMovil() {
		return numMovil;
	}

	public double getPeso() {
		return peso;
	}

	public int getAsegurado() {
		return asegurado;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public void setNumMovil(String numMovil) {
		this.numMovil = numMovil;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public void setAsegurado(int asegurado) {
		this.asegurado = asegurado;
	}
}