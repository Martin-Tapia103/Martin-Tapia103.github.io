package gestionPacientes;

import java.sql.*;
import java.util.*;

public class Main {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);

	private static final String URL = "jdbc:sqlite:clinica.db";

	public static void main(String[] args) {

		try (Connection conn = DriverManager.getConnection(URL)) {

			System.out.println("La conexión se ha establecido");

			baseDeDatos(conn);

			int opcion;

			do {
				System.out.println("\nGESTIÓN DE PACIENTES");
				System.out.println("1. Añadir paciente");
				System.out.println("2. Listar todos los pacientes");
				System.out.println("3. Buscar paciente");
				System.out.println("4. Actualizar paciente");
				System.out.println("5. Eliminar paciente");
				System.out.println("6. Listar pacientes asegurados");
				System.out.println("7. Listar pacientes mayores de edad");
				System.out.println("8. Listar pacientes en un rango de peso");
				System.out.println("9. Poner móvil si no lo tiene");
				System.out.println("0. Salir");
				System.out.print("Elige una opción: ");

				opcion = scInt.nextInt();
				scInt.nextLine();

				switch (opcion) {

				case 1:
					System.out.print("DNI: ");
					String dni = scLine.nextLine();

					System.out.print("Nombre: ");
					String nombre = scLine.nextLine();

					System.out.print("Edad: ");
					int edad = scInt.nextInt();
					scInt.nextLine();

					System.out.print("Móvil: ");
					String numMovil = scLine.nextLine();

					System.out.print("Peso: ");
					double peso = scInt.nextDouble();
					scInt.nextLine();

					System.out.print("1 asegurado, 0 no asegurado: ");
					int asegurado = scInt.nextInt();
					scInt.nextLine();

					insertarPaciente(conn, dni, nombre, edad, numMovil, peso, asegurado);
					break;

				case 2:
					listarPacientes(conn);
					break;

				case 3:
					buscarPacientes(conn);
					break;

				case 4:
					actualizarPaciente(conn);
					break;

				case 5:
					System.out.print("DNI del paciente a eliminar: ");
					String dniEliminar = scLine.nextLine();

					System.out.print("¿Seguro? S/N: ");
					String confirmacion = scLine.nextLine();

					if (confirmacion.equalsIgnoreCase("S")) {
						eliminarPaciente(conn, dniEliminar);
					} else {
						System.out.println("No se ha eliminado");
					}
					break;

				case 6:
					listarPacientesAsegurados(conn);
					break;

				case 7:
					listarPacientesMayoresEdad(conn);
					break;

				case 8:
					System.out.print("Peso mínimo: ");
					double pesoMin = scInt.nextDouble();
					scInt.nextLine();

					System.out.print("Peso máximo: ");
					double pesoMax = scInt.nextDouble();
					scInt.nextLine();

					listarPacientesPorPeso(conn, pesoMin, pesoMax);
					break;

				case 9:
					ponerMovilSiNoTiene(conn);
					break;

				case 0:
					System.out.println("Adiós");
					break;

				default:
					System.out.println("Opción incorrecta");
				}

			} while (opcion != 0);

		} catch (SQLException e) {
			System.out.println("Error en la conexión");
		}
	}

	private static void baseDeDatos(Connection conn) {

		String sql = """
				CREATE TABLE IF NOT EXISTS pacientes (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				dni TEXT NOT NULL UNIQUE,
				nombre TEXT NOT NULL,
				edad INTEGER NOT NULL,
				numMovil TEXT,
				peso REAL NOT NULL,
				asegurado INTEGER NOT NULL
				);
				""";

		try (Statement stmt = conn.createStatement()) {
			stmt.execute(sql);
		} catch (SQLException e) {
			System.out.println("Hay un error en la sentencia SQL");
		}
	}

	private static void insertarPaciente(Connection conn, String dni, String nombre, int edad, String numMovil,
			double peso, int asegurado) {

		String sql = "INSERT INTO pacientes(dni, nombre, edad, numMovil, peso, asegurado) VALUES(?, ?, ?, ?, ?, ?)";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, dni);
			pstmt.setString(2, nombre);
			pstmt.setInt(3, edad);
			pstmt.setString(4, numMovil);
			pstmt.setDouble(5, peso);
			pstmt.setInt(6, asegurado);

			pstmt.executeUpdate();

			System.out.println("Paciente añadido");

		} catch (SQLException e) {
			System.out.println("Hay un error al añadir el paciente");
		}
	}

	private static void listarPacientes(Connection conn) {

		String sql = "SELECT * FROM pacientes";

		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {

			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;
				mostrarPaciente(rs);
			}

			if (!encontrado) {
				System.out.println("No hay pacientes");
			}

		} catch (SQLException e) {
			System.out.println("Hay un error al listar los pacientes");
		}
	}

	private static void buscarPacientes(Connection conn) {

		System.out.println("\nBUSCAR PACIENTE");
		System.out.println("1. Por DNI");
		System.out.println("2. Por nombre");
		System.out.print("Elige una opción: ");

		int opcion = scInt.nextInt();
		scInt.nextLine();

		switch (opcion) {

		case 1:
			System.out.print("DNI: ");
			String dni = scLine.nextLine();
			buscarPorDni(conn, dni);
			break;

		case 2:
			System.out.print("Nombre: ");
			String nombre = scLine.nextLine();
			buscarPorNombre(conn, nombre);
			break;

		default:
			System.out.println("Opción incorrecta");
		}
	}

	private static void buscarPorDni(Connection conn, String dni) {

		String sql = "SELECT * FROM pacientes WHERE dni = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, dni);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				mostrarPaciente(rs);
			} else {
				System.out.println("Ningún paciente tiene ese DNI");
			}

		} catch (SQLException e) {
			System.out.println("Error al buscar por DNI");
		}
	}

	private static void buscarPorNombre(Connection conn, String nombre) {

		String sql = "SELECT * FROM pacientes WHERE nombre LIKE ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, "%" + nombre + "%");

			ResultSet rs = pstmt.executeQuery();

			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;
				mostrarPaciente(rs);
			}

			if (!encontrado) {
				System.out.println("No hay pacientes con ese nombre");
			}

		} catch (SQLException e) {
			System.out.println("Error al buscar por nombre");
		}
	}

	private static void actualizarPaciente(Connection conn) {

		System.out.print("DNI del paciente a actualizar: ");
		String dni = scLine.nextLine();

		String sqlBuscar = "SELECT * FROM pacientes WHERE dni = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sqlBuscar)) {

			pstmt.setString(1, dni);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				String nombreAntiguo = rs.getString("nombre");
				int edadAntigua = rs.getInt("edad");
				String movilAntiguo = rs.getString("numMovil");
				double pesoAntiguo = rs.getDouble("peso");
				int aseguradoAntiguo = rs.getInt("asegurado");

				System.out.println("Nombre actual: " + nombreAntiguo);
				System.out.print("Nuevo nombre: ");
				String nombreNuevo = scLine.nextLine();

				if (nombreNuevo.equals("")) {
					nombreNuevo = nombreAntiguo;
				}

				System.out.println("Edad actual: " + edadAntigua);
				System.out.print("Nueva edad: ");
				String edadTexto = scLine.nextLine();

				int edadNueva = edadAntigua;
				if (!edadTexto.equals("")) {
					edadNueva = Integer.parseInt(edadTexto);
				}

				System.out.println("Móvil actual: " + movilAntiguo);
				System.out.print("Nuevo móvil: ");
				String movilNuevo = scLine.nextLine();

				if (movilNuevo.equals("")) {
					movilNuevo = movilAntiguo;
				}

				System.out.println("Peso actual: " + pesoAntiguo);
				System.out.print("Nuevo peso: ");
				String pesoTexto = scLine.nextLine();

				double pesoNuevo = pesoAntiguo;
				if (!pesoTexto.equals("")) {
					pesoNuevo = Double.parseDouble(pesoTexto);
				}

				System.out.println("Asegurado actual: " + aseguradoAntiguo);
				System.out.print("Nuevo asegurado: ");
				String aseguradoTexto = scLine.nextLine();

				int aseguradoNuevo = aseguradoAntiguo;
				if (!aseguradoTexto.equals("")) {
					aseguradoNuevo = Integer.parseInt(aseguradoTexto);
				}

				String sqlActualizar = "UPDATE pacientes SET nombre = ?, edad = ?, numMovil = ?, peso = ?, asegurado = ? WHERE dni = ?";

				try (PreparedStatement pstmt2 = conn.prepareStatement(sqlActualizar)) {

					pstmt2.setString(1, nombreNuevo);
					pstmt2.setInt(2, edadNueva);
					pstmt2.setString(3, movilNuevo);
					pstmt2.setDouble(4, pesoNuevo);
					pstmt2.setInt(5, aseguradoNuevo);
					pstmt2.setString(6, dni);

					pstmt2.executeUpdate();

					System.out.println("Paciente actualizado");
				}

			} else {
				System.out.println("No existe un paciente con ese DNI");
			}

		} catch (SQLException e) {
			System.out.println("Error al actualizar el paciente");
		}
	}

	private static void eliminarPaciente(Connection conn, String dni) {

		String sql = "DELETE FROM pacientes WHERE dni = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, dni);

			int filas = pstmt.executeUpdate();

			if (filas > 0) {
				System.out.println("Paciente eliminado");
			} else {
				System.out.println("No existe un paciente con ese DNI");
			}

		} catch (SQLException e) {
			System.out.println("Error al eliminar el paciente");
		}
	}

	private static void listarPacientesAsegurados(Connection conn) {

		String sql = "SELECT * FROM pacientes WHERE asegurado = 1";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			ResultSet rs = pstmt.executeQuery();

			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;
				mostrarPaciente(rs);
			}

			if (!encontrado) {
				System.out.println("No hay pacientes asegurados");
			}

		} catch (SQLException e) {
			System.out.println("Error al listar pacientes asegurados");
		}
	}

	private static void listarPacientesMayoresEdad(Connection conn) {

		String sql = "SELECT * FROM pacientes WHERE edad >= 18";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			ResultSet rs = pstmt.executeQuery();

			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;
				mostrarPaciente(rs);
			}

			if (!encontrado) {
				System.out.println("No hay pacientes mayores de edad");
			}

		} catch (SQLException e) {
			System.out.println("Error al listar pacientes mayores de edad");
		}
	}

	private static void listarPacientesPorPeso(Connection conn, double pesoMin, double pesoMax) {

		String sql = "SELECT * FROM pacientes WHERE peso >= ? AND peso <= ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setDouble(1, pesoMin);
			pstmt.setDouble(2, pesoMax);

			ResultSet rs = pstmt.executeQuery();

			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;
				mostrarPaciente(rs);
			}

			if (!encontrado) {
				System.out.println("No hay pacientes en ese rango de peso");
			}

		} catch (SQLException e) {
			System.out.println("Error al listar pacientes por peso");
		}
	}

	private static void ponerMovilSiNoTiene(Connection conn) {

		System.out.print("DNI: ");
		String dni = scLine.nextLine();

		String sqlBuscar = "SELECT * FROM pacientes WHERE dni = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sqlBuscar)) {

			pstmt.setString(1, dni);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				String movil = rs.getString("numMovil");

				if (movil != null && !movil.equals("")) {
					System.out.println("Este paciente ya tiene móvil");
				} else {
					System.out.print("Introduce el móvil: ");
					String movilNuevo = scLine.nextLine();

					String sqlActualizar = "UPDATE pacientes SET numMovil = ? WHERE dni = ?";

					try (PreparedStatement pstmt2 = conn.prepareStatement(sqlActualizar)) {

						pstmt2.setString(1, movilNuevo);
						pstmt2.setString(2, dni);

						pstmt2.executeUpdate();

						System.out.println("Móvil actualizado");
					}
				}

			} else {
				System.out.println("No existe un paciente con ese DNI");
			}

		} catch (SQLException e) {
			System.out.println("Error al poner el móvil");
		}
	}

	private static void mostrarPaciente(ResultSet rs) throws SQLException {

		System.out.println(
				rs.getInt("id") + " | " +
				rs.getString("dni") + " | " +
				rs.getString("nombre") + " | " +
				rs.getInt("edad") + " | " +
				rs.getString("numMovil") + " | " +
				rs.getDouble("peso") + " | " +
				rs.getInt("asegurado")
		);
	}
}