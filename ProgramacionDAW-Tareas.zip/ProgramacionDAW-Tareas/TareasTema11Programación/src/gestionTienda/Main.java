package gestionTienda;

import java.sql.*;
import java.util.*;

public class Main {

    static Scanner scLine = new Scanner(System.in);
    static Scanner scInt = new Scanner(System.in);

    private static final String URL = "jdbc:sqlite:tienda.db";

    public static void main(String[] args) {

        try (Connection conn = DriverManager.getConnection(URL)) {

            System.out.println("La conexión se ha establecido");

            activarClavesForaneas(conn);
            baseDeDatos(conn);

            int opcion;

            do {
                System.out.println("\n===== GESTIÓN DE TIENDA =====");
                System.out.println("1. Añadir cliente");
                System.out.println("2. Mostrar clientes");
                System.out.println("3. Modificar cliente");
                System.out.println("4. Eliminar cliente");
                System.out.println("5. Añadir producto");
                System.out.println("6. Mostrar productos");
                System.out.println("7. Modificar producto");
                System.out.println("8. Eliminar producto");
                System.out.println("9. Crear pedido");
                System.out.println("10. Mostrar pedidos");
                System.out.println("11. Eliminar pedido");
                System.out.println("12. Buscar producto por código");
                System.out.println("13. Buscar cliente por código");
                System.out.println("14. Buscar pedido por código");
                System.out.println("0. Salir");
                System.out.print("Seleccione una opción: ");

                opcion = scInt.nextInt();
                scInt.nextLine();

                switch (opcion) {

                    case 1:
                        System.out.print("Código del cliente: ");
                        String codigoCliente = scLine.nextLine();

                        System.out.print("Nombre: ");
                        String nombreCliente = scLine.nextLine();

                        System.out.print("Teléfono: ");
                        String telefono = scLine.nextLine();

                        System.out.print("Email: ");
                        String email = scLine.nextLine();

                        insertarCliente(conn, codigoCliente, nombreCliente, telefono, email);
                        break;

                    case 2:
                        mostrarClientes(conn);
                        break;

                    case 3:
                        modificarCliente(conn);
                        break;

                    case 4:
                        System.out.print("Código del cliente a eliminar: ");
                        String codCliEliminar = scLine.nextLine();

                        System.out.print("¿Seguro? S/N: ");
                        String confirmacionCliente = scLine.nextLine();

                        if (confirmacionCliente.equalsIgnoreCase("S")) {
                            eliminarCliente(conn, codCliEliminar);
                        } else {
                            System.out.println("No se ha eliminado");
                        }
                        break;

                    case 5:
                        System.out.print("Código del producto: ");
                        String codigoProducto = scLine.nextLine();

                        System.out.print("Nombre del producto: ");
                        String nombreProducto = scLine.nextLine();

                        System.out.print("Precio: ");
                        double precio = scInt.nextDouble();
                        scInt.nextLine();

                        System.out.print("Stock: ");
                        int stock = scInt.nextInt();
                        scInt.nextLine();

                        insertarProducto(conn, codigoProducto, nombreProducto, precio, stock);
                        break;

                    case 6:
                        mostrarProductos(conn);
                        break;

                    case 7:
                        modificarProducto(conn);
                        break;

                    case 8:
                        System.out.print("Código del producto a eliminar: ");
                        String codProdEliminar = scLine.nextLine();

                        System.out.print("¿Seguro? S/N: ");
                        String confirmacionProducto = scLine.nextLine();

                        if (confirmacionProducto.equalsIgnoreCase("S")) {
                            eliminarProducto(conn, codProdEliminar);
                        } else {
                            System.out.println("No se ha eliminado");
                        }
                        break;

                    case 9:
                        System.out.print("Código del pedido: ");
                        String codigoPedido = scLine.nextLine();

                        System.out.print("Código del cliente: ");
                        String clientePedido = scLine.nextLine();

                        System.out.print("Código del producto: ");
                        String productoPedido = scLine.nextLine();

                        System.out.print("Cantidad: ");
                        int cantidad = scInt.nextInt();
                        scInt.nextLine();

                        crearPedido(conn, codigoPedido, clientePedido, productoPedido, cantidad);
                        break;

                    case 10:
                        mostrarPedidos(conn);
                        break;

                    case 11:
                        System.out.print("Código del pedido a eliminar: ");
                        String codPedEliminar = scLine.nextLine();

                        System.out.print("¿Seguro? S/N: ");
                        String confirmacionPedido = scLine.nextLine();

                        if (confirmacionPedido.equalsIgnoreCase("S")) {
                            eliminarPedido(conn, codPedEliminar);
                        } else {
                            System.out.println("No se ha eliminado");
                        }
                        break;

                    case 12:
                        System.out.print("Código del producto: ");
                        String codProdBuscar = scLine.nextLine();
                        buscarProductoPorCodigo(conn, codProdBuscar);
                        break;

                    case 13:
                        System.out.print("Código del cliente: ");
                        String codCliBuscar = scLine.nextLine();
                        buscarClientePorCodigo(conn, codCliBuscar);
                        break;

                    case 14:
                        System.out.print("Código del pedido: ");
                        String codPedBuscar = scLine.nextLine();
                        buscarPedidoPorCodigo(conn, codPedBuscar);
                        break;

                    case 0:
                        System.out.println("Adiós");
                        break;

                    default:
                        System.out.println("Opción incorrecta");
                }

            } while (opcion != 0);

        } catch (SQLException e) {
            System.out.println("Error en la conexión");
            System.out.println(e.getMessage());
        }
    }

    private static void activarClavesForaneas(Connection conn) {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON");
        } catch (SQLException e) {
            System.out.println("Error al activar claves foráneas");
        }
    }

    private static void baseDeDatos(Connection conn) {

        String sqlClientes = """
                CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_cliente TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL,
                telefono TEXT,
                email TEXT
                );
                """;

        String sqlProductos = """
                CREATE TABLE IF NOT EXISTS productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_producto TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL,
                precio REAL NOT NULL,
                stock INTEGER NOT NULL
                );
                """;

        String sqlPedidos = """
                CREATE TABLE IF NOT EXISTS pedidos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_pedido TEXT NOT NULL UNIQUE,
                codigo_cliente TEXT NOT NULL,
                codigo_producto TEXT NOT NULL,
                cantidad INTEGER NOT NULL,
                FOREIGN KEY (codigo_cliente) REFERENCES clientes(codigo_cliente),
                FOREIGN KEY (codigo_producto) REFERENCES productos(codigo_producto)
                );
                """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sqlClientes);
            stmt.execute(sqlProductos);
            stmt.execute(sqlPedidos);
        } catch (SQLException e) {
            System.out.println("Hay un error en la sentencia SQL");
            System.out.println(e.getMessage());
        }
    }

    private static void insertarCliente(Connection conn, String codigo, String nombre, String telefono, String email) {
        String sql = "INSERT INTO clientes(codigo_cliente, nombre, telefono, email) VALUES(?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            pstmt.setString(2, nombre);
            pstmt.setString(3, telefono);
            pstmt.setString(4, email);
            pstmt.executeUpdate();
            System.out.println("Cliente añadido");
        } catch (SQLException e) {
            System.out.println("Hay un error al añadir el cliente. Puede que el código esté repetido");
        }
    }

    private static void mostrarClientes(Connection conn) {
        String sql = "SELECT * FROM clientes";

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            boolean encontrado = false;

            while (rs.next()) {
                encontrado = true;
                mostrarCliente(rs);
            }

            if (!encontrado) {
                System.out.println("No hay clientes");
            }
        } catch (SQLException e) {
            System.out.println("Hay un error al mostrar los clientes");
        }
    }

    private static void modificarCliente(Connection conn) {
        System.out.print("Código del cliente a modificar: ");
        String codigo = scLine.nextLine();

        String sqlBuscar = "SELECT * FROM clientes WHERE codigo_cliente = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String nombreAntiguo = rs.getString("nombre");
                String telefonoAntiguo = rs.getString("telefono");
                String emailAntiguo = rs.getString("email");

                System.out.println("Nombre actual: " + nombreAntiguo);
                System.out.print("Nuevo nombre: ");
                String nombreNuevo = scLine.nextLine();
                if (nombreNuevo.equals("")) nombreNuevo = nombreAntiguo;

                System.out.println("Teléfono actual: " + telefonoAntiguo);
                System.out.print("Nuevo teléfono: ");
                String telefonoNuevo = scLine.nextLine();
                if (telefonoNuevo.equals("")) telefonoNuevo = telefonoAntiguo;

                System.out.println("Email actual: " + emailAntiguo);
                System.out.print("Nuevo email: ");
                String emailNuevo = scLine.nextLine();
                if (emailNuevo.equals("")) emailNuevo = emailAntiguo;

                String sqlActualizar = "UPDATE clientes SET nombre = ?, telefono = ?, email = ? WHERE codigo_cliente = ?";

                try (PreparedStatement pstmt2 = conn.prepareStatement(sqlActualizar)) {
                    pstmt2.setString(1, nombreNuevo);
                    pstmt2.setString(2, telefonoNuevo);
                    pstmt2.setString(3, emailNuevo);
                    pstmt2.setString(4, codigo);
                    pstmt2.executeUpdate();
                    System.out.println("Cliente actualizado");
                }
            } else {
                System.out.println("No existe un cliente con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al modificar el cliente");
        }
    }

    private static void eliminarCliente(Connection conn, String codigo) {
        String sql = "DELETE FROM clientes WHERE codigo_cliente = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            int filas = pstmt.executeUpdate();

            if (filas > 0) {
                System.out.println("Cliente eliminado");
            } else {
                System.out.println("No existe un cliente con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el cliente. Puede tener pedidos asociados");
        }
    }

    private static void insertarProducto(Connection conn, String codigo, String nombre, double precio, int stock) {
        String sql = "INSERT INTO productos(codigo_producto, nombre, precio, stock) VALUES(?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            pstmt.setString(2, nombre);
            pstmt.setDouble(3, precio);
            pstmt.setInt(4, stock);
            pstmt.executeUpdate();
            System.out.println("Producto añadido");
        } catch (SQLException e) {
            System.out.println("Hay un error al añadir el producto. Puede que el código esté repetido");
        }
    }

    private static void mostrarProductos(Connection conn) {
        String sql = "SELECT * FROM productos";

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            boolean encontrado = false;

            while (rs.next()) {
                encontrado = true;
                mostrarProducto(rs);
            }

            if (!encontrado) {
                System.out.println("No hay productos");
            }
        } catch (SQLException e) {
            System.out.println("Hay un error al mostrar los productos");
        }
    }

    private static void modificarProducto(Connection conn) {
        System.out.print("Código del producto a modificar: ");
        String codigo = scLine.nextLine();

        String sqlBuscar = "SELECT * FROM productos WHERE codigo_producto = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String nombreAntiguo = rs.getString("nombre");
                double precioAntiguo = rs.getDouble("precio");
                int stockAntiguo = rs.getInt("stock");

                System.out.println("Nombre actual: " + nombreAntiguo);
                System.out.print("Nuevo nombre: ");
                String nombreNuevo = scLine.nextLine();
                if (nombreNuevo.equals("")) nombreNuevo = nombreAntiguo;

                System.out.println("Precio actual: " + precioAntiguo);
                System.out.print("Nuevo precio: ");
                String precioTexto = scLine.nextLine();
                double precioNuevo = precioAntiguo;
                if (!precioTexto.equals("")) precioNuevo = Double.parseDouble(precioTexto);

                System.out.println("Stock actual: " + stockAntiguo);
                System.out.print("Nuevo stock: ");
                String stockTexto = scLine.nextLine();
                int stockNuevo = stockAntiguo;
                if (!stockTexto.equals("")) stockNuevo = Integer.parseInt(stockTexto);

                String sqlActualizar = "UPDATE productos SET nombre = ?, precio = ?, stock = ? WHERE codigo_producto = ?";

                try (PreparedStatement pstmt2 = conn.prepareStatement(sqlActualizar)) {
                    pstmt2.setString(1, nombreNuevo);
                    pstmt2.setDouble(2, precioNuevo);
                    pstmt2.setInt(3, stockNuevo);
                    pstmt2.setString(4, codigo);
                    pstmt2.executeUpdate();
                    System.out.println("Producto actualizado");
                }
            } else {
                System.out.println("No existe un producto con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al modificar el producto");
        }
    }

    private static void eliminarProducto(Connection conn, String codigo) {
        String sql = "DELETE FROM productos WHERE codigo_producto = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            int filas = pstmt.executeUpdate();

            if (filas > 0) {
                System.out.println("Producto eliminado");
            } else {
                System.out.println("No existe un producto con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el producto. Puede tener pedidos asociados");
        }
    }

    private static void crearPedido(Connection conn, String codigoPedido, String codigoCliente, String codigoProducto, int cantidad) {

        if (!existeCliente(conn, codigoCliente)) {
            System.out.println("No existe el cliente indicado");
            return;
        }

        if (!existeProducto(conn, codigoProducto)) {
            System.out.println("No existe el producto indicado");
            return;
        }

        int stockDisponible = obtenerStock(conn, codigoProducto);

        if (cantidad > stockDisponible) {
            System.out.println("No hay stock suficiente. Stock disponible: " + stockDisponible);
            return;
        }

        String sqlPedido = "INSERT INTO pedidos(codigo_pedido, codigo_cliente, codigo_producto, cantidad) VALUES(?, ?, ?, ?)";
        String sqlStock = "UPDATE productos SET stock = stock - ? WHERE codigo_producto = ?";

        try {
            conn.setAutoCommit(false);

            try (PreparedStatement pstmt = conn.prepareStatement(sqlPedido)) {
                pstmt.setString(1, codigoPedido);
                pstmt.setString(2, codigoCliente);
                pstmt.setString(3, codigoProducto);
                pstmt.setInt(4, cantidad);
                pstmt.executeUpdate();
            }

            try (PreparedStatement pstmt2 = conn.prepareStatement(sqlStock)) {
                pstmt2.setInt(1, cantidad);
                pstmt2.setString(2, codigoProducto);
                pstmt2.executeUpdate();
            }

            conn.commit();
            System.out.println("Pedido creado y stock actualizado");

        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println("Error al deshacer los cambios");
            }
            System.out.println("Error al crear el pedido. Puede que el código esté repetido");
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Error al restaurar autocommit");
            }
        }
    }

    private static void mostrarPedidos(Connection conn) {
        String sql = """
                SELECT pe.codigo_pedido, c.nombre AS nombre_cliente, p.nombre AS nombre_producto, pe.cantidad
                FROM pedidos pe
                INNER JOIN clientes c ON pe.codigo_cliente = c.codigo_cliente
                INNER JOIN productos p ON pe.codigo_producto = p.codigo_producto
                """;

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            boolean encontrado = false;

            while (rs.next()) {
                encontrado = true;
                System.out.println(
                        rs.getString("codigo_pedido") + " | " +
                        rs.getString("nombre_cliente") + " | " +
                        rs.getString("nombre_producto") + " | " +
                        rs.getInt("cantidad")
                );
            }

            if (!encontrado) {
                System.out.println("No hay pedidos");
            }
        } catch (SQLException e) {
            System.out.println("Hay un error al mostrar los pedidos");
        }
    }

    private static void eliminarPedido(Connection conn, String codigo) {
        String sql = "DELETE FROM pedidos WHERE codigo_pedido = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            int filas = pstmt.executeUpdate();

            if (filas > 0) {
                System.out.println("Pedido eliminado");
            } else {
                System.out.println("No existe un pedido con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el pedido");
        }
    }

    private static void buscarProductoPorCodigo(Connection conn, String codigo) {
        String sql = "SELECT * FROM productos WHERE codigo_producto = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                mostrarProducto(rs);
            } else {
                System.out.println("No existe un producto con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar el producto");
        }
    }

    private static void buscarClientePorCodigo(Connection conn, String codigo) {
        String sql = "SELECT * FROM clientes WHERE codigo_cliente = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                mostrarCliente(rs);
            } else {
                System.out.println("No existe un cliente con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar el cliente");
        }
    }

    private static void buscarPedidoPorCodigo(Connection conn, String codigo) {
        String sql = """
                SELECT pe.codigo_pedido, c.nombre AS nombre_cliente, p.nombre AS nombre_producto, pe.cantidad
                FROM pedidos pe
                INNER JOIN clientes c ON pe.codigo_cliente = c.codigo_cliente
                INNER JOIN productos p ON pe.codigo_producto = p.codigo_producto
                WHERE pe.codigo_pedido = ?
                """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println(
                        rs.getString("codigo_pedido") + " | " +
                        rs.getString("nombre_cliente") + " | " +
                        rs.getString("nombre_producto") + " | " +
                        rs.getInt("cantidad")
                );
            } else {
                System.out.println("No existe un pedido con ese código");
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar el pedido");
        }
    }

    private static boolean existeCliente(Connection conn, String codigo) {
        String sql = "SELECT codigo_cliente FROM clientes WHERE codigo_cliente = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Error al comprobar el cliente");
            return false;
        }
    }

    private static boolean existeProducto(Connection conn, String codigo) {
        String sql = "SELECT codigo_producto FROM productos WHERE codigo_producto = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Error al comprobar el producto");
            return false;
        }
    }

    private static int obtenerStock(Connection conn, String codigo) {
        String sql = "SELECT stock FROM productos WHERE codigo_producto = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("stock");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el stock");
        }

        return 0;
    }

    private static void mostrarCliente(ResultSet rs) throws SQLException {
        System.out.println(
                rs.getString("codigo_cliente") + " | " +
                rs.getString("nombre") + " | " +
                rs.getString("telefono") + " | " +
                rs.getString("email")
        );
    }

    private static void mostrarProducto(ResultSet rs) throws SQLException {
        System.out.println(
                rs.getString("codigo_producto") + " | " +
                rs.getString("nombre") + " | " +
                rs.getDouble("precio") + " | " +
                rs.getInt("stock")
        );
    }
}
