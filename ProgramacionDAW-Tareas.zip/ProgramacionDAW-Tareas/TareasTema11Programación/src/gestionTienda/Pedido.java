package gestionTienda;

public class Pedido {

    private int id;
    private String codigoPedido;
    private String codigoCliente;
    private String codigoProducto;
    private int cantidad;

    public Pedido(int id, String codigoPedido, String codigoCliente, String codigoProducto, int cantidad) {
        this.id = id;
        this.codigoPedido = codigoPedido;
        this.codigoCliente = codigoCliente;
        this.codigoProducto = codigoProducto;
        this.cantidad = cantidad;
    }

    public Pedido(String codigoPedido, String codigoCliente, String codigoProducto, int cantidad) {
        this.codigoPedido = codigoPedido;
        this.codigoCliente = codigoCliente;
        this.codigoProducto = codigoProducto;
        this.cantidad = cantidad;
    }

    public int getId() {
        return id;
    }

    public String getCodigoPedido() {
        return codigoPedido;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCodigoPedido(String codigoPedido) {
        this.codigoPedido = codigoPedido;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
