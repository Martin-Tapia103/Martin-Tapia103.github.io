package gestionTienda;

public class Cliente {

    private int id;
    private String codigoCliente;
    private String nombre;
    private String telefono;
    private String email;

    public Cliente(int id, String codigoCliente, String nombre, String telefono, String email) {
        this.id = id;
        this.codigoCliente = codigoCliente;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }

    public Cliente(String codigoCliente, String nombre, String telefono, String email) {
        this.codigoCliente = codigoCliente;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
