package gestionLibrosOpcional;

import java.sql.*;
import java.time.Year;
import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);
	private static final String URL = "jdbc:sqlite:biblioteca.db";

	public static void main(String[] args) {

		try (Connection conn = DriverManager.getConnection(URL)) {

			System.out.println("La conexión se ha establecido");
			baseDeDatos(conn);

			int opcion;

			do {
				System.out.println("\nGESTIÓN DE BIBLIOTECA");
				System.out.println("1. Añadir libro");
				System.out.println("2. Listar todos los libros");
				System.out.println("3. Buscar libro");
				System.out.println("4. Actualizar libro");
				System.out.println("5. Eliminar libro");
				System.out.println("6. Listar libros disponibles");
				System.out.println("7. Búsqueda avanzada");
				System.out.println("8. Listar libros ordenados");
				System.out.println("0. Salir");
				System.out.print("Elige una opción: ");

				opcion = leerEntero();

				switch (opcion) {

				case 1:
					añadirLibro(conn);
					break;

				case 2:
					listarLibros(conn);
					break;

				case 3:
					buscarLibros(conn);
					break;

				case 4:
					actualizarLibro(conn);
					break;

				case 5:
					System.out.print("ID del libro a eliminar: ");
					int idEliminar = leerEntero();

					System.out.print("¿Seguro? S/N: ");
					String confirmacion = sc.nextLine();

					if (confirmacion.equalsIgnoreCase("S")) {
						eliminarLibro(conn, idEliminar);
					} else {
						System.out.println("Eliminación cancelada");
					}
					break;

				case 6:
					listarLibrosDisponibles(conn);
					break;

				case 7:
					busquedaAvanzada(conn);
					break;

				case 8:
					listarLibrosOrdenados(conn);
					break;

				case 0:
					System.out.println("Adeu");
					break;

				default:
					System.out.println("Opción incorrecta");
				}

			} while (opcion != 0);

		} catch (SQLException e) {
			System.out.println("Error de conexión con la base de datos");
		}
	}

	private static void baseDeDatos(Connection conn) {

		String sql = """
				CREATE TABLE IF NOT EXISTS libros (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				titulo TEXT NOT NULL,
				autor TEXT NOT NULL,
				anio INTEGER,
				genero TEXT,
				disponible INTEGER
				);
				""";

		try (Statement stmt = conn.createStatement()) {
			stmt.execute(sql);
		} catch (SQLException e) {
			System.out.println("Error al crear la tabla");
		}
	}

	private static void añadirLibro(Connection conn) {

		System.out.print("Título: ");
		String titulo = sc.nextLine();

		System.out.print("Autor: ");
		String autor = sc.nextLine();

		System.out.print("Año: ");
		int anio = leerEntero();

		System.out.print("Género: ");
		String genero = sc.nextLine();

		System.out.print("Disponible, 1 sí, 0 no: ");
		int disponible = leerEntero();

		if (!validarDatos(titulo, autor, anio, genero, disponible)) {
			return;
		}

		if (existeLibro(conn, titulo, autor, anio)) {
			System.out.println("No se puede insertar. Ese libro ya existe");
			return;
		}

		insertarLibro(conn, titulo, autor, anio, genero, disponible);
	}

	private static boolean validarDatos(String titulo, String autor, int anio, String genero, int disponible) {

		int anioActual = Year.now().getValue();

		if (titulo.isBlank()) {
			System.out.println("El título no puede estar vacío");
			return false;
		}

		if (autor.isBlank()) {
			System.out.println("El autor no puede estar vacío");
			return false;
		}

		if (anio < 1500 || anio > anioActual) {
			System.out.println("El año debe estar entre 1500 y " + anioActual);
			return false;
		}

		if (genero.isBlank()) {
			System.out.println("El género no puede estar vacío");
			return false;
		}

		if (disponible != 0 && disponible != 1) {
			System.out.println("La disponibilidad solo puede ser 0 o 1");
			return false;
		}

		return true;
	}

	private static boolean existeLibro(Connection conn, String titulo, String autor, int anio) {

		String sql = "SELECT id FROM libros WHERE titulo = ? AND autor = ? AND anio = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			pstmt.setString(2, autor);
			pstmt.setInt(3, anio);

			ResultSet rs = pstmt.executeQuery();

			return rs.next();

		} catch (SQLException e) {
			System.out.println("Error al comprobar duplicados");
			return true;
		}
	}

	private static void insertarLibro(Connection conn, String titulo, String autor, int anio, String genero,
			int disponible) {

		String sql = "INSERT INTO libros(titulo, autor, anio, genero, disponible) VALUES(?, ?, ?, ?, ?)";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			pstmt.setString(2, autor);
			pstmt.setInt(3, anio);
			pstmt.setString(4, genero);
			pstmt.setInt(5, disponible);

			pstmt.executeUpdate();

			System.out.println("Libro añadido");

		} catch (SQLException e) {
			System.out.println("Error al añadir el libro");
		}
	}

	private static void listarLibros(Connection conn) {

		String sql = "SELECT * FROM libros";

		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al listar los libros");
		}
	}

	private static void buscarLibros(Connection conn) {

		System.out.println("\nBUSCAR LIBRO");
		System.out.println("1. Por ID");
		System.out.println("2. Por título");
		System.out.println("3. Por autor");
		System.out.print("Elige una opción: ");

		int opcion = leerEntero();

		switch (opcion) {

		case 1:
			System.out.print("ID: ");
			int id = leerEntero();
			buscarPorId(conn, id);
			break;

		case 2:
			System.out.print("Título: ");
			String titulo = sc.nextLine();
			buscarPorTitulo(conn, titulo);
			break;

		case 3:
			System.out.print("Autor: ");
			String autor = sc.nextLine();
			buscarPorAutor(conn, autor);
			break;

		default:
			System.out.println("Opción incorrecta");
		}
	}

	private static void actualizarLibro(Connection conn) {

		System.out.print("ID del libro a actualizar: ");
		int id = leerEntero();

		System.out.print("Título nuevo: ");
		String titulo = sc.nextLine();

		System.out.print("Autor nuevo: ");
		String autor = sc.nextLine();

		System.out.print("Año nuevo: ");
		int anio = leerEntero();

		System.out.print("Género nuevo: ");
		String genero = sc.nextLine();

		System.out.print("Disponible, 1 sí, 0 no: ");
		int disponible = leerEntero();

		if (!validarDatos(titulo, autor, anio, genero, disponible)) {
			return;
		}

		String sql = "UPDATE libros SET titulo = ?, autor = ?, anio = ?, genero = ?, disponible = ? WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			pstmt.setString(2, autor);
			pstmt.setInt(3, anio);
			pstmt.setString(4, genero);
			pstmt.setInt(5, disponible);
			pstmt.setInt(6, id);

			int filas = pstmt.executeUpdate();

			if (filas > 0) {
				System.out.println("Libro actualizado");
			} else {
				System.out.println("No existe ningún libro con ese ID");
			}

		} catch (SQLException e) {
			System.out.println("Error al actualizar el libro");
		}
	}

	private static void eliminarLibro(Connection conn, int idEliminar) {

		String sql = "DELETE FROM libros WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, idEliminar);

			int filas = pstmt.executeUpdate();

			System.out.println("Se han eliminado " + filas + " libros");

		} catch (SQLException e) {
			System.out.println("Error al eliminar el libro");
		}
	}

	private static void listarLibrosDisponibles(Connection conn) {

		String sql = "SELECT * FROM libros WHERE disponible = 1";

		try (PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al listar libros disponibles");
		}
	}

	private static void busquedaAvanzada(Connection conn) {

		System.out.print("Autor: ");
		String autor = sc.nextLine();

		System.out.print("Género: ");
		String genero = sc.nextLine();

		System.out.print("Disponible, 1 sí, 0 no: ");
		int disponible = leerEntero();

		if (disponible != 0 && disponible != 1) {
			System.out.println("La disponibilidad solo puede ser 0 o 1");
			return;
		}

		String sql = "SELECT * FROM libros WHERE autor LIKE ? AND genero LIKE ? AND disponible = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, "%" + autor + "%");
			pstmt.setString(2, "%" + genero + "%");
			pstmt.setInt(3, disponible);

			ResultSet rs = pstmt.executeQuery();

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error en la búsqueda avanzada");
		}
	}

	private static void listarLibrosOrdenados(Connection conn) {

		System.out.println("\nORDENAR LIBROS");
		System.out.println("1. Ordenar por título");
		System.out.println("2. Ordenar por autor");
		System.out.println("3. Ordenar por año");
		System.out.print("Elige una opción: ");

		int opcion = leerEntero();

		String campo;

		switch (opcion) {
		case 1:
			campo = "titulo";
			break;
		case 2:
			campo = "autor";
			break;
		case 3:
			campo = "anio";
			break;
		default:
			System.out.println("Opción incorrecta");
			return;
		}

		String sql = "SELECT * FROM libros ORDER BY " + campo;

		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al ordenar los libros");
		}
	}

	private static void buscarPorId(Connection conn, int id) {

		String sql = "SELECT * FROM libros WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al buscar por ID");
		}
	}

	private static void buscarPorTitulo(Connection conn, String titulo) {

		String sql = "SELECT * FROM libros WHERE titulo LIKE ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, "%" + titulo + "%");

			ResultSet rs = pstmt.executeQuery();

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al buscar por título");
		}
	}

	private static void buscarPorAutor(Connection conn, String autor) {

		String sql = "SELECT * FROM libros WHERE autor LIKE ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, "%" + autor + "%");

			ResultSet rs = pstmt.executeQuery();

			imprimirResultado(rs);

		} catch (SQLException e) {
			System.out.println("Error al buscar por autor");
		}
	}

	private static void imprimirResultado(ResultSet rs) throws SQLException {

		boolean encontrado = false;

		while (rs.next()) {
			encontrado = true;

			System.out.println(
					rs.getInt("id") + " | " +
					rs.getString("titulo") + " | " +
					rs.getString("autor") + " | " +
					rs.getInt("anio") + " | " +
					rs.getString("genero") + " | " +
					rs.getInt("disponible")
			);
		}

		if (!encontrado) {
			System.out.println("No se han encontrado libros");
		}
	}

	private static int leerEntero() {

		while (!sc.hasNextInt()) {
			System.out.print("Introduce un número válido: ");
			sc.nextLine();
		}

		int numero = sc.nextInt();
		sc.nextLine();

		return numero;
	}
}
