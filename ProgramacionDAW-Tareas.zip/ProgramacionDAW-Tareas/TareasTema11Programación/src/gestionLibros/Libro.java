package gestionLibros;

public class Libro {

	//================== ATRIBUTOS ===================
	
	private int id;
	private String titulo;
	private String autor;
	private int anio;
	private String genero;
	private int disponible;
	
	
	//================== CONSTRUCTORES ==================

	public Libro(int id, String titulo, String autor, int anio, String genero, int disponible) {
		this.id = id;
		this.titulo = titulo;
		this.autor = autor;
		this.anio = anio;
		this.genero = genero;
		this.disponible = disponible;
	}

	public Libro(String titulo, String autor, int anio, String genero, int disponible) {
		this.titulo = titulo;
		this.autor = autor;
		this.anio = anio;
		this.genero = genero;
		this.disponible = disponible;
	}

	
	//=================== GETTERS Y SETTERS =================
	
	public int getId() {
		return id;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getAutor() {
		return autor;
	}

	public int getAnio() {
		return anio;
	}

	public String getGenero() {
		return genero;
	}

	public int getDisponible() {
		return disponible;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public void setDisponible(int disponible) {
		this.disponible = disponible;
	}
		
}
