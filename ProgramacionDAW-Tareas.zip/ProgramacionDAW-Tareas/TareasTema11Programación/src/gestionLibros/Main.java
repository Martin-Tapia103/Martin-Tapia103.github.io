package gestionLibros;

import java.sql.*;
import java.util.*;

public class Main {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	
	private static final String URL = "jdbc:sqlite:biblioteca.db";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try (Connection conn = DriverManager.getConnection(URL)) {

			System.out.println("La conexión se ha establecido");

			baseDeDatos(conn);

			int opcion;

			do {
				System.out.println("\nGESTIÓN DE BIBLIOTECA");
				System.out.println("1. Añadir libro");
				System.out.println("2. Listar todos los libros");
				System.out.println("3. Buscar libro");
				System.out.println("4. Actualizar libro");
				System.out.println("5. Eliminar libro");
				System.out.println("6. Listar libros disponibles");
				System.out.println("0. Salir");
				System.out.print("Elige una opción: ");
		
				opcion = scInt.nextInt();
				scInt.nextLine();

				switch (opcion) {

				case 1:
					System.out.print("titulo");
					String titulo = scLine.nextLine();

					System.out.print("autor");
					String autor = scLine.nextLine();

					System.out.print("año");
					int anio = scInt.nextInt();
					scInt.nextLine();

					System.out.print("genero");
					String genero = scLine.nextLine();

					System.out.print("1 es disponible, 0 es no disponible");
					int disponible = scInt.nextInt();

					insertarLibro(conn, titulo, autor, anio, genero, disponible);
					break;

				case 2:
					listarLibros(conn);
					break;

				case 3:
					buscarLibros(conn, scLine, scInt);
					break;

				case 4:
					actualizarLibro(conn, scLine, scInt);
					break;

				case 5:
					System.out.print("ID?");
					int idEliminar = scInt.nextInt();
					scInt.nextLine();

					System.out.print("SEGURO? S/N");
					String confirmacion = scLine.nextLine();

					if (confirmacion.equalsIgnoreCase("S")) {
						eliminarLibro(conn, idEliminar);
					} else {
						System.out.println("Eliminado");
					}
					break;

				case 6:
					listarLibrosDisponibles(conn);
					break;

				case 0:
					System.out.println("Adeu");
					break;

				default:
					System.out.println("No?");
				}

			} while (opcion != 0);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	//=================== BASE DE DATOS =========================
	
	private static void baseDeDatos(Connection conn) {

		String sql = """
				CREATE TABLE IF NOT EXISTS libros (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				titulo TEXT NOT NULL,
				autor TEXT NOT NULL,
				anio INTEGER,
				genero TEXT,
				disponible INTEGER
				);
				""";

		try (Statement stmt = conn.createStatement()) {
			stmt.execute(sql);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Hay un error en la sentencia SQL" +
			" con la que creamos la tabla");
		}
	}

	

	//================== METODOS ====================
	
	private static void insertarLibro(Connection conn, String titulo, String autor, int anio, String genero,
			int disponible) {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO libros(titulo, autor, anio, genero, disponible) VALUES(?, ?, ?, ?, ?)";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			pstmt.setString(2, autor);
			pstmt.setInt(3, anio);
			pstmt.setString(4, genero);
			pstmt.setInt(5, disponible);
			pstmt.executeUpdate();
			
			System.out.println("Libro añadido");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Hay un error al añadir el libro");
		}
	}

	private static void listarLibros(Connection conn) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM libros";

		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {

			while (rs.next()) {

				System.out.println(
						rs.getInt("id") + " | " +
						rs.getString("titulo") + " | " +
						rs.getString("autor") + " | " +
						rs.getInt("anio") + " | " +
						rs.getString("genero") + " | " +
						rs.getInt("disponible")
				);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Hay un error al listar los Libros");
		}
		
	}

	private static void buscarLibros(Connection conn, Scanner scLine2, Scanner scInt2) {
		// TODO Auto-generated method stub
		
		System.out.println("\nBUSCAR LIBRO");
		System.out.print("1. Por ID");
		System.out.print("2. Por título");
		System.out.print("3. Por autor");

		int opcion = scInt.nextInt();
		scInt.nextLine();

		switch (opcion) {

		case 1:
			System.out.print("ID");
			int id = scInt.nextInt();
			buscarPorId(conn, id);
			break;

		case 2:
			System.out.print("TITULO");
			String titulo = scLine.nextLine();
			buscarPorTitulo(conn, titulo);
			break;

		case 3:
			System.out.print("AUTOR");
			String autor = scLine.nextLine();
			buscarPorAutor(conn, autor);
			break;

		default:
			System.out.println("No?");
		}
	}

	private static void actualizarLibro(Connection conn, Scanner scLine2, Scanner scInt2) {
		// TODO Auto-generated method stub
		
		System.out.print("ID");
		int id = scInt.nextInt();
		scInt.nextLine();

		System.out.print("Titulo nuevo");
		String titulo = scLine.nextLine();

		System.out.print("Autor nuevo");
		String autor = scLine.nextLine();

		System.out.print("Año nuevo");
		int anio = scInt.nextInt();
		scInt.nextLine();

		System.out.print("Genero nuevo");
		String genero = scLine.nextLine();

		System.out.print("1 si esta disponible y 0 no lo esta");
		int disponible = scInt.nextInt();

		String sql = "UPDATE libros SET titulo = ?, autor = ?, anio = ?, genero = ?, disponible = ? WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			pstmt.setString(2, autor);
			pstmt.setInt(3, anio);
			pstmt.setString(4, genero);
			pstmt.setInt(5, disponible);
			pstmt.setInt(6, id);

			pstmt.executeUpdate();

			System.out.println("Actualizado");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Algo ha ido mal");
		}	
	}

	private static void eliminarLibro(Connection conn, int idEliminar) {
		// TODO Auto-generated method stub
		
		String sql = "DELETE FROM libros WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, idEliminar);

			int filas = pstmt.executeUpdate();

			System.out.println("Se han eliminado " + filas + " libros");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Error al eliminar un libro");
		}	
	}

	private static void listarLibrosDisponibles(Connection conn) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM libros WHERE disponible = 1";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				System.out.println(
						rs.getInt("id") + " | " +
						rs.getString("titulo") + " | " +
						rs.getString("autor") + " | " +
						rs.getInt("anio") + " | " +
						rs.getString("genero") + " | " +
						rs.getInt("disponible")
				);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Error en encontrar los libros");
		}		
	}
	
	
	//================== METODOS DE BUSCAR ==========================
	
	private static void buscarPorId(Connection conn, int id) {

		String sql = "SELECT * FROM libros WHERE id = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				System.out.println(
						rs.getInt("id") + " | " +
						rs.getString("titulo") + " | " +
						rs.getString("autor") + " | " +
						rs.getInt("anio") + " | " +
						rs.getString("genero") + " | " +
						rs.getInt("disponible")
				);

			} else {

				System.out.println("Ningun libro tiene ese ID");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Error al encontrar dicho ID");
		}
	}

	private static void buscarPorTitulo(Connection conn, String titulo) {

		String sql = "SELECT * FROM libros WHERE titulo = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, titulo);
			ResultSet rs = pstmt.executeQuery();
			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;

				System.out.println(
						rs.getInt("id") + " | " +
						rs.getString("titulo") + " | " +
						rs.getString("autor") + " | " +
						rs.getInt("anio") + " | " +
						rs.getString("genero") + " | " +
						rs.getInt("disponible")
				);
			}

			if (!encontrado) {
				System.out.println("Ningun libro tiene ese titulo");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Error al encontrar dicho titulo");
		}
	}

	private static void buscarPorAutor(Connection conn, String autor) {

		String sql = "SELECT * FROM libros WHERE autor LIKE ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, "%" + autor + "%");
			ResultSet rs = pstmt.executeQuery();
			boolean encontrado = false;

			while (rs.next()) {
				encontrado = true;

				System.out.println(
						rs.getInt("id") + " | " +
						rs.getString("titulo") + " | " +
						rs.getString("autor") + " | " +
						rs.getInt("anio") + " | " +
						rs.getString("genero") + " | " +
						rs.getInt("disponible")
				);
			}

			if (!encontrado) {
				System.out.println("Ningun libro tiene ese autor");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Error al encontrar ese libro o autor");
		}
	}
}
