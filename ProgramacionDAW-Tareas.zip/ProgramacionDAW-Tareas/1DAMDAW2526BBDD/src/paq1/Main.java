package paq1;

import java.sql.*;
import java.util.*;

public class Main {

	private static final String URL = "jdbc:sqlite:mi_base_de_datos.db";
	
	static Set<Usuario> listaUsuarios = new HashSet();

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scLine = new Scanner(System.in);
		Scanner scInt = new Scanner(System.in);
		
		
		//***************************************************
		//Se establece la conexión con un try-with-resources
		//Este es el try principal que va a contener todo el código
		//ya que es donde ha de estar creada la conexión para hacer
		//cualquier cosa
		try (Connection conn = DriverManager.getConnection(URL)) {

			System.out.println("La conexión se ha establecido");
			// ******************
			
			
			
			
			
			
			// **********************************
			//Crear tabla
			
			// El tipo de atributo INTEGER tambien puede ser INT
			// EXCEPTO si es la PRIMARY KEY. En ese caso solo puede
			// ser INTEGER
			// EL tipo de atributo TEXT puede ser VARCHAR(x) pero
			// la x NO limita, de hecho no hace nada, por lo tanto
			// en SQLite utilizaremos siempre TEXT para los atributos
			// que son String en los objetos
			
			String sql = """
					CREATE TABLE IF NOT EXISTS usuarios (
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					nombre TEXT NOT NULL,
					email TEXT NOT NULL UNIQUE,
					edad INTEGER
					);
					""";
			
			
			//De aqui hacia abajo siempre sera igual
			try (Statement stmt = conn.createStatement()) {
				
				stmt.execute(sql);
				
				//System.out.println("Tabla usuarios creada");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Hay un error en la sentencia SQL" +
				" con la que creamos la tabla");
			}
			
			//**********************************
			
			
			
			
			
			
			//************************
			//Creamos un objeto cualquiera
			//(En este caso le preguntamos al usuario)
			//Este objeto tiene en atributos un id, pero no preguntamos
			//por el id porque éste se lo asigna la bbdd cuando lo
			//inserta con el autoincrement
			
			
			System.out.println("Introduce el nombre");
			String nombre = scLine.nextLine();
			
			System.out.println("Introduce el email");
			String email = scLine.nextLine();
			
			System.out.println("Introduce la edad");
			int edad = scInt.nextInt();
			
			Usuario ux = new Usuario(nombre, email, edad);
			//*******************************
			

			
			
			//Llamamos al metodo para insertar un registro dentro de la 
			// tabla que esta puesta dentro de este metodo
			insertarUsuario(conn, nombre, email, edad);
			
			//Llamamos al metodo para listar todos los registros
			//que están en la tabla usuarios de la bbdd mi_base_de_datos.db
			leerUsuarios(conn);
			
			
			//Llamamos al metodo para listar todos los registros
			//que están en la tabla usuarios de la bbdd mi_base_de_datos.db
			// e internamente los pasamos a objetos
			leerUsuarios2(conn);
			
			
			System.out.println("\nDime un nombre del cual hacer la busqueda\n");
			
			String nombreBusq = scLine.nextLine();
			
			buscarPorNombre(conn, nombreBusq);
			
			
			System.out.println("\nDime el rango de edad en la que buscar usuarios\n");
			System.out.println("Mayor de? ");
			int edadMayorDe= scInt.nextInt();
			
			System.out.println("\nMenor de? \n");
			int edadMenorDe= scInt.nextInt();	
			
			buscarPorRangoDeEdad(conn, edadMayorDe, edadMenorDe);
			
			
			System.out.println("\nIntroduce el id del usuario a eliminar\n");
			
			int idElim =scInt.nextInt(); 
			
			eliminarUsuarioPorId(conn, idElim);
			
			
			System.out.println("Vamos a cambiar la edad a un registro");
			
			System.out.println("\nIntroduce el id del registro a modificar\n");
			
			int idAct = scInt.nextInt();
			
			System.out.println("\nIntroduce la nueva edad\n");
			
			int edadNueva = scInt.nextInt();
			
			actualizarEdadUsuario(conn, idAct, edadNueva);
			
			System.out.println();
			
			leerUsuarios(conn);
			
		// Este es el catch del try-with-resources inicial con el
		// que establecemos la conexión
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} 
		
		//****************
		// Aquí ya no podemos hacer nada con la  BBDD porque se ha
		// cerrado la conexión
		
		//****************
	} //llave de cierre del metodo main

	
	private static void actualizarEdadUsuario(Connection conn, int idAct, int edadNueva) {
		// TODO Auto-generated method stub
		

	    String sql = "UPDATE usuarios SET edad = ? WHERE id = ?";

	    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
		
	    	pstmt.setInt(1, edadNueva);
	    	pstmt.setInt(2, idAct);

	    	int filas = pstmt.executeUpdate();

	    	System.out.println("Se han actualizado " + filas + " filas");
	    
	    
	    
	    } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}


	private static void eliminarUsuarioPorId(Connection conn, int idElim) {
		// TODO Auto-generated method stub
		
		String sql = "DELETE FROM usuarios WHERE id = ?;";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
		
			pstmt.setInt(1, idElim);
			
			int filasAfectadas = pstmt.executeUpdate();
		
			System.out.println("\nSe han eliminado " + filasAfectadas + " usuarios");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
		
		
		
		
	}


	private static void buscarPorRangoDeEdad(Connection conn, int edadMayorDe, int edadMenorDe) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM usuarios WHERE edad BETWEEN ? AND ?";
		
		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
		
			pstmt.setInt(1, edadMayorDe);
			pstmt.setInt(2, edadMenorDe);
		
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				System.out.println(
						rs.getInt("Id") + " | " +
						rs.getString("Nombre") + " | " +
						rs.getString("email") + " | " + 
						rs.getInt("edad")
						);		
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}


	private static void buscarPorNombre(Connection conn, String nombreBusq) {
		// TODO Auto-generated method stub
		
		
		String sql = "SELECT * FROM usuarios WHERE nombre LIKE ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
			
			pstmt.setString(1, "%" + nombreBusq + "%");
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				System.out.println(
						rs.getInt("Id") + " | " +
						rs.getString("Nombre") + " | " +
						rs.getString("email") + " | " + 
						rs.getInt("edad")
						);		
				
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}


	private static void leerUsuarios2(Connection conn) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM usuarios";

		listaUsuarios.clear();
		
		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
		
			while(rs.next()) {
				
				Usuario u = new Usuario(rs.getInt("Id"), rs.getString("Nombre"),
						rs.getString("email"), rs.getInt("edad"));	
				
				listaUsuarios.add(u);
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}


	//Metodo para leer todos los registros de la tabla usuarios
	private static void leerUsuarios(Connection conn) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM usuarios";

		
		try (Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
		
			while(rs.next()) {
				
				System.out.println(
						rs.getInt("Id") + " | " +
						rs.getString("Nombre") + " | " +
						rs.getString("email") + " | " + 
						rs.getInt("edad")
						);		
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}


	// Metodo insertar al que se le pasa la conexión
	// y todos los campos que componen el registro que vamos a 
	// meter dentro de la tabla (excepto el id)
	private static void insertarUsuario( 
			Connection conn,
			String nombre, 
			String email, 
			int edad) {
		// TODO Auto-generated method stub
		
		//La istrucción SQL hay que adaptarla a la tabla con la que 
		//estemos trabajando, y hay que poner los campos que necesitemos
		// (que seran los mismos que le hayamos pasado en los 
		// parametros
		
	    String sql = "INSERT INTO usuarios(nombre, email, edad) VALUES(?, ?, ?)";
		
	    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	    	
	        pstmt.setString(1, nombre);
	        pstmt.setString(2, email);
	        pstmt.setInt(3, edad);
	        pstmt.executeUpdate();

	    	System.out.println("Usuario " + nombre + " añadido");
	    	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	
	
	

}
