package Paq;

import java.io.*;
import java.util.*;

public class db {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	File f0 = new File("miFichero");
		
		File f1 = new File("src/paq");
		
		String archivos[] = f1.list();
		
		System.out.println(Arrays.toString(archivos));
		
		for(int i=0; i<archivos.length; i++) {
			
			System.out.println(archivos[i]);
			
		}
				
		File f3 = new File("src/paq/Coche.java");
		
		boolean existe = f3.exists();
		
		System.out.println(existe);
		
		if(f3.exists()){
			
			System.out.println("Nombre del del fichero: " + f3.getName());
			System.out.println("Ruta relativa: " + f3.getPath());
			System.out.println("Ruta absoluta: " + f3.getAbsolutePath());
			System.out.println("Se puede leer?: " + f3.canRead());
			System.out.println("Se puede escribir? " + f3.canWrite());
			System.out.println("Tamaño: " + f3.length());
			System.out.println("Es un directorio: " + f3.isDirectory());
			System.out.println("Es un fichero: " + f3.isFile());
		}
		else {
			System.out.println("El fichero no existe");
		}
		
		
		
		System.out.println("Creamos un directorio");
		File f4 = new File("NUEVO_DIRECTORIO");
		
		f4.mkdir();
	//	f4.delete();
		
		File f5 = new File(f4, "MiFichero.txt");
		
		try {
			f5.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Hay un problema con el disco duro. "
					+ "No puedo crear el fichero");
			
		}
		
		//Lectura de fichero con FileReader (caracter a caracter)
		
		try (FileReader fr = new FileReader("src/paq/Coche.java")) {
		
			int c;
			while((c=fr.read())!=-1) {
			
				System.out.print((char)c);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//Lectura de fichero con BufferReader (linea a linea)
		
		System.out.println("********");
		
		try (FileReader fr = new FileReader("src/paq/Coche.java");
				BufferedReader br = new BufferedReader(fr)) {
		
			String linea;
			while((linea=br.readLine())!=null) {
				
				System.out.println(linea);		
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//Lectura de fichero con BufferReader (linea a linea)
		
		System.out.println("********");
		
		try (FileReader fr = new FileReader("NUEVO_DIRECTORIO/MiFichero.txt");
				BufferedReader br = new BufferedReader(fr)) {
		
			String linea;
			while((linea=br.readLine())!=null) {
				
				System.out.println(linea);
				
				String atributos[] = linea.split(";");
				
				System.out.println(atributos[0]);
				System.out.println(atributos[1]);
				System.out.println(atributos[2]);
				
				String matricula= atributos[0];
				String marca = atributos[1];
				int potencia = Integer.parseInt(atributos[2]);
						
				Coche cx = new Coche(matricula, marca, potencia);
				
				System.out.println(cx);
				
				
				
				
				
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("\nEscribiendo fichero con FileWriter");
		
		try (FileWriter fw = new FileWriter("NUEVO_DIRECTORIO/MiFichero2.txt")) {
		
			fw.write("hola");
			fw.write("adios\n");
			fw.write("hola de nuevo");
			
			System.out.println("Fichero escrito");
			
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("\nEscribiendo fichero con BufferedWriter");
		
		try (FileWriter fw = new FileWriter("NUEVO_DIRECTORIO/MiFichero3.txt");
				BufferedWriter bw = new BufferedWriter(fw)) {
			
			bw.write("Esta es una linea de mi fichero");
			bw.newLine();
			bw.write("Esta es una nueva linea"); 
			
			System.out.println("fichero escrito");
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Escribiendo fichero con PrintWriter");
		
		
		try (FileWriter fw = new FileWriter("NUEVO_DIRECTORIO/MiFichero4.txt");
				PrintWriter pw = new PrintWriter(fw)) {
			
			
			pw.println("Esto es una linea");
			pw.print("hola");
			pw.println("adios");
			int a=555;
			pw.printf("el valor es %d", a);
			
			System.out.println("Fichero escrito");
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Guardar un objeto en fichero con formato CSV");
		
		
		try (FileWriter fw = new FileWriter("NUEVO_DIRECTORIO/Datos.txt");
				PrintWriter pw = new PrintWriter(fw)) {
			
			Coche cx = new Coche("1234CBD", "Seat", 120);
			
			String matricula = cx.getMatricula();
			String marca = cx.getMarca();
			int potencia = cx.getPotencia();
			
			pw.printf("%s;%s;%d", matricula, marca, potencia);

			
			System.out.println("Fichero escrito");
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}


