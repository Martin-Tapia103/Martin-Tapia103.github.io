package tarea1;
import java.util.*;

public class Tarea3OPCIONAL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//EJERCICIO 1 - Ejercicio 1: Nombre completo “pro”
//		Enunciado:
//			1.	Pide el nombre completo en una sola línea: "Nombre Apellido1 Apellido2".
//			2.	Muestra el formato "APELLIDO1 APELLIDO2, Nombre" (apellidos en mayúsculas; nombre capitalizado).
//			3.	Muestra el número  de caracteres ‘a’
//			4.	Muestra las 3 primeras letras del nombre y las 2 últimas del segundo apellido concatenadas.

		
//		Scanner scLine = new Scanner(System.in);
//
//		System.out.print("Introduce tu nombre completo: ");
//		String nombreCompleto = scLine.nextLine().trim();
//
//		int primerEspacio = nombreCompleto.indexOf(' ');
//		int segundoEspacio = nombreCompleto.lastIndexOf(' ');
//
//		String nombre = nombreCompleto.substring(0, primerEspacio);
//		String apellido1 = nombreCompleto.substring(primerEspacio + 1, segundoEspacio);
//		String apellido2 = nombreCompleto.substring(segundoEspacio + 1);
//
//		String formato = apellido1.toUpperCase() + " " + apellido2.toUpperCase() + ", "
//				+ nombre.substring(0, 1).toUpperCase() + nombre.substring(1).toLowerCase();
//
//		System.out.println("Formato: " + formato);
//
//		int totalA = nombreCompleto.length() - nombreCompleto.replace("a", "").replace("A", "").length();
//		System.out.println("Caracteres 'a': " + totalA);
//
//		String codigo = nombre.substring(0, 3) + apellido2.substring(apellido2.length() - 2);
//		System.out.println("Código: " + codigo);
//
//		scLine.close();
		
		
		//EJERCICIO 2 - Ejercicio 2: Usuario “plus” con aleatorio y máscaras
//		Enunciado:
//			1.	Pide nombre y apellido.
//			2.	Crea usuario: 3 primeras de nombre + 3 últimas de apellido (minúsculas, sin espacios).
//			3.	Añade un número aleatorio entre 1000 y 9999).
//			4.	Inserta un carácter aleatorio tomado de "_-.@" usando índice aleatorio y charAt.
//			5.	Muestra el resultado final.

		
		
//        Scanner scLine = new Scanner(System.in);
//        Random r = new Random();
//
//        System.out.print("Nombre: ");
//        String nombre = scLine.nextLine();
//        nombre = nombre.trim();
//
//        System.out.print("Apellido: ");
//        String apellido = scLine.nextLine().trim();
//
//        String usuario = (nombre.substring(0, 3) + apellido.substring(apellido.length() - 3)).toLowerCase();
//
//        int numero = r.nextInt(9000) + 1000;
//
//        String simbolos = "_-.@";
//        char simbolo = simbolos.charAt(r.nextInt(simbolos.length()));
//
//
//        String usuarioFinal = usuario + simbolo + numero;
//        System.out.println("Usuario: " + usuarioFinal);
//
//        scLine.close();
  
		

//		EJERCICIO 3 - Ejercicio 3: Analizador de email con subdominio
//		Enunciado:
//		1.	Pide un email con posible subdominio (p.ej.: ana.soler@alumnos.instituto.edu.es).
//		2.	Extrae y muestra: Usuario (antes de @).
//		3.	Muestra Dominio completo (entre @ y el último .). Usar el método lastIndexOf(‘.’).
//		4.	Muestra TLD (después del último .).
//		5.	Muestra el Dominio de segundo nivel (parte anterior al TLD; usa lastIndexOf('.') dos veces).

		
		
//		Scanner scLine = new Scanner(System.in);
//
//        System.out.print("Email: ");
//        String email = scLine.nextLine();
//        email = email.trim();
//
//
//        String usuario = email.substring(0, email.indexOf('@'));
//
//
//        int posArroba = email.indexOf('@');
//        int posUltimoPunto = email.lastIndexOf('.');
//        String dominioCompleto = email.substring(posArroba + 1, posUltimoPunto);
//
//
//        String tld = email.substring(posUltimoPunto + 1);
//
//
//        int posPenultimoPunto = email.lastIndexOf('.', posUltimoPunto - 1);
//        String segundoNivel = email.substring(posPenultimoPunto + 1, posUltimoPunto);
//
//
//        System.out.println("Usuario: " + usuario);
//        System.out.println("Dominio: " + dominioCompleto);
//        System.out.println("TLD: " + tld);
//        System.out.println("Segundo nivel: " + segundoNivel);
//
//        scLine.close();
		
		
		
		
		//EJERCICIO 4 - Ejercicio 4: Cinco dados y estadísticas sin bucles
//		Enunciado:
//			1.	Genera cinco enteros aleatorios d1..d5 entre 1 y 6.
//			2.	Muestra los cinco valores.
//			3.	Calcula media con 2 decimales.
//			4.	Calcula máximo y mínimo 

		
//        int d1 = (int)(Math.random() * 6) + 1;
//        int d2 = (int)(Math.random() * 6) + 1;
//        int d3 = (int)(Math.random() * 6) + 1;
//        int d4 = (int)(Math.random() * 6) + 1;
//        int d5 = (int)(Math.random() * 6) + 1;
//
//        System.out.println("Tiradas: " + d1 + ", " + d2 + ", " + d3 + ", " + d4 + ", " + d5);
//
//    
//        double media = (d1 + d2 + d3 + d4 + d5) / 5.0;
//        media = Math.round(media * 100.0) / 100.0; 
//        String media2 = ("" + (media + 0.001)).substring(0, ("" + (media + 0.001)).indexOf(".") + 3);
//        System.out.println("Media: " + media2);
//
//     
//        int max1 = Math.max(d1, d2);
//        int max2 = Math.max(d3, d4);
//        int maxFinal = Math.max(Math.max(max1, max2), d5);
//        System.out.println("Máximo: " + maxFinal);
//
//      
//        int min1 = Math.min(d1, d2);
//        int min2 = Math.min(d3, d4);
//        int minFinal = Math.min(Math.min(min1, min2), d5);
//        System.out.println("Mínimo: " + minFinal);
		
		
		
		//EJERCICIo 5 - Ejercicio 5: IMC + cálculos planetarios
//		Enunciado:
//			1.	Pide peso (kg) y altura (m).
//			2.	IMC = peso / (altura^2) con 2 decimales.
//			3.	Peso aparente en Luna y Marte con factores 0.165 y 0.38.
//			4.	Energía potencial: E = m * g * h con h = 1.20 m, g = 9.80665.

		
		
//		Scanner scDouble = new Scanner(System.in);
//       
//        System.out.print("Peso (kg): ");
//        double peso = scDouble.nextDouble();
//
//        System.out.print("Altura (m): ");
//        double altura = scDouble.nextDouble();
//
//
//        double imc = peso / (altura * altura);
//        imc = Math.round(imc * 100.0) / 100.0;
//
//
//        double pesoLuna = peso * 0.165;
//        pesoLuna = Math.round(pesoLuna * 100.0) / 100.0;
//
//        double pesoMarte = peso * 0.38;
//        pesoMarte = Math.round(pesoMarte * 100.0) / 100.0;
//
//
//        double h = 1.20;
//        double g = 9.80665;
//        double energia = peso * g * h;
//        energia = Math.round(energia * 100.0) / 100.0;
//
//        System.out.println("IMC: " + imc);
//        System.out.println("Peso en la Luna: " + pesoLuna + " kg");
//        System.out.println("Peso en Marte: " + pesoMarte + " kg");
//        System.out.println("E (subir 1.20 m): " + energia + " J");
//
//        scDouble.close();
		
		
		
		
		//EJERCICIO 6 - Ejercicio 6: Texto
//		Enunciado:
//			1.	Pide una frase.
//			2.	Muestra la frase sin espacios.
//			3.	Concatena las 5 primeras y las 5 últimas letras si la frase es suficientemente larga (asume válida).
//			4.	Cuenta ocurrencias de "Java".

		
//		Scanner scLine = new Scanner(System.in);
//
//        System.out.print("Frase: ");
//        String frase = scLine.nextLine();
//
//
//        String fraseSinEspacios = frase.replace(" ", "").trim();
//        System.out.println("Sin espacios: \"" + fraseSinEspacios + "\"");
//
//
//        String inicioFin = fraseSinEspacios.substring(0, 5)
//                         + fraseSinEspacios.substring(fraseSinEspacios.length() - 5);
//        System.out.println("Inicio+Fin: \"" + inicioFin + "\"");
//
//
//        int ocurrenciasJava = (frase.length() - frase.replace("Java", "").length()) / 4;
//        System.out.println("Ocurrencias \"Java\": " + ocurrenciasJava);
//
//        scLine.close();
		
		
		
		//EJERCICIO 7 - Ejercicio 7: Aleatorios con semilla y formato
//		Enunciado:
//			5.	Pide una semilla (long) y crea Random r = new Random(semilla).
//			6.	Genera un double en [0.0, 1.0). r.nextDouble();
//			7.	Genera un entero en [50, 100]
//			8.	Genera un precio simulado con dos decimales: double a = r.nextDouble();

		
		
//        Scanner scDouble = new Scanner(System.in);
//
//        System.out.print("Semilla: ");
//        long semilla = scDouble.nextLong();
//
//        Random r = new Random(semilla);
//
//        double u = r.nextDouble();
//        u = Math.round(u * 1000.0) / 1000.0; 
//        System.out.println("u: " + u);
//
//
//        int n = r.nextInt(51) + 50; 
//        System.out.println("n: " + n);
//
//
//        double precio = r.nextDouble() * 1000;
//        precio = Math.round(precio * 100.0) / 100.0;
//        System.out.println("precio: " + precio + " €");
//
//        scDouble.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
