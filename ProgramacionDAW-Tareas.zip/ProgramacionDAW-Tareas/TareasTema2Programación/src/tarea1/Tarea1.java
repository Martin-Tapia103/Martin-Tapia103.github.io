package tarea1;
import java.util.*;
public class Tarea1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		//EJERCICIO 1 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario su nombre completo.
//			2. Muestre el nombre en mayúsculas.
//			3. Muestre el nombre en minúsculas.
//			4. Indique la longitud total del nombre.
//			5. Muestre el primer carácter.
//			6. Muestre el último carácter.

		
//        Scanner scLine = new Scanner(System.in);
//        //NOMBRE
//        System.out.print("Introduce tu nombre completo: ");
//        String nombre = scLine.nextLine();
//        //MAYUS
//        String mayusculas = nombre.toUpperCase();
//        System.out.println("MAYÚSCULAS: " + mayusculas);
//        //MINUS
//        String minusculas = nombre.toLowerCase();
//        System.out.println("minúsculas: " + minusculas);
//        //LONGITUD
//        int longitud = nombre.length();
//        System.out.println("Longitud: " + longitud);
//        //PRIMERA LETRA
//        char primerCaracter = nombre.charAt(0);
//        System.out.println("Primer carácter: " + primerCaracter);
//        //SEGUNDA LETRA
//        char ultimoCaracter = nombre.charAt(nombre.length() - 1);
//        System.out.println("Último carácter: " + ultimoCaracter);
//        scLine.close();
//		
		
		
		//EJERCICIO 2 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario que escriba su nombre.
//			2. Genere un número aleatorio entre 50 y 100 (ambos incluidos)
//			3. Muestre un mensaje con el nombre del usuario y el número generado.

		
//		Scanner scLine = new Scanner(System.in);
//        Random random = new Random();
//        //NOMBRE
//        System.out.print("Introduce tu nombre: ");
//        String nombre = scLine.nextLine();
//        //NUMERO ALEATORIO
//        int numeroAleatorio = 50 + random.nextInt(51);
//        System.out.println("Hola " + nombre + ", tu número de la suerte es: " + numeroAleatorio);
//        scLine.close();
		
		
		
		//EJERCICIO 3 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario que escriba su nombre.
//			2. Genere un número aleatorio entre 50 y 100 (ambos incluidos)
//			3. Muestre un mensaje con el nombre del usuario y el número generado.

		
//		Scanner scLine = new Scanner(System.in);
//        //NOMBRE Y CIUDAD
//        System.out.print("Introduce tu nombre: ");
//        String nombre = scLine.nextLine();
//        System.out.print("Introduce tu ciudad de nacimiento: ");
//        String ciudad = scLine.nextLine();
//        System.out.println("Hola, me llamo " + nombre + " y nací en " + ciudad + ".");
//        scLine.close();
		
		
		
		//EJERCICIO 4 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario que escriba su nombre.
//			2. Genere un número aleatorio entre 50 y 100 (ambos incluidos)
//			3. Muestre un mensaje con el nombre del usuario y el número generado.

		
//        Scanner scDouble = new Scanner(System.in);
//        //PRIMER Y SEGUNDO NÚMEROS
//        System.out.print("Introduce el primer número: ");
//        double num1 = scDouble.nextDouble();
//        System.out.print("Introduce el segundo número: ");
//        double num2 = scDouble.nextDouble();
//        //SUMA Y RESTA Y MULTIPLICACION Y DIVISION
//        double suma = num1 + num2;
//        double resta = num1 - num2;
//        double multiplicacion = num1 * num2;
//        double division = num1 / num2;
//        System.out.println("Suma: " + suma);
//        System.out.println("Resta: " + resta);
//        System.out.println("Multiplicación: " + multiplicacion);
//        System.out.println("División: " + division);
//        scDouble.close();
		
		
		
		
		//EJERCICIO 5 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario que introduzca su nombre, apellido y número de teléfono.
//			2. Muestre los datos en formato de tarjeta de contacto con varias líneas.

		
//		  Scanner scLine = new Scanner(System.in);
//        //DATOS
//        System.out.print("Introduce tu nombre: ");
//        String nombre = scLine.nextLine();
//        System.out.print("Introduce tu apellido: ");
//        String apellido = scLine.nextLine();
//        System.out.print("Introduce tu número de teléfono: ");
//        String telefono = scLine.nextLine();
//        //TARJETA DE CONTACTO
//        System.out.println("\n--- TARJETA DE CONTACTO ---");
//        System.out.println("Nombre: " + nombre);
//        System.out.println("Apellido: " + apellido);
//        System.out.println("Teléfono: " + telefono);
//        scLine.close();
	
		
		
		//EJERCICIO 6 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario su nombre y apellido.
//			2. Muestre en pantalla las iniciales en mayúsculas.

		
//        Scanner scLine = new Scanner(System.in);
//        //NOMBRE Y APELLIDOS
//        System.out.print("Introduce tu nombre: ");
//        String nombre = scLine.nextLine();
//        System.out.print("Introduce tu apellido: ");
//        String apellido = scLine.nextLine();
//        //INICIALES + MAYUS
//        char inicialNombre = Character.toUpperCase(nombre.charAt(0));
//        char inicialApellido = Character.toUpperCase(apellido.charAt(0));
//        System.out.println("Tus iniciales son: " + inicialNombre + "." + inicialApellido + ".");
//        scLine.close();
		
		
		
		//EJERCICIO 7 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario dos números enteros.
//			2. Genere un número aleatorio entre esos dos números.
//			3. Muestre el número en pantalla.

		
//        Scanner scInt = new Scanner(System.in);
//        Random random = new Random();
//        //DOS NUM ENTEROS
//        System.out.print("Introduce el primer número: ");
//        int num1 = scInt.nextInt();
//        System.out.print("Introduce el segundo número: ");
//        int num2 = scInt.nextInt();
//        //MAX, MIN Y ALEATORIO
//        int min = Math.min(num1, num2);
//        int max = Math.max(num1, num2);
//        int numAleatorio = min + random.nextInt(max - min + 1);
//        System.out.println("Número aleatorio generado: " + numAleatorio);
//        scInt.close();
		
		
		
		//EJERCICIO 8 - Enunciado:
//		Crea un programa en Java que:
//			1. Pida al usuario un número decimal.
//			2. Muestre ese número redondeado al entero más cercano.
//			3. Muestre también el valor truncado (parte entera).

		
//		Scanner scDouble = new Scanner(System.in);
//        //DECIMAL
//        System.out.print("Introduce un número decimal: ");
//        double numero = scDouble.nextDouble();
//        //REDONDEAR A ENTERO QUITANDO DECIMAL
//        long redondeado = Math.round(numero);
//        int truncado = (int) numero;
//        System.out.println("Redondeado: " + redondeado);
//        System.out.println("Truncado: " + truncado);
//        scDouble.close();
        
	}

}
