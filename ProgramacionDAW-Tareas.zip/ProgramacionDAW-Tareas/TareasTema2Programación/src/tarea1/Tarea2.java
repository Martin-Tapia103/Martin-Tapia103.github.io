package tarea1;
import java.util.*;
public class Tarea2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//EJERCICIO 1 - Enunciado:
//		1. Pida al usuario su nombre y dos apellidos en líneas separadas.
//		2. Muestre el nombre en formato: APELLIDO1 APELLIDO2, Nombre.
//		3. Muestre las iniciales en mayúsculas (ej.: J. P. G.).
//		4. Indique el número de letras sin contar espacios.
//		5. Muestre la posición (índice) de la primera letra 'a' (o -1 si no existe).

		
//		Scanner scLine = new Scanner(System.in);
//        System.out.println("Introduce tu nombre: ");
//        String nombre = scLine.nextLine();
//        System.out.println("Introduce tu primer apellido: ");
//        String apellido1 = scLine.nextLine();
//        System.out.println("Introduce tu segundo apellido: ");
//        String apellido2 = scLine.nextLine();
//        //APELLIDO1 + APELLIDO + NOMBRE
//        System.out.println("Formato: " + apellido1.toUpperCase() + " " + apellido2.toUpperCase() + ", " + nombre);
//        //MAYUS
//        char inicialNombre = Character.toUpperCase(nombre.charAt(0));
//        char inicialApe1 = Character.toUpperCase(apellido1.charAt(0));
//        char inicialApe2 = Character.toUpperCase(apellido2.charAt(0));
//        System.out.println("Iniciales: " + inicialNombre + ". " + inicialApe1 + ". " + inicialApe2 + ".");
//        //SIN ESPACIOS
//        int letrasSinEspacios = (nombre + apellido1 + apellido2).replace(" ", "").length();
//        System.out.println("Letras (sin espacios): " + letrasSinEspacios);
//        //PRIMERA 'a'
//        int indiceA = (nombre + " " + apellido1 + " " + apellido2).indexOf('a');
//        System.out.println("Primera ‘a’ en índice: " + indiceA);
//        scLine.close();
		
		
		
		
		//EJERCICIO 2 - Enunciado:
//		1. Pida dos números decimales a y b.
//		2. Muestre: suma, resta, multiplicación y división.
//		3. Muestre a^b (a elevado a b) y √a (raíz cuadrada de a).
//		4. Muestra los resultados con 2 decimales.

		
//		Scanner scDouble = new Scanner(System.in);
//        System.out.println("Introduce a: ");
//        double a = scDouble.nextDouble();
//
//        System.out.println("Introduce b: ");
//        
//        double b = scDouble.nextDouble();
//        double suma = a + b;
//        double resta = a - b;
//        double multi = a * b;
//        double div = a / b;
//        double potencia = Math.pow(a, b);
//        double raiz = Math.sqrt(a);
//        
//        System.out.println("Suma: " + Math.round(suma * 100.0)/100.0);
//        System.out.println("Resta: " + Math.round(resta * 100.0)/100.0);
//        System.out.println("Multiplicación: " + Math.round(multi * 100.0)/100.0);
//        System.out.println("División: " + Math.round(div * 100.0)/100.0);
//        System.out.println("a^b: " + Math.round(potencia * 100.0)/100.0);
//        System.out.println("√a: " + Math.round(raiz * 100.0)/100.0);
//        scDouble.close();
		
		
		
		//EJERCICIO 3 - Enunciado:
//		1. Pida nombre y apellido.
//		2. Genere un nombre de usuario con:
//		3. - Las 3 primeras letras del nombre,
//		4. - Las 3 últimas letras del apellido,
//		5. - Un número aleatorio entre 100 y 999.
//		6. Muéstralo en minúsculas y sin espacios.

		
//		 Scanner scLine = new Scanner(System.in);
//
//		 System.out.println("Introduce tu nombre: ");
//
//		 String nombre = scLine.nextLine();
//
//		 System.out.println("Introduce tu apellido: ");
//
//		 String apellido = scLine.nextLine();
//
//		 String usuario = nombre.substring(0, 3).toLowerCase() + apellido.substring(apellido.length() - 3).toLowerCase();
//
//		 Random numeroAleatorio = new Random();
//
//		 int numero = numeroAleatorio.nextInt(999) + 100;
//
//		 System.out.println("Usuario sugerido: " + usuario + numero);
//
//		 scLine.close();
		
		
		
		//EJERCICIO 4 - Enunciado:
//		1. Pida una dirección de correo (ej.: nombre.apellido@empresa.com).
//		2. Muestre por pantalla:
//		3. - Usuarsio (antes de @)
//		4. - Dominio (entre @ y el último punto)
//		5. - TLD (después del último punto, ej.: com, es, org)

		
//		Scanner scLine = new Scanner(System.in);
//        System.out.println("Introduce tu correo: ");
//        String correo = scLine.nextLine();
//
//        int arroba = correo.indexOf("@");
//        int punto = correo.lastIndexOf(".");
//
//        String usuario = correo.substring(0, arroba);
//        String dominio = correo.substring(arroba + 1, punto);
//        String tld = correo.substring(punto + 1);
//
//        System.out.println("Usuario: " + usuario);
//        System.out.println("Dominio: " + dominio);
//        System.out.println("TLD: " + tld);
//        scLine.close();
		
		
		//EJERCICIO 5 - Enunciado:
//		1. Pida una cantidad en euros (decimal).
//		2. Convierta a dólares y libras usando tipos de cambio introducidos por el usuario.
//		3. Muestre los tres valores con 2 decimales.

		
//		 Scanner scDouble = new Scanner(System.in);
//	        System.out.println("Introduce cantidad en euros: ");
//	        double euros = scDouble.nextDouble();
//
//	        System.out.println("Introduce tipo de cambio EUR→USD: ");
//	        double usdRatio = scDouble.nextDouble();
//
//	        System.out.println("Introduce tipo de cambio EUR→GBP: ");
//	        double gbpRatio = scDouble.nextDouble();
//
//	        double usd = euros * usdRatio;
//	        double gbp = euros * gbpRatio;
//
//	        System.out.println("Euros: " + Math.round(euros * 100.0)/100.0);
//	        System.out.println("Dólares: " + Math.round(usd * 100.0)/100.0);
//	        System.out.println("Libras: " + Math.round(gbp * 100.0)/100.0);
//	        scDouble.close();
		
		
		
		//EJERCICIO 6 - Enunciado:
//		1. Genere tres números aleatorios entre 1 y 6 (simulando tres dados).
//		2. Muestre cada tirada y la media (decimal con 2 decimales).

		
//        Random random = new Random();
//        int dado1 = random.nextInt(6) + 1;
//        int dado2 = random.nextInt(6) + 1;
//        int dado3 = random.nextInt(6) + 1;
//
//        double media = (dado1 + dado2 + dado3) / 3.0;
//
//        System.out.println("Dado 1: " + dado1);
//        System.out.println("Dado 2: " + dado2);
//        System.out.println("Dado 3: " + dado3);
//        System.out.println("Media: " + Math.round(media * 100.0)/100.0);
		
		
		
		//EJERCICIO 7 - Enunciado:
//		1.	1. Pida peso en kg (decimal) y altura en metros (decimal).
//		2.	2. Calcule el IMC = peso / (altura^2).
//		3.	3. Muestre el IMC con 2 decimales y el texto “IMC calculado correctamente”.

		
//		Scanner scDouble = new Scanner(System.in);
//        System.out.println("Introduce tu peso (kg): ");
//        double peso = scDouble.nextDouble();
//
//        System.out.println("Introduce tu altura (m): ");
//        double altura = scDouble.nextDouble();
//
//        double imc = peso / Math.pow(altura, 2);
//
//        System.out.println("IMC: " + Math.round(imc * 100.0)/100.0);
//        System.out.println("IMC calculado correctamente");
//        scDouble.close();
		
		
		
        
		//EJERCICIO 8 - Enunciado:
//		4.	1. Pida el nombre del usuario.
//		5.	2. Pida tres valoraciones (enteros de 1 a 5) sobre: usabilidad, diseño y rendimiento.
//		6.	3. Calcule la media (con 2 decimales).
//		7.	4. Calcule el porcentaje que representa la media respecto al máximo (5) y lo muestre con %.

		
//        Scanner scInt = new Scanner(System.in);
//        System.out.println("Nombre: ");
//        String nombre = scInt.nextLine();
//
//        System.out.println("Usabilidad (1-5): ");
//        int usabilidad = scInt.nextInt();
//
//        System.out.println("Diseño (1-5): ");
//        int diseno = scInt.nextInt();
//
//        System.out.println("Rendimiento (1-5): ");
//        int rendimiento = scInt.nextInt();
//
//        double media = (usabilidad + diseno + rendimiento) / 3.0;
//        double porcentaje = (media / 5.0) * 100;
//
//        System.out.println("Media: " + Math.round(media * 100.0)/100.0);
//        System.out.println("Porcentaje sobre 5: " + Math.round(porcentaje * 100.0)/100.0 + '%');
//        scInt.close();
		
		
	}

}
