package paqEscribir;

import paqCoche.*;
import java.util.*;
import java.io.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Coche c0 = new Coche("1111BBB", "Seat", 100);
		Coche c1 = new Coche("2222CCC", "Opel", 110);
		Coche c2 = new Coche("3333DDD", "Citroen", 120);
		
		List<Coche> lista = new ArrayList();
		
		lista.add(c0);
		lista.add(c1);
		lista.add(c2);
		
		try (FileOutputStream fos = new FileOutputStream("coches.bin");
				ObjectOutputStream oos = new ObjectOutputStream(fos)) {
			
			oos.writeObject(lista); //PASA A BINARIO, CREANDO COCHES.BIN
			System.out.println("El fichero ha sido creado");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
