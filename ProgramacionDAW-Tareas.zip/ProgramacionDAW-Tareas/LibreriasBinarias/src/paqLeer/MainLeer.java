package paqLeer;

import java.util.*;
import java.io.*;
import paqCoche.*;

public class MainLeer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//============= USANDO ARRAY LIST ================
		
		
//		List<Coche> lista = new ArrayList();
//		
//		try (FileInputStream fis = new FileInputStream("coches.bin");
//				ObjectInputStream ois = new ObjectInputStream(fis)) {
//			
//			lista = (List<Coche>)ois.readObject(); //LEE EL FICHERO BINARIO
//			System.out.println("Fichero leeido correctamente");
//			
//		} catch (Exception e) {  //IMPORTANTE QUITAR EL "IO" ANTES DE EXCEPTION PARA QUE EL readObject FUNCIONE.
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		for(Coche c: lista) System.out.println(c); //PODEMOS USAR SYSO(c) DIRECTAMENTE GRACIAS AL ToString.
		
		
		//============= USANDO HASH SET ================
		
		Set<Coche> lista = new HashSet<>();

		try (FileInputStream fis = new FileInputStream("coches.bin");
		     ObjectInputStream ois = new ObjectInputStream(fis)) {
		    
		    lista = (Set<Coche>) ois.readObject(); 
		    System.out.println("Fichero leído correctamente en un HashSet");
		    
		} catch (Exception e) {
		    e.printStackTrace();
		}

		for(Coche c : lista) {
		    System.out.println(c);
		}
		
	}	
}
