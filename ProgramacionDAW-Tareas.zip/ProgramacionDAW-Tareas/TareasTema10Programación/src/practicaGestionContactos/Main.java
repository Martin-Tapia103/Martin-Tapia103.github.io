package practicaGestionContactos;

import java.util.*;

public class Main {
	
    static Scanner scInt = new Scanner(System.in);
    static Scanner scLine = new Scanner(System.in);
    static GestorContactos gestor = new GestorContactos();
    static boolean salir = true;
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        do {

		            System.out.println("\n=========== MENU ===========");
		            System.out.println("1.- Buscar un contacto");
		            System.out.println("2.- Introducir un nuevo contacto");
		            System.out.println("3.- Eliminar un contacto");
		            System.out.println("4.- Salir");

		            int opcion = scInt.nextInt();

		            switch (opcion) {

		            case 1:
		                buscarContacto();
		                System.out.println("\nPulsa ENTER para volver al menu");
		                scLine.nextLine();
		                break;

		            case 2:
		                introducirContacto();
		                System.out.println("\nPulsa ENTER para volver al menu");
		                scLine.nextLine();
		                break;

		            case 3:
		                eliminarContacto();
		                System.out.println("\nPulsa ENTER para volver al menu");
		                scLine.nextLine();
		                break;

		            case 4:
		                salir();
		                break;

		            default:
		                System.out.println("Selecciona una opcion correcta");
		                System.out.println("\nPulsa ENTER para volver al menu");
		                scLine.nextLine();
		                break;
		            }

		        } while (salir);

		        System.out.println("\nAdeu...");
		    }

		    public static void buscarContacto() {
		        System.out.println("\nBuscar por:");
		        System.out.println("1.- Telefono");
		        System.out.println("2.- Email");

		        int opcion = scInt.nextInt();
		        Contacto encontrado = null;

		        if (opcion == 1) {
		            System.out.print("Introduce el telefono: ");
		            String telefono = scLine.nextLine();
		            encontrado = gestor.buscarPorTelefono(telefono);

		        } else if (opcion == 2) {
		            System.out.print("Introduce el email: ");
		            String email = scLine.nextLine();
		            encontrado = gestor.buscarPorEmail(email);

		        } else {
		            System.out.println("Opcion no valida");
		            return;
		        }

		        if (encontrado != null) {
		            System.out.println("\nContacto encontrado:");
		            System.out.println(encontrado);
		        } else {
		            System.out.println("Ese contacto no existe.");
		        }
		    }

		    public static void introducirContacto() {
		        System.out.print("Nombre: ");
		        String nombre = scLine.nextLine();

		        System.out.print("Apellido: ");
		        String apellido = scLine.nextLine();

		        System.out.print("Telefono: ");
		        String telefono = scLine.nextLine();

		        System.out.print("Email: ");
		        String email = scLine.nextLine();

		        Contacto nuevo = new Contacto(nombre, apellido, telefono, email);

		        if (gestor.agregarContacto(nuevo)) {
		            System.out.println("Contacto añadido correctamente.");
		        }
		    }

		    public static void eliminarContacto() {
		        System.out.println("\nEliminar por:");
		        System.out.println("1.- Telefono");
		        System.out.println("2.- Email");

		        int opcion = scInt.nextInt();
		        boolean eliminado = false;

		        if (opcion == 1) {
		            System.out.print("Introduce el telefono: ");
		            String telefono = scLine.nextLine();
		            eliminado = gestor.eliminarPorTelefono(telefono);

		        } else if (opcion == 2) {
		            System.out.print("Introduce el email: ");
		            String email = scLine.nextLine();
		            eliminado = gestor.eliminarPorEmail(email);

		        } else {
		            System.out.println("Opcion no valida");
		            return;
		        }

		        if (eliminado) {
		            System.out.println("Contacto eliminado correctamente.");
		        } else {
		            System.out.println("No existe un contacto con ese dato.");
		        }
		    }

		    public static void salir() {
		        salir = false;
		    }
		}
