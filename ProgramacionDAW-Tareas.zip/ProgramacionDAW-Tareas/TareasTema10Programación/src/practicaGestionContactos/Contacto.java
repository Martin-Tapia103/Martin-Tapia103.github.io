package practicaGestionContactos;

public class Contacto {

	//===== ATRIBUTOS =====
	
	private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    
    
    //===== CONSTRUCTORES =====

    public Contacto(String nombre, String apellido, String telefono, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
    }

    
    //===== GETTERS Y SETTERS =====
    
    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String toCSV() {
        return nombre + ";" + apellido + ";" + telefono + ";" + email;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\nApellido: " + apellido + "\nTeléfono: " + telefono + "\nEmail: " + email;
    }
	
}
