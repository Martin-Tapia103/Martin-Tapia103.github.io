package practicaGestionContactos;

import java.io.*;
import java.util.ArrayList;

public class GestorContactos {
    private ArrayList<Contacto> contactos;
    private final String archivo = "CONTACTOS/contactos.csv";

    public GestorContactos() {
        this.contactos = new ArrayList<>();
        cargarContactos();
    }

    public void cargarContactos() {
    	
        File fichero = new File(this.archivo);

        if (!fichero.exists()) {
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");

                if (partes.length == 4) {
                    String nombre = partes[0];
                    String apellido = partes[1];
                    String telefono = partes[2];
                    String email = partes[3];

                    Contacto c = new Contacto(nombre, apellido, telefono, email);
                    this.contactos.add(c);
                }
            }

        } catch (IOException e) {
            System.out.println("No se puede ver: " + e.getMessage());
        }
    }

    public Contacto buscarPorTelefono(String telefono) {
        for (Contacto c : this.contactos) {
            if (c.getTelefono().equals(telefono)) {
                return c;
            }
        }
        return null;
    }

    public Contacto buscarPorEmail(String email) {
        for (Contacto c : this.contactos) {
            if (c.getEmail().equalsIgnoreCase(email)) {
                return c;
            }
        }
        return null;
    }

    public boolean existeTelefono(String telefono) {
        return buscarPorTelefono(telefono) != null;
    }

    public boolean existeEmail(String email) {
        return buscarPorEmail(email) != null;
    }

    public boolean agregarContacto(Contacto nuevo) {
        boolean telefonoRepetido = existeTelefono(nuevo.getTelefono());
        boolean emailRepetido = existeEmail(nuevo.getEmail());

        if (telefonoRepetido || emailRepetido) {
            System.out.println("Ese contacto ya existe:");

            if (telefonoRepetido && emailRepetido) {
                System.out.println("Ese teléfono ya existe");
                System.out.println("Ese email ya existe");
            } else if (telefonoRepetido) {
                System.out.println("Ese teléfono ya existe");
            } else {
                System.out.println("Ese email ya existe");
            }

            return false;
        }

        this.contactos.add(nuevo);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            bw.write(nuevo.toCSV());
            bw.newLine();
        } catch (IOException e) {
            System.out.println("No se puede guardar ese contacto : " + e.getMessage());
            return false;
        }

        return true;
    }

    public boolean eliminarPorTelefono(String telefono) {
        Contacto contactoAEliminar = buscarPorTelefono(telefono);

        if (contactoAEliminar == null) {
            return false;
        }

        this.contactos.remove(contactoAEliminar);
        reescribirArchivo();
        return true;
    }

    public boolean eliminarPorEmail(String email) {
        Contacto contactoAEliminar = buscarPorEmail(email);

        if (contactoAEliminar == null) {
            return false;
        }

        this.contactos.remove(contactoAEliminar);
        reescribirArchivo();
        return true;
    }

    private void reescribirArchivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            for (Contacto c : this.contactos) {
                bw.write(c.toCSV());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("No se puede: " + e.getMessage());
        }
    }
}
