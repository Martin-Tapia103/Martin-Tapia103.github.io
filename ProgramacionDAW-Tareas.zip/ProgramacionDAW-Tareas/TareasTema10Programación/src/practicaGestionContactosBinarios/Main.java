package practicaGestionContactosBinarios;

import java.util.*;
import practicaGestionContactos.Contacto;
import java.io.*;

public class Main {

	static boolean salir = false;
	static boolean hayCambios = false;
	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static ArrayList<Contactos> contactos = new ArrayList<>();
	static final String archivo = "contactos.bin";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// ======================== CREAR ARCHIVO ==========================

		File fichero = new File(archivo);

		if (!fichero.exists()) {
			try (FileOutputStream fos = new FileOutputStream(archivo);
					ObjectOutputStream oos = new ObjectOutputStream(fos)) {
				oos.writeObject(contactos);
				System.out.println("El fichero ha sido creado");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// ========================== MENU =============================

		cargarContactos();

		int opcion;
		
		do {
			System.out.println("\n--- GESTOR DE VEHICULOS ---");
			System.out.println("1. Listar contactos que están en memoria.");
			System.out.println("2. Introducir un nuevo contacto.");
			System.out.println("3. Eliminar un contacto.");
			System.out.println("4. Actualizar fichero");
			System.out.println("5. Salir");
			System.out.print("Opción: ");
			opcion = scInt.nextInt();
			scLine.nextLine();

			switch (opcion) {
			
			case 1:
				listarContactos();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 2:
				introducirContacto();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 3:
				eliminarContacto();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 4:
				actualizarFichero();
				System.out.println("\nPulsa ENTER para volver al menu");
				scLine.nextLine();
				break;
				
			case 5:
				salir();
				System.out.println("ADEU (Y guardado si hay cambios)");
				break;
				
			default:
				System.out.println("Eso no es una opción valida");
			}
			
		} while (salir == false);
	}

	
	// ========================== METODOS MENU =============================
	
	private static void listarContactos() {
	    if (contactos.isEmpty()) {
	        System.out.println("No hay contactos en memoria");
	    } else {
	        for (Contactos c : contactos) {
	            System.out.println(c);
	            System.out.println();
	        }
	    }
	}

	private static void introducirContacto() {
	    System.out.print("DNI: ");
	    String dni = scLine.nextLine();

	    boolean existe = false;
	    for (Contactos c : contactos) {
	        if (c.getDni().equalsIgnoreCase(dni)) {
	            existe = true;
	        }
	    }

	    if (existe) {
	        System.out.println("Ya existe un contacto con ese dni");
	    } else {
	        System.out.print("Nombre: ");
	        String nombre = scLine.nextLine();

	        System.out.print("Apellido: ");
	        String apellido = scLine.nextLine();

	        System.out.print("Teléfono: ");
	        String telefono = scLine.nextLine();

	        System.out.print("Email: ");
	        String email = scLine.nextLine();

	        contactos.add(new Contactos(dni, nombre, apellido, telefono, email));
	        hayCambios = true;

	        System.out.println("Contacto añadido en memoria");
	    }
	}

	private static void eliminarContacto() {
	    System.out.print("DNI del contacto a eliminar: ");
	    String dni = scLine.nextLine();

	    boolean eliminado = false;

	    for (int i = 0; i < contactos.size(); i++) {
	        if (contactos.get(i).getDni().equalsIgnoreCase(dni)) {
	            contactos.remove(i);
	            eliminado = true;
	            hayCambios = true;
	            break;
	        }
	    }

	    if (eliminado) {
	        System.out.println("Contacto eliminado de memoria");
	    } else {
	        System.out.println("No existe un contacto con ese dni");
	    }
	}

	private static void actualizarFichero() {
	    if (!hayCambios) {
	        System.out.println("No hay cambios que actualizar");
	        return;
	    }

	    try (FileOutputStream fos = new FileOutputStream(archivo);
	            ObjectOutputStream oos = new ObjectOutputStream(fos)) {

	        oos.writeObject(contactos);
	        hayCambios = false;

	        System.out.println("Actualizado");

	    } catch (IOException e) {
	        System.out.println("No se puede: " + e.getMessage());
	    }
	}

	private static void salir() {
	    if (hayCambios) {
	        try (FileOutputStream fos = new FileOutputStream(archivo);
	                ObjectOutputStream oos = new ObjectOutputStream(fos)) {

	            oos.writeObject(contactos);
	            hayCambios = false;
	            salir = true;

	        } catch (IOException e) {
	            System.out.println("No se puede: " + e.getMessage());
	        }
	    } else {
	        salir = true;
	    }
	}
	

	// ========================== GESTOR =============================

	private static void cargarContactos() {
	    File fichero = new File(archivo);
	    if (!fichero.exists()) {
	        return;
	    }

	    try (FileInputStream fis = new FileInputStream(fichero);
	            ObjectInputStream ois = new ObjectInputStream(fis)) {

	        contactos = (ArrayList<Contactos>) ois.readObject();

	    } catch (Exception e) {
	        System.out.println("No se puede ver: " + e.getMessage());
	    }
	}
}