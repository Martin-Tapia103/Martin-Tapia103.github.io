package tareas;

import java.util.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.ChronoUnit;

public class PracticaFechaYhoras {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE dd/MM/yyyy HH:mm:ss");

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int opcion;

		do {

			LocalDateTime ahora = LocalDateTime.now();

			System.out.println("\n=== FECHA ACTUAL ===");
			System.out.println(ahora + " (Sin formatear)");
			System.out.println(ahora.format(formatter) + " (Formateada)");

			System.out.println("\n1.- Sumar tiempo");
			System.out.println("2.- Restar tiempo");
			System.out.print("Elige una opción: ");
			opcion = scInt.nextInt();

			if (opcion == 1 || opcion == 2) {

				System.out.println("\n1.- Minutos");
				System.out.println("2.- Horas");
				System.out.println("3.- Días");
				System.out.println("4.- Meses");
				System.out.println("5.- Años");
				System.out.print("Elige una opción: ");
				int opcion1 = scInt.nextInt();

				System.out.print("Cantidad: ");
				int cantidad = scInt.nextInt();

				LocalDateTime modificada = ahora;

				if (opcion == 1) {
					switch (opcion1) {
					case 1:
						modificada = ahora.plusMinutes(cantidad);
						break;
					case 2:
						modificada = ahora.plusHours(cantidad);
						break;
					case 3:
						modificada = ahora.plusDays(cantidad);
						break;
					case 4:
						modificada = ahora.plusMonths(cantidad);
						break;
					case 5:
						modificada = ahora.plusYears(cantidad);
						break;
					}
				} else {
					switch (opcion1) {
					case 1:
						modificada = ahora.minusMinutes(cantidad);
						break;
					case 2:
						modificada = ahora.minusHours(cantidad);
						break;
					case 3:
						modificada = ahora.minusDays(cantidad);
						break;
					case 4:
						modificada = ahora.minusMonths(cantidad);
						break;
					case 5:
						modificada = ahora.minusYears(cantidad);
						break;
					}
				}

				LocalDateTime nuevo = LocalDateTime.now();

				long minutosD = Math.abs(ChronoUnit.MINUTES.between(nuevo, modificada));
				long horasD = minutosD / 60;
				long minutosRestantes = minutosD % 60;

				System.out.println("\n=== ==== ===");
				System.out.println("Fecha y hora modificada: " + modificada.format(formatter));
				System.out.println("Fecha y hora real: " + nuevo.format(formatter));
				System.out.println("Horas de diferencia: " + horasD);
				System.out.println("Minutos de diferencia: " + minutosD);
				System.out.println("Tiempo de diferencia: " + horasD + " horas + " + minutosRestantes + " minutos");
			}
				
		} while (true);
	}
}
