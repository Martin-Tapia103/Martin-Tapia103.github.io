package practicaGestionVehiculos;

public class Coche extends Vehiculo {
	
	
	//ATRIBUTOS
	
	private int numeroPuertas;
	private boolean automatico; //true = si | false = no
	
	
	//CONSTRUCTORES
	

	public Coche() {
		super();
	}


	public Coche(String matricula, String marca, int anyo, int numeroPuertas, boolean automatico) {
		super(matricula, marca, anyo);
		this.numeroPuertas = numeroPuertas;
		this.automatico = automatico;
	}


	//GETTERS Y SETTERS
	
	
	public int getNumeroPuertas() {
		return numeroPuertas;
	}


	public void setNumeroPuertas(int numeroPuertas) {
		this.numeroPuertas = numeroPuertas;
	}


	public boolean isAutomatico() {
		return automatico;
	}


	public void setAutomatico(boolean automatico) {
		this.automatico = automatico;
	}

	
	//TO STRING

	@Override
	public String toString() {
		return "COCHE;" + matricula + ";" + marca + ";" + anyo + ";" + numeroPuertas + ";" + automatico;
	}	
}
