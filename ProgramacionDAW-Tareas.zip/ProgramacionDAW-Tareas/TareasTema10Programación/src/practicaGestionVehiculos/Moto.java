package practicaGestionVehiculos;

public class Moto extends Vehiculo {
	
	//ATRIBUTOS 
	
	private int cilindrada;
	
	
	//CONSTRUCTORES

	public Moto(String matricula, String marca, int anyo, int cilindrada) {
		super(matricula, marca, anyo);
		this.cilindrada = cilindrada;
	}

	public Moto() {
		super();
	}

	
	//GETTERS Y SETTERS
	
	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	
	//TO STRING
	
	@Override
	public String toString() {
		return "MOTO;" + matricula + ";" + marca + ";" + anyo + ";" + cilindrada;
	}
	
	
	
	

}
