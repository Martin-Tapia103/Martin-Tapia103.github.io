package practicaGestionVehiculos;

public abstract class Vehiculo {

	// ============= ATRIBUTOS ===================
	
	protected String matricula;
	protected String marca;
	protected int anyo;
	
	
	// ============= CONSTRUCTORES =================
	
	public Vehiculo(String matricula, String marca, int anyo) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.anyo = anyo;
	}


	public Vehiculo() {
		super();
	}


	// ============ GETTERS Y SETTERS ==============
	
	public String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public int getAnyo() {
		return anyo;
	}


	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	// ============= TO STRING ==================
	
	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", marca=" + marca + ", anyo=" + anyo + "]";
	}
	
	
	
	
	
}
