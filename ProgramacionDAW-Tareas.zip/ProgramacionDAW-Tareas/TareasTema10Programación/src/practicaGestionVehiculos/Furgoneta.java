package practicaGestionVehiculos;

public class Furgoneta extends Vehiculo {
	
	//ATRIBUTOS
	
	private double capacidadCarga;
	
	
	//CONSTRUCTORES

	public Furgoneta(String matricula, String marca, int anyo, double capacidadCarga) {
		super(matricula, marca, anyo);
		this.capacidadCarga = capacidadCarga;
	}

	public Furgoneta() {
		super();
	}

	
	//GETTERS Y SETTERS
	
	public double getCapacidadCarga() {
		return capacidadCarga;
	}

	public void setCapacidadCarga(double capacidadCarga) {
		this.capacidadCarga = capacidadCarga;
	}


	
	//TO STRING
	
	@Override
	public String toString() {
		return "FURGONETA;" + matricula + ";" + marca + ";" + anyo + ";" + capacidadCarga;
	}
	
	

}
