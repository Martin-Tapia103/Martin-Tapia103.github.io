package PracticaGestionVehiculosMain;

import java.io.*;
import java.util.*;

import practicaGestionVehiculos.*;

public class Main {

	static Scanner scInt = new Scanner(System.in);
	static Scanner scLine = scInt;
	static Scanner scBoolean = scInt;

	static private ArrayList<Vehiculo> vehiculos = new ArrayList<>();
	static final String archivo = "vehiculos.txt";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// ================================= MAIN =================================
		
		cargarVehiculos(); 

        int opcion;

        do {
            System.out.println("\n--- GESTOR DE VEHICULOS ---");
            System.out.println("1. Mostrar vehículos");
            System.out.println("2. Añadir vehículo");
            System.out.println("3. Eliminar vehículo");
            System.out.println("4. Buscar por marca");
            System.out.println("5. Salir");
            System.out.print("Opción: ");
            opcion = scInt.nextInt();
            scLine.nextLine();

            switch (opcion) {
                case 1:
                    mostrarVehiculos();
                    break;
                case 2:
                    anadirVehiculo();
                    break;
                case 3:
                    eliminarVehiculo();
                    break;
                case 4:
                    buscarPorMarca();
                    break;
                case 5:
                    guardarVehiculos(); 
                    System.out.println("Guardado");
                    break;
                default:
                    System.out.println("Eso no es uan opción valida");
            }

        } while (opcion != 5);
    }

    // ================= MÉTODOS =================

    private static void mostrarVehiculos() {
        for (Vehiculo v : vehiculos) {
            System.out.println(v);
        }
    }

    private static void anadirVehiculo() {

        System.out.print("Tipo (COCHE/MOTO/FURGONETA): ");
        String tipo = scLine.nextLine().toUpperCase();

        System.out.print("Matrícula: ");
        String matricula = scLine.nextLine();

        System.out.print("Marca: ");
        String marca = scLine.nextLine();

        System.out.print("Año: ");
        int anyo = scInt.nextInt();
        scLine.nextLine();

        switch (tipo) {
            case "COCHE":
            	System.out.print("Número de puertas: ");
            	int puertas = scInt.nextInt();
            	scLine.nextLine();

            	System.out.print("¿Automático? (true/false): ");
            	boolean automatico = scBoolean.nextBoolean();
            	scLine.nextLine();
            	
            	vehiculos.add(new Coche(matricula, marca, anyo, puertas, automatico));
                break;

            case "MOTO":
                System.out.print("Cilindrada: ");
                int cilindrada = scInt.nextInt();
                scLine.nextLine();

                vehiculos.add(new Moto(matricula, marca, anyo, cilindrada));
                break;

            case "FURGONETA":
                System.out.print("Capacidad de carga: ");
                double carga = scInt.nextDouble();
                scLine.nextLine();

                vehiculos.add(new Furgoneta(matricula, marca, anyo, carga));
                break;

            default:
                System.out.println("Tipo no válido");
        }
    }

    private static void eliminarVehiculo() {
        System.out.print("Introduce matricula: ");
        String mat = scLine.nextLine();

        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).getMatricula().equalsIgnoreCase(mat)) {
                vehiculos.remove(i);
                break;
            }
        }
    }

    private static void buscarPorMarca() {
        System.out.print("Marca: ");
        String marca = scLine.nextLine();

        for (Vehiculo v : vehiculos) {
            if (v.getMarca().equalsIgnoreCase(marca)) {
                System.out.println(v);
            }
        }
    }
		
    
		// ================================= GESTOR DE VEHICULOS =========================================
		
			
    private static void cargarVehiculos() {
	    
	    File fichero = new File(archivo);

	    if (!fichero.exists()) {
	        return;
	    }

	    try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
	        String linea;

	        while ((linea = br.readLine()) != null) {
	            String[] partes = linea.split(";");

	            String tipo = partes[0];
	            String matricula = partes[1];
	            String marca = partes[2];
	            int anyo = Integer.parseInt(partes[3]);

	            switch (tipo.toUpperCase()) {
	                case "COCHE":
	                	int numeroPuertas = Integer.parseInt(partes[4]);
	                	boolean automatico = Boolean.parseBoolean(partes[5]);
	                	Vehiculo coche = new Coche(matricula, marca, anyo, numeroPuertas, automatico);
	                    vehiculos.add(coche);
	                    break;

	                case "MOTO":
	                    int cilindrada = Integer.parseInt(partes[4]);
	                    Vehiculo moto = new Moto(matricula, marca, anyo, cilindrada);
	                    vehiculos.add(moto);
	                    break;

	                case "FURGONETA":
	                    double capacidadCarga = Double.parseDouble(partes[4]);
	                    Vehiculo furgoneta = new Furgoneta(matricula, marca, anyo, capacidadCarga);
	                    vehiculos.add(furgoneta);
	                    break;

	                default:
	                    System.out.println("Eso no es un vehiculo valido: " + tipo);
	                    break;
	            }
	        }

	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}
	
    private static void guardarVehiculos() {
	    
	    File fichero = new File(archivo);

	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichero))) {
	        
	        for (Vehiculo v : vehiculos) {
	            bw.write(v.toString());
	            bw.newLine();
	        }

	    } catch (IOException e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}
}
