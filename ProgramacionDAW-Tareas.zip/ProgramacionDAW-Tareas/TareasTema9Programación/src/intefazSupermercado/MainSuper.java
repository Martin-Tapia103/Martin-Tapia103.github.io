package intefazSupermercado;

import java.util.*;

import java.awt.*;

import javax.swing.*;

public class MainSuper {

	static Producto[] productos = {

			new Producto("Lejía", 2.5),
 
			new Producto("Chocolate", 1.25),

			new Producto("Brick de leche", 0.9),

			new Producto("Macarrones", 1.5),

			new Producto("Jamón", 5.75),

			new Producto("Pulpo", 10.5),

			new Producto("Mantequilla", 1.0), 

			new Producto("Lomo", 3.5),

			new Producto("Natillas", 2.25),

			new Producto("Caviar", 32.5)

	};

	static double precioTotal = 0;

	public static void main(String[] args) {

		// ---------------- VENTANA 1 ----------------

		JFrame frame1 = new JFrame("Supermercado");

		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame1.setSize(400, 350);

		frame1.setLocation(200, 150);

		JPanel panel1 = new JPanel(new FlowLayout());

		JRadioButton[] radios = new JRadioButton[productos.length];

		ButtonGroup grupo = new ButtonGroup();

		for (int i = 0; i < productos.length; i++) {

			radios[i] = new JRadioButton(productos[i].getNombre() + " (" + productos[i].getPrecio() + "€)");

			grupo.add(radios[i]);

			panel1.add(radios[i]);

		}

		JLabel lblCantidad = new JLabel("Cantidad:");

		JTextField txtCantidad = new JTextField(5);

		JButton btnComprar = new JButton("Comprar");

		JButton btnDevolver = new JButton("Devolver");

		panel1.add(lblCantidad);

		panel1.add(txtCantidad);

		panel1.add(btnComprar);

		panel1.add(btnDevolver);

		frame1.setContentPane(panel1);

		frame1.setVisible(true);

		// ---------------- VENTANA 2 ----------------

		JFrame frame2 = new JFrame("Pedidos Supermercado");

		frame2.setSize(450, 250);

		frame2.setLocation(650, 150);

		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel2 = new JPanel(new FlowLayout());

		JLabel linea1 = new JLabel();

		JLabel linea2 = new JLabel();

		JLabel linea3 = new JLabel();

		JLabel linea4 = new JLabel();

		panel2.add(linea1);

		panel2.add(linea2);

		panel2.add(linea3);

		panel2.add(linea4);

		frame2.setContentPane(panel2);

		frame2.setVisible(true);

		actualizarResumen(linea1, linea2, linea3, linea4);

		// ---------------- BOTÓN COMPRAR ----------------

		btnComprar.addActionListener(e -> {

			int cantidad = Integer.parseInt(txtCantidad.getText());

			for (int i = 0; i < radios.length; i++) {

				if (radios[i].isSelected()) {

					productos[i].setCantidad(productos[i].getCantidad() + cantidad);

					precioTotal += cantidad * productos[i].getPrecio();

				}

			}

			actualizarResumen(linea1, linea2, linea3, linea4);

		});

		// ---------------- BOTÓN DEVOLVER ----------------

		btnDevolver.addActionListener(e -> {

			int cantidad = Integer.parseInt(txtCantidad.getText());

			for (int i = 0; i < radios.length; i++) {

				if (radios[i].isSelected() && productos[i].getCantidad() >= cantidad) {

					productos[i].setCantidad(productos[i].getCantidad() - cantidad);

					precioTotal -= cantidad * productos[i].getPrecio();

				}

			}

			actualizarResumen(linea1, linea2, linea3, linea4);

		});

	}

	public static void actualizarResumen(JLabel l1, JLabel l2, JLabel l3, JLabel l4) {

		l1.setText(productos[0].getNombre() + ": " + productos[0].getCantidad() +

				" " + productos[1].getNombre() + ": " + productos[1].getCantidad() +

				" " + productos[2].getNombre() + ": " + productos[2].getCantidad());

		l2.setText(productos[3].getNombre() + ": " + productos[3].getCantidad() +

				" " + productos[4].getNombre() + ": " + productos[4].getCantidad() +

				" " + productos[5].getNombre() + ": " + productos[5].getCantidad());

		l3.setText(productos[6].getNombre() + ": " + productos[6].getCantidad() +

				" " + productos[7].getNombre() + ": " + productos[7].getCantidad() +

				" " + productos[8].getNombre() + ": " + productos[8].getCantidad() +

				" " + productos[9].getNombre() + ": " + productos[9].getCantidad());

		l4.setText("Precio total: " + precioTotal);

	}

}


 