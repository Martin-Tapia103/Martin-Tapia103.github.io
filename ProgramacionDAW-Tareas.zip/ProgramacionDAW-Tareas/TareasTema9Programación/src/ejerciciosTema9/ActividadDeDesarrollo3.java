package ejerciciosTema9;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ActividadDeDesarrollo3 {

	 static int suma = 0; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

JFrame frame = new JFrame("NOMBRE");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(500,400);
		frame.setLocationRelativeTo(null);  

		JPanel panel = new JPanel(new FlowLayout());
		
		JButton boton = new JButton("Boton");
		JLabel texto = new JLabel("0");

		
		panel.add(boton);
		panel.add(texto);

        boton.addActionListener(e -> {
        	
            suma++; 
            texto.setText(String.valueOf(suma));
            
        });

        frame.setContentPane(panel);
        frame.setVisible(true);

	}

}
