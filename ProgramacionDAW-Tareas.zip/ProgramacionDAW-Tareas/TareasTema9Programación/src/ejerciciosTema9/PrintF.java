package ejerciciosTema9;
import java.util.*;

public class PrintF {

	static Scanner scLine = new Scanner(System.in);
	static Scanner scInt = new Scanner(System.in);
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1

		System.out.print("Introduce tu nombre: ");
		String nombre = scLine.nextLine();

		System.out.print("Introduce tu ciudad: ");
		String ciudad = scLine.nextLine();

		System.out.printf("Nombre: %s, Ciudad: %s\n\n", nombre, ciudad);

		// 2

		System.out.print("Introduce tu nombre: ");
		String nombre2 = scLine.nextLine();

		System.out.print("Introduce tu edad: ");
		int edad = scInt.nextInt();

		System.out.print("Introduce el año actual: ");
		int anyo = scInt.nextInt();

		System.out.printf("Nombre: %s, Edad: %d, Año: %d\n\n", nombre2, edad, anyo);

		// 3

		double pi = Math.PI;
		System.out.printf("PI con 4 decimales: %.4f\n\n", pi);

		// 4

		boolean valor = true;
		System.out.printf("Valor booleano: %b\n\n", valor);

		// 5

		char inicial1 = 'A';
		System.out.printf("Inicial: %c\n\n", inicial1);

		// 6

		System.out.printf("%-10d %10s\n", 1, "Hola");
		System.out.printf("%-10d %10s\n", 123, "Mundo");
		System.out.printf("%-10d %10s\n", 12345, "Java");
		System.out.println();

		// 7

		System.out.print("Introduce un número entero: ");
		int num = scInt.nextInt();
		System.out.printf("Número con ceros: %05d\n\n", num);

		// 8

		System.out.print("Introduce un número grande: ");
		int grande = scInt.nextInt();
		System.out.printf("Con separadores: %,d\n", grande);

	}

}
