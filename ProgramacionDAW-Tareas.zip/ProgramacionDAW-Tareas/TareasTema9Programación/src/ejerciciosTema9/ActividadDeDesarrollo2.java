package ejerciciosTema9;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ActividadDeDesarrollo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
JFrame frame = new JFrame("VENTANA IZQUIERDA");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(500,300);
		frame.setLocation(150,400);
		JLabel label1 = new JLabel("Introduce un texto"); 
		
		JPanel panel = new JPanel(new FlowLayout());		
		panel.add(label1);
			
		JTextField textoAEscribir = new JTextField(10);		
		panel.add(textoAEscribir);
		
		frame.setContentPane(panel);	
		frame.setVisible(true);
		
		
		
		
JFrame frame2 = new JFrame("VENTANA DERECHA");

		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame2.setSize(600,400);
		frame2.setLocation(1050,400);

		JPanel panel2 = new JPanel(new FlowLayout());

		JButton boton = new JButton("Boton"); 
		JLabel texto = new JLabel("");

		panel2.add(boton);
		panel2.add(texto);

		boton.addActionListener(e -> {
		    texto.setText(textoAEscribir.getText());
		});

		frame2.setContentPane(panel2);
		frame2.setVisible(true);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
