package tarea1;

public class Tarea1FigurasMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("----------------------- ESFERAS ---------------------------");
		
		Esfera esfera0 = new Esfera();
		Esfera esfera1 = new Esfera();
		Esfera esfera2 = new Esfera();
		
		esfera0.setTamanyo("Pequeña");
		esfera0.setRadio(5);
		esfera0.asignarColor();
		esfera0.setMaterial("hierro");
		
		System.out.println("\nLa superficie de la esfera " + esfera0.getTamanyo() + " y " + esfera0.getColor() + " es " + esfera0.calcularSuperficieEsfera());
		System.out.println("El volumen de la esfera " + esfera0.getTamanyo() + " y " + esfera0.getColor() + " es " + esfera0.calcularVolumenEsfera());
		System.out.println("La esfera " + esfera0.getTamanyo()  + " pesa " + esfera0.calcularPeso() + " gr y cuesta pintarla de verde " + esfera0.calcularCostePintura() + " euros");
		
		esfera1.setTamanyo("Mediana");
		esfera1.setRadio(10);
		esfera1.asignarColor();
		esfera1.setMaterial("madera");
		
		System.out.println("\nLa superficie de la esfera " + esfera1.getTamanyo() + " y " + esfera1.getColor() + " es " + esfera1.calcularSuperficieEsfera());
		System.out.println("El volumen de la esfera " + esfera1.getTamanyo() + " y " + esfera1.getColor() + " es " + esfera1.calcularVolumenEsfera());
		System.out.println("La esfera " + esfera1.getTamanyo()  + " pesa " + esfera1.calcularPeso() + " gr y cuesta pintarla de verde " + esfera1.calcularCostePintura() + " euros");
		
		esfera2.setTamanyo("Grande");
		esfera2.setRadio(15);
		esfera2.asignarColor();
		esfera2.setMaterial("corcho");
		
		System.out.println("\nLa superficie de la esfera " + esfera2.getTamanyo() + " y " + esfera2.getColor() + " es " + esfera2.calcularSuperficieEsfera());
		System.out.println("El volumen de la esfera " + esfera2.getTamanyo() + " y " + esfera2.getColor() + " es " + esfera2.calcularVolumenEsfera());
		System.out.println("La esfera " + esfera2.getTamanyo()  + " pesa " + esfera2.calcularPeso() + " gr y cuesta pintarla de verde " + esfera2.calcularCostePintura() + " euros");

		
		//-------------------------------
		
		System.out.println("\n\n------------------------ CILINDROS ------------------------");
		
		Cilindro cilindro0 = new Cilindro();
		Cilindro cilindro1 = new Cilindro();
		Cilindro cilindro2 = new Cilindro();
		
		cilindro0.setTamanyo("Pequeño");
		cilindro0.setRadio(5);
		cilindro0.setAltura(10);
		cilindro0.asignarColor();
		cilindro0.setMaterial("hierro");
		
		System.out.println("\nLa superficie del cilindro " + cilindro0.getTamanyo() + " y " + cilindro0.getColor() + " es " + cilindro0.calcularSuperficieCilindro());
		System.out.println("El volumen del cilindro " + cilindro0.getTamanyo() + " y " + cilindro0.getColor() + " es " + cilindro0.calcularVolumenCilindro());
		System.out.println("El cilindro " + cilindro0.getTamanyo()  + " pesa " + cilindro0.calcularPeso() + " gr y cuesta pintarlo de verde " + cilindro0.calcularCostePintura() + " euros");
		
		cilindro1.setTamanyo("Mediana");
		cilindro1.setRadio(10);
		cilindro1.setAltura(15);
		cilindro1.asignarColor();
		cilindro1.setMaterial("madera");
		
		System.out.println("\nLa superficie del cilindro " + cilindro1.getTamanyo() + " y " + cilindro1.getColor() + " es " + cilindro1.calcularSuperficieCilindro());
		System.out.println("El volumen del cilindro " + cilindro1.getTamanyo() + " y " + cilindro1.getColor() + " es " + cilindro1.calcularVolumenCilindro());
		System.out.println("El cilindro " + cilindro1.getTamanyo()  + " pesa " + cilindro1.calcularPeso() + " gr y cuesta pintarlo de verde " + cilindro1.calcularCostePintura() + " euros");
		
		
		cilindro2.setTamanyo("Grande");
		cilindro2.setRadio(15);
		cilindro2.setAltura(20);
		cilindro2.asignarColor();
		cilindro2.setMaterial("corcho");
		
		System.out.println("\nLa superficie del cilindro " + cilindro2.getTamanyo() + " y " + cilindro2.getColor() + " es " + cilindro2.calcularSuperficieCilindro());
		System.out.println("El volumen del cilindro " + cilindro2.getTamanyo() + " y " + cilindro2.getColor() + " es " + cilindro2.calcularVolumenCilindro());
		System.out.println("El cilindro " + cilindro2.getTamanyo()  + " pesa " + cilindro2.calcularPeso() + " gr y cuesta pintarlo de verde " + cilindro2.calcularCostePintura() + " euros");
		
		
		//-------------------------------
		
		System.out.println("\n\n------------------------ ORTOEDROS ------------------------");
		
		
		Ortoedro ortoedro0 = new Ortoedro("Pequeño", 1, 1, 1);
		Ortoedro ortoedro1 = new Ortoedro("Mediano", 2, 2, 2);
		Ortoedro ortoedro2 = new Ortoedro("Grande", 3, 3, 3);
		
		
		ortoedro0.asignarColor();
		ortoedro0.setMaterial("hierro");
		ortoedro1.asignarColor();
		ortoedro1.setMaterial("madera");
		ortoedro2.asignarColor();
		ortoedro2.setMaterial("corcho");
		
		
		System.out.println("\nLa superficie del ortoedro " + ortoedro0.getTamanyo() + " y " + ortoedro0.getColor() + " es " + ortoedro0.calcularSuperficieOrtoedro());
		System.out.println("El volumen del ortoedro " + ortoedro0.getTamanyo() + " y " + ortoedro0.getColor() + " es " + ortoedro0.calcularVolumenOrtoedro());
		System.out.println("El ortoedro " + ortoedro0.getTamanyo()  + " pesa " + ortoedro0.calcularPeso() + " gr y cuesta pintarlo de verde " + ortoedro0.calcularCostePintura() + " euros");
		
		System.out.println("\nLa superficie del ortoedro " + ortoedro1.getTamanyo() + " y " + ortoedro1.getColor() + " es " + ortoedro1.calcularSuperficieOrtoedro());
		System.out.println("El volumen del ortoedro " + ortoedro1.getTamanyo() + " y " + ortoedro1.getColor() + " es " + ortoedro1.calcularVolumenOrtoedro());
		System.out.println("El ortoedro " + ortoedro1.getTamanyo()  + " pesa " + ortoedro1.calcularPeso() + " gr y cuesta pintarlo de verde " + ortoedro1.calcularCostePintura() + " euros");
		
		System.out.println("\nLa superficie del ortoedro " + ortoedro2.getTamanyo() + " y " + ortoedro2.getColor() + " es " + ortoedro2.calcularSuperficieOrtoedro());
		System.out.println("El volumen del ortoedro " + ortoedro2.getTamanyo() + " y " + ortoedro2.getColor() + " es " + ortoedro2.calcularVolumenOrtoedro());
		System.out.println("El ortoedro " + ortoedro2.getTamanyo()  + " pesa " + ortoedro2.calcularPeso() + " gr y cuesta pintarlo de verde " + ortoedro2.calcularCostePintura() + " euros");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
