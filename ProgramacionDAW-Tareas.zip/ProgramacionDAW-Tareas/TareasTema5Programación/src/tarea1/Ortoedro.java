package tarea1;

import java.util.Random;

public class Ortoedro {

	
	//ATRIBUTOS ---------------------------------------------------------------------------------------------
	
	private String tamanyo;
	private String color;
	private double largo;
	private double ancho;
	private double altura;
	private String material;
	
		
	//CONSTRUCTORES -----------------------------------------------------------------------------------------
	
	//---------------------------------------
	
	public Ortoedro() {
		super();
	}
	
	//---------------------------------------
	
	public Ortoedro(String tamanyo, double largo, double ancho, double altura) {
		super();
		this.tamanyo = tamanyo;
		this.largo = largo;
		this.ancho = ancho;
		this.altura = altura;
	}
	
		
	
	
	// SETTERS Y GETTERS ------------------------------------------------------------------------------------
	
	
	public String getTamanyo() {
		return tamanyo;
	}

	public void setTamanyo(String tamanyo) {
		this.tamanyo = tamanyo;
	}
			
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public double getLargo() {
		return largo;
	}

	public void setLargo(double largo) {
		this.largo = largo;
	}

	public double getAncho() {
		return ancho;
	}

	public void setAncho(double ancho) {
		this.ancho = ancho;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public double calcularSuperficieOrtoedro() {

		double superficie = 0;
		superficie = 2.0*(this.largo*this.ancho + this.largo*this.altura + this.ancho*this.altura);
		double superficieOrtoedroADos = Math.round(superficie * 100.0) / 100.0;
		return superficieOrtoedroADos;
		
	}
	
	public double calcularVolumenOrtoedro() {
		double volumen = 0;
		volumen = this.largo*this.ancho*this.altura;
		double volumenOrtoedroADos = Math.round(volumen * 100.0) / 100.0;
		return volumenOrtoedroADos;
		
	}
	
	
	public void asignarColor( ) {
		
		Random r = new Random();
		int c1 = r.nextInt(2);
		int c2 = r.nextInt(2);
		
		if (c1 == 0) {
			this.color = "verde";
				
		}else {
			this.color = "azul";			
		}
		
		if (c2 == 0) {
			this.color = "verde";
				
		}else {
			this.color = "azul";			
		}
		
	}
	
	
	public double calcularPeso() {
		double densidad = 0;

		switch (this.material) {
			case "corcho":
				densidad = 0.2;
				break;
			case "madera":
				densidad = 0.7;
				break;
			case "hierro":
				densidad = 7.87;
				break;
			default:
				System.out.println("Material desconocido");
				return 0;
		}
			
		double peso = densidad * calcularVolumenOrtoedro();
		return Math.round(peso * 100.0) / 100.0;
	}
	
	
	public double calcularCostePintura() {
		double costeCm2 = 0;

		switch (this.color) {
			case "verde":
				switch (this.material) {
					case "corcho": costeCm2 = 0.05; break;
					case "madera": costeCm2 = 0.07; break;
					case "hierro": costeCm2 = 0.09; break;
				}
				break;
			case "azul":
				switch (this.material) {
					case "corcho": costeCm2 = 0.06; break;
					case "madera": costeCm2 = 0.08; break;
					case "hierro": costeCm2 = 0.10; break;
				}
				break;
		}
		
		double costeTotal = costeCm2 * calcularSuperficieOrtoedro();
		return Math.round(costeTotal * 100.0) / 100.0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
