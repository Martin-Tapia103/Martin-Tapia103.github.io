package tarea1;

import java.util.Random;

public class Cilindro {

	
	//ATRIBUTOS ---------------------------------------------------------------------------------------------
	
		private String tamanyo;
		private double radio;
		private String color;
		private double altura;
		private String material;
		
			
		//CONSTRUCTORES -----------------------------------------------------------------------------------------
		
		//---------------------------------------
		
		public Cilindro() {
			super();
		}
		
		//---------------------------------------
		
		
			
		
		
		
		
		// SETTERS Y GETTERS ------------------------------------------------------------------------------------
		
		public String getTamanyo() {
			return tamanyo;
		}

		public void setTamanyo(String tamanyo) {
			this.tamanyo = tamanyo;
		}
			
		public double getRadio() {
			return radio;
		}

		public void setRadio(double radio) {
			this.radio = radio;
		}
		
		public String getColor() {
			return color;
		}

		public void setColor(String color) {
			this.color = color;
		}
	
		public double getAltura() {
			return altura;
		}

		public void setAltura(double altura) {
			this.altura = altura;
		}

		
		public String getMaterial() {
			return material;
		}

		public void setMaterial(String material) {
			this.material = material;
		}

		public double calcularSuperficieCilindro() {

			double superficie = 0;
			superficie = 2*Math.PI*this.radio*(this.radio + this.altura);
			double superficieCilindroADos = Math.round(superficie * 100.0) / 100.0;
			return superficieCilindroADos;
			
		}
		
		public double calcularVolumenCilindro() {
			double volumen = 0;
			volumen = Math.PI*Math.pow(radio, 2)*this.altura;
			double volumenCilindroADos = Math.round(volumen * 100.0) / 100.0;
			return volumenCilindroADos;
			
		}
		
		
		public void asignarColor( ) {
			
			Random r = new Random();
			int c1 = r.nextInt(2);
			int c2 = r.nextInt(2);
			
			if (c1 == 0) {
				this.color = "verde";
					
			}else {
				this.color = "azul";			
			}
			
			if (c2 == 0) {
				this.color = "verde";
					
			}else {
				this.color = "azul";			
			}
			
		}
	
	
		public double calcularPeso() {
			double densidad = 0;

			switch (this.material) {
				case "corcho":
					densidad = 0.2;
					break;
				case "madera":
					densidad = 0.7;
					break;
				case "hierro":
					densidad = 7.87;
					break;
				default:
					System.out.println("Material desconocido");
					return 0;
			}
				
			double peso = densidad * calcularVolumenCilindro();
			return Math.round(peso * 100.0) / 100.0;
		}
		
		
		public double calcularCostePintura() {
			double costeCm2 = 0;

			switch (this.color) {
				case "verde":
					switch (this.material) {
						case "corcho": costeCm2 = 0.05; break;
						case "madera": costeCm2 = 0.07; break;
						case "hierro": costeCm2 = 0.09; break;
					}
					break;
				case "azul":
					switch (this.material) {
						case "corcho": costeCm2 = 0.06; break;
						case "madera": costeCm2 = 0.08; break;
						case "hierro": costeCm2 = 0.10; break;
					}
					break;
			}
			
			double costeTotal = costeCm2 * calcularSuperficieCilindro();
			return Math.round(costeTotal * 100.0) / 100.0;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
