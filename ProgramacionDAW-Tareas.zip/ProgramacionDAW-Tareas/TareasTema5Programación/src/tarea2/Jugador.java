package tarea2;

public class Jugador {
	

	//ATRIBUTOS ------------------------------------
	
	private String nombre;
	private int numero1;
	private int numero2;
	private int numero3;
	private boolean aci_numero1;
	private boolean aci_numero2;
	private boolean aci_numero3;
	
	
	
	//CONSTRUCTORES ----------------------------------
	
	public Jugador() {
		super();
	}	
	
	//----------------------
	
	public Jugador(String nombre) {
		super();
		this.nombre = nombre;
	}

		
	
	
	//GETTERS Y SETTERS
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumero1() {
		return numero1;
	}

	public void setNumero1(int numero1) {
		this.numero1 = numero1;
	}

	public int getNumero2() {
		return numero2;
	}

	public void setNumero2(int numero2) {
		this.numero2 = numero2;
	}

	public int getNumero3() {
		return numero3;
	}

	public void setNumero3(int numero3) {
		this.numero3 = numero3;
	}

	public boolean isAci_numero1() {
		return aci_numero1;
	}


	public void setAci_numero1(boolean aci_numero1) {
		this.aci_numero1 = aci_numero1;
	}


	public boolean isAci_numero2() {
		return aci_numero2;
	}


	public void setAci_numero2(boolean aci_numero2) {
		this.aci_numero2 = aci_numero2;
	}


	public boolean isAci_numero3() {
		return aci_numero3;
	}


	public void setAci_numero3(boolean aci_numero3) {
		this.aci_numero3 = aci_numero3;
	}

    public void asignarCarton() {

        this.numero1 = (int)(Math.random() * 20 + 1);
        this.numero2 = (int)(Math.random() * 20 + 1);
        this.numero3 = (int)(Math.random() * 20 + 1);

        System.out.println("Los números de " + this.nombre + " son: " + this.numero1 + ", " + this.numero2 + " y " + this.numero3);
    }
	
    public void comprobarBola(int bola) {
        if (bola == this.numero1 && !this.aci_numero1) {
            this.aci_numero1 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }

        if (bola == this.numero2 && !this.aci_numero2) {
            this.aci_numero2 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }

        if (bola == this.numero3 && !this.aci_numero3) {
            this.aci_numero3 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }
    }
            
    public boolean esGanador() {
        return this.aci_numero1 && this.aci_numero2 && this.aci_numero3;
    }       
            
        
    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
