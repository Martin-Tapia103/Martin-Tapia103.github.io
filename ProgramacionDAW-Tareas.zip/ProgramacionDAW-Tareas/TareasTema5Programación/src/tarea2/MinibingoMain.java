package tarea2;

import java.util.*;

public class MinibingoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scLine = new Scanner(System.in);

		Bombo b0 = new Bombo();
		
		Jugador p0 = new Jugador("Matias");
		Jugador p1 = new Jugador("Luuuurdes");
		Jugador p2 = new Jugador("Gorjo");
		Jugador p3 = new Jugador("Ignacia Facunda");
		Jugador p4 = new Jugador("Hector");
		
		p0.asignarCarton();
		p1.asignarCarton();
		p2.asignarCarton();
		p3.asignarCarton();
		p4.asignarCarton();
		
		System.out.println("\n");
		
		while(true) {
		System.out.println("Pulsa ENTER para sacar una bola ");
		String enter = scLine.nextLine();
		System.out.println("Ha salido la bola " + b0.sacarBola() + "\n");
		
		p0.comprobarBola(b0.getUltimaBola());
		p1.comprobarBola(b0.getUltimaBola());
		p2.comprobarBola(b0.getUltimaBola());
		p3.comprobarBola(b0.getUltimaBola());
		p4.comprobarBola(b0.getUltimaBola());
		
		System.out.println("\n");
		
		if (p0.esGanador()) {
			System.out.println("El jugador " + p0.getNombre() + " ha ganado");
			System.out.println("La partida ha finalizado");
			break;
		} else if (p1.esGanador()){
			System.out.println("El jugador " + p1.getNombre() + " ha ganado");
			System.out.println("La partida ha finalizado");
			break;
		} else if (p2.esGanador()){
			System.out.println("El jugador " + p2.getNombre() + " ha ganado");
			System.out.println("La partida ha finalizado");
			break;
		} else if (p3.esGanador()){
			System.out.println("El jugador " + p3.getNombre() + " ha ganado");
			System.out.println("La partida ha finalizado");
			break;
		} else if (p4.esGanador()){
			System.out.println("El jugador " + p4.getNombre() + " ha ganado");
			System.out.println("La partida ha finalizado");
			break;
		} else {
		continue;	
		
		}
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
    }
}
