package tarea2.MiniBingoAmpliado;

public class Bombo {
	
	//ATRIBUTOS --------------------------------------------------

	private int ultimaBola;
	
	
	
	 //CONSTRUCTORES ---------------------------------------------
	
	public Bombo() {
	this.ultimaBola = 0;
	}
	
	
	//GETTERS Y SETTERS ------------------------------------------
	
	public int getUltimaBola() {
		return ultimaBola;
	}

	public void setUltimaBola(int ultimaBola) {
		this.ultimaBola = ultimaBola;
	}
	
    public int sacarBola() {
        int bola;
        do {
            bola = (int)(Math.random() * 20) + 1;
        } while (bola == this.ultimaBola);

        ultimaBola = bola;
        return bola;
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
