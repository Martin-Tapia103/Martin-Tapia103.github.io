package tarea2.MiniBingoAmpliado;

import java.util.Scanner;

public class MinibingoMain {

    public static void main(String[] args) {

        Scanner scLine = new Scanner(System.in);

        Jugador p0 = new Jugador("Matias");
        Jugador p1 = new Jugador("Luuuurdes");
        Jugador p2 = new Jugador("Gorjo");
        Jugador p3 = new Jugador("Ignacia Facunda");
        Jugador p4 = new Jugador("Hector");

        while (true) {

        	 Bombo bombo = new Bombo();
        	
            int vivos = 0;

            if (p0.isEnjuego()) vivos++;
            if (p1.isEnjuego()) vivos++;
            if (p2.isEnjuego()) vivos++;
            if (p3.isEnjuego()) vivos++;
            if (p4.isEnjuego()) vivos++;

            if (vivos == 1) {

                System.out.println("\nFIN");

                if (p0.isEnjuego()) System.out.println("GANADOR: " + p0.getNombre());
                if (p1.isEnjuego()) System.out.println("GANADOR: " + p1.getNombre());
                if (p2.isEnjuego()) System.out.println("GANADOR: " + p2.getNombre());
                if (p3.isEnjuego()) System.out.println("GANADOR: " + p3.getNombre());
                if (p4.isEnjuego()) System.out.println("GANADOR: " + p4.getNombre());

                break;
            }
            
            for (int i = 0; i < 1; i++) {
            System.out.println("\nPulsa ENTER para jugar la partida (No mantener pulsado enter que si no se buggea)");
            scLine.nextLine();
            }

            double bote = 0;
           
            if (p0.isEnjuego() && p0.pagarCarton()) { p0.asignarCarton(); bote += 5; }
            else p0.setEnjuego(false);

            if (p1.isEnjuego() && p1.pagarCarton()) { p1.asignarCarton(); bote += 5; }
            else p1.setEnjuego(false);

            if (p2.isEnjuego() && p2.pagarCarton()) { p2.asignarCarton(); bote += 5; }
            else p2.setEnjuego(false);

            if (p3.isEnjuego() && p3.pagarCarton()) { p3.asignarCarton(); bote += 5; }
            else p3.setEnjuego(false);

            if (p4.isEnjuego() && p4.pagarCarton()) { p4.asignarCarton(); bote += 5; }
            else p4.setEnjuego(false);

            System.out.println("\nBote total: " + bote + "€");

            boolean partidaTerminada = false;

            
            while (!partidaTerminada) {

                int bola = bombo.sacarBola();
                System.out.println("\nHa salido la bola: " + bola);

                if (p0.isEnjuego()) p0.comprobarBola(bola);
                if (p1.isEnjuego()) p1.comprobarBola(bola);
                if (p2.isEnjuego()) p2.comprobarBola(bola);
                if (p3.isEnjuego()) p3.comprobarBola(bola);
                if (p4.isEnjuego()) p4.comprobarBola(bola);

              
                int ganadores = 0;

                if (p0.isEnjuego() && p0.esGanador()) ganadores++;
                if (p1.isEnjuego() && p1.esGanador()) ganadores++;
                if (p2.isEnjuego() && p2.esGanador()) ganadores++;
                if (p3.isEnjuego() && p3.esGanador()) ganadores++;
                if (p4.isEnjuego() && p4.esGanador()) ganadores++;

                if (ganadores > 0) {

                    double premio = bote / ganadores;

                    System.out.println("\nGANADOR:");

                    if (p0.esGanador()) { p0.sumarDinero(premio); System.out.println(p0.getNombre() + " gana " + premio + "€"); }
                    if (p1.esGanador()) { p1.sumarDinero(premio); System.out.println(p1.getNombre() + " gana " + premio + "€"); }
                    if (p2.esGanador()) { p2.sumarDinero(premio); System.out.println(p2.getNombre() + " gana " + premio + "€"); }
                    if (p3.esGanador()) { p3.sumarDinero(premio); System.out.println(p3.getNombre() + " gana " + premio + "€"); }
                    if (p4.esGanador()) { p4.sumarDinero(premio); System.out.println(p4.getNombre() + " gana " + premio + "€"); }

                    partidaTerminada = true;
                }
            }

            System.out.println("\nDinero al finalizar:");

            if (p0.isEnjuego()) System.out.println(p0.getNombre() + ": " + p0.getDinero() + "€");
            else System.out.println(p0.getNombre() + " ELIMINADO");

            if (p1.isEnjuego()) System.out.println(p1.getNombre() + ": " + p1.getDinero() + "€");
            else System.out.println(p1.getNombre() + " ELIMINADO");

            if (p2.isEnjuego()) System.out.println(p2.getNombre() + ": " + p2.getDinero() + "€");
            else System.out.println(p2.getNombre() + " ELIMINADO");

            if (p3.isEnjuego()) System.out.println(p3.getNombre() + ": " + p3.getDinero() + "€");
            else System.out.println(p3.getNombre() + " ELIMINADO");

            if (p4.isEnjuego()) System.out.println(p4.getNombre() + ": " + p4.getDinero() + "€");
            else System.out.println(p4.getNombre() + " ELIMINADO");
        }

        scLine.close();
    }
}
