package tarea2.MiniBingoAmpliado;

public class Jugador {
	

	//ATRIBUTOS ------------------------------------
	
	private String nombre;
	private int numero1;
	private int numero2;
	private int numero3;
	private boolean aci_numero1;
	private boolean aci_numero2;
	private boolean aci_numero3;
	private double dinero = 20;
	private boolean enjuego = true; //true = Esta en juego / false = Eliminado
	
	
	//CONSTRUCTORES ----------------------------------
	
	public Jugador() {
		super();
	}	
	
	//----------------------
	
	public Jugador(String nombre) {
		super();
		this.nombre = nombre;
	}

		
	
	
	//GETTERS Y SETTERS
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumero1() {
		return numero1;
	}

	public void setNumero1(int numero1) {
		this.numero1 = numero1;
	}

	public int getNumero2() {
		return numero2;
	}

	public void setNumero2(int numero2) {
		this.numero2 = numero2;
	}

	public int getNumero3() {
		return numero3;
	}

	public void setNumero3(int numero3) {
		this.numero3 = numero3;
	}

	public boolean isAci_numero1() {
		return aci_numero1;
	}


	public void setAci_numero1(boolean aci_numero1) {
		this.aci_numero1 = aci_numero1;
	}


	public boolean isAci_numero2() {
		return aci_numero2;
	}


	public void setAci_numero2(boolean aci_numero2) {
		this.aci_numero2 = aci_numero2;
	}


	public boolean isAci_numero3() {
		return aci_numero3;
	}


	public void setAci_numero3(boolean aci_numero3) {
		this.aci_numero3 = aci_numero3;
	}
	
    public double getDinero() {
		return dinero;
	}

	public void setDinero(double dinero) {
		this.dinero = dinero;
	}

	public boolean isEnjuego() {
		return enjuego;
	}

	public void setEnjuego(boolean enjuego) {
		this.enjuego = enjuego;
	}

	public void asignarCarton() {

		int n1, n2, n3;

		 n1 = (int) (Math.random() * 20 + 1);
		 do {
		 n2 = (int) (Math.random() * 20 + 1);
		 } while (n2 == n1);
		 do {			 
		 n3 = (int) (Math.random() * 20 + 1);
		 } while (n3 == n1 || n3 == n2);

		 
		 this.numero1 = n1;
		 this.numero2 = n2;
		 this.numero3 = n3;

		 System.out.println("Los números de " + this.nombre + " son: " + this.numero1 + ", " + this.numero2 + " y " + this.numero3);

		 aci_numero1 = false;
		 aci_numero2 = false;
		 aci_numero3 = false;
		 
	}
	
    public void comprobarBola(int bola) {
        if (bola == this.numero1 && !this.aci_numero1) {
            this.aci_numero1 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }

        if (bola == this.numero2 && !this.aci_numero2) {
            this.aci_numero2 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }

        if (bola == this.numero3 && !this.aci_numero3) {
            this.aci_numero3 = true;
            System.out.println("el jugador " + this.nombre + " tiene el numero " + bola);
        }
    }
            
    public boolean esGanador() {
        return this.aci_numero1 && this.aci_numero2 && this.aci_numero3;
    }       
               
    public boolean pagarCarton() {
        if (this.dinero >= 5) {
            this.dinero -= 5;
            return true;
        } else {
        return false;       
        }
    }

    public void sumarDinero(double premio) {
        this.dinero += premio;
    }
	
	public void estaJugando( ) {
		while(true) {
			if (this.enjuego == false) {
				System.out.println("El jugador ha sido elminado");
				
		} else {
			continue;
			}
				
		}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
